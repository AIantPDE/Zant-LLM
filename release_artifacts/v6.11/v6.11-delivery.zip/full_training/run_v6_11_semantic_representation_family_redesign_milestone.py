from pathlib import Path
import argparse,subprocess,sys

def main():
    ap=argparse.ArgumentParser()
    for k in (
        "root","base-model","source-adapter","v67-patch","v610-bridge",
        "v69-report","v69-summary","v69-detail","v69-target-family",
        "v610-report","v610-analysis","v610-summary","train-file",
        "runtime-script","worker"
    ):
        ap.add_argument("--"+k,required=True)
    a=ap.parse_args()

    print("========== ZANT-LLM v6.11 SEMANTIC REPRESENTATION FAMILY REDESIGN ==========")
    print("NO_TRAINING=True")
    print("NO_NEW_RULES=True")
    print("SOURCE_V6_10_COMPLETE=True")
    print("SOURCE_V6_10_PASS=0/20")
    print("SOURCE_V6_10_HIT_MAX=10")
    print("SOURCE_V6_10_FIRST_TOKEN_TOP1=0/20")
    print("SOURCE_V6_10_FIRST_TOKEN_MEAN_RANK=59.7")
    print("SOURCE_V6_10_POSITIVE_MINUS_NEGATIVE_LOGP=-1.4009976446628571")
    print("SCAN_ALL_35_TEXT_LAYERS=True")
    print("RETAINED_HOLDOUT_EVALUATED=False")
    print("NO_GITHUB_PUSH=True")

    cmd=[
        Path(sys.executable),a.worker,
        "--root",a.root,
        "--base-model",a.base_model,
        "--source-adapter",a.source_adapter,
        "--v67-patch",a.v67_patch,
        "--v610-bridge",a.v610_bridge,
        "--v69-report",a.v69_report,
        "--v69-summary",a.v69_summary,
        "--v69-detail",a.v69_detail,
        "--v69-target-family",a.v69_target_family,
        "--v610-report",a.v610_report,
        "--v610-analysis",a.v610_analysis,
        "--v610-summary",a.v610_summary,
        "--train-file",a.train_file,
        "--runtime-script",a.runtime_script,
    ]
    print("RUN="+subprocess.list2cmdline([str(x) for x in cmd]))
    p=subprocess.run([str(x) for x in cmd])
    if p.returncode!=0:
        raise SystemExit("v6.11 worker failed exit="+str(p.returncode))

    print("V6_11_PROCESS_EXIT=0")
    print("========== v6.11 ONE-CLICK DONE ==========")

if __name__=="__main__":
    main()
