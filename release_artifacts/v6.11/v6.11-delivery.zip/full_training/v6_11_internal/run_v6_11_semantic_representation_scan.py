from pathlib import Path
import argparse,json,hashlib,importlib.util,statistics,gc
from collections import defaultdict

EXPECTED_V610_REPORT_SHA="9b9d38e6774f33c9772ab6170ab04ab7a64532a31bc6ad0d9f245a901fa19316"
EXPECTED_V610_ANALYSIS_SHA="f43e4c190824bde0a3867a2b4e0202f4b326655ecf44b6d92adee6e2d06679d4"
EXPECTED_V610_SUMMARY_SHA="773757738abb26775b3a99e20ac1931ba7e5778ccd70a47e4a78e03bc63dace0"
EXPECTED_V610_PATCH_MANIFEST_SHA="32709d0a17f63a0b9ca90fb12aea81754b9155d5cd2cb5a2cde89a025e82a53b"
EXPECTED_V610_BRIDGE_FILE_SHA="5381124ed214dc6d9fa2291d0b5ee2732a8a07c3526c1c1bf917abb877f3ec32"
EXPECTED_V69_REPORT_SHA="ccad373c434e536ad109c1079dce704cf29a90894573ad4667b5cc084712331d"
EXPECTED_V69_SUMMARY_SHA="a033d2b35428cbc74c162bb362f2c5e15c727b3acde87b376f915eec3f14d7b9"

def load_module(path,name):
    spec=importlib.util.spec_from_file_location(name,str(path))
    m=importlib.util.module_from_spec(spec)
    spec.loader.exec_module(m)
    return m

def write_json(path,obj):
    Path(path).parent.mkdir(parents=True,exist_ok=True)
    Path(path).write_text(json.dumps(obj,ensure_ascii=False,indent=2)+"\n",
                          encoding="utf-8",newline="\n")

def write_jsonl(path,rows):
    Path(path).parent.mkdir(parents=True,exist_ok=True)
    with Path(path).open("w",encoding="utf-8",newline="\n") as f:
        for r in rows:
            f.write(json.dumps(r,ensure_ascii=False,separators=(",",":"))+"\n")

def prompt_ids(tok,prompt):
    try:
        txt=tok.apply_chat_template(
            [{"role":"user","content":prompt}],
            tokenize=False,add_generation_prompt=True
        )
        return tok(txt,add_special_tokens=False).input_ids
    except Exception:
        return tok("User: "+prompt+"\nAssistant: ",add_special_tokens=False).input_ids

def generated_first_token_id(tok,text):
    ids=tok(str(text).strip(),add_special_tokens=False).input_ids
    return int(ids[0]) if ids else None

def positive_first_token_id(tok,text):
    ids=tok(str(text).strip(),add_special_tokens=False).input_ids
    if not ids:
        raise RuntimeError("Empty positive target tokens")
    return int(ids[0])

def rank_and_margin(logits,pos_id,neg_id):
    pos=logits[int(pos_id)]
    rank=int((logits>pos).sum().item())+1
    if neg_id is None:
        margin=None
        win=None
    else:
        margin=float((pos-logits[int(neg_id)]).item())
        win=bool(margin>0)
    return rank,margin,win

def summarize_layer(rows,layer):
    xs=[r for r in rows if r["layer"]==layer]
    ranks=[r["positive_first_token_rank"] for r in xs]
    margins=[r["positive_minus_negative_first_token_logit"]
             for r in xs if r["positive_minus_negative_first_token_logit"] is not None]
    wins=[r["positive_beats_negative_first_token"]
          for r in xs if r["positive_beats_negative_first_token"] is not None]
    out={
        "layer":layer,
        "rows":len(xs),
        "mean_rank":float(statistics.mean(ranks)),
        "median_rank":float(statistics.median(ranks)),
        "top1_count":sum(int(x==1) for x in ranks),
        "top5_count":sum(int(x<=5) for x in ranks),
        "top10_count":sum(int(x<=10) for x in ranks),
        "top32_count":sum(int(x<=32) for x in ranks),
        "positive_vs_negative_win_count":sum(int(x) for x in wins),
        "mean_positive_minus_negative_first_token_logit":(
            float(statistics.mean(margins)) if margins else None
        ),
    }
    for language in ("en","zh"):
        ys=[r for r in xs if r["language"]==language]
        yr=[r["positive_first_token_rank"] for r in ys]
        ym=[r["positive_minus_negative_first_token_logit"]
            for r in ys if r["positive_minus_negative_first_token_logit"] is not None]
        yw=[r["positive_beats_negative_first_token"]
            for r in ys if r["positive_beats_negative_first_token"] is not None]
        out[language]={
            "rows":len(ys),
            "mean_rank":float(statistics.mean(yr)),
            "top10_count":sum(int(x<=10) for x in yr),
            "positive_vs_negative_win_count":sum(int(x) for x in yw),
            "mean_positive_minus_negative_first_token_logit":(
                float(statistics.mean(ym)) if ym else None
            ),
        }
    return out

def select_best(stats):
    return min(
        stats,
        key=lambda x:(
            -int(x["positive_vs_negative_win_count"]),
            -int(x["top10_count"]),
            float(x["mean_rank"]),
            -float(x["mean_positive_minus_negative_first_token_logit"]
                   if x["mean_positive_minus_negative_first_token_logit"] is not None else -1e30),
            int(x["layer"]),
        )
    )

def main():
    ap=argparse.ArgumentParser()
    for k in (
        "root","base-model","source-adapter","v67-patch","v610-bridge",
        "v69-report","v69-summary","v69-detail","v69-target-family",
        "v610-report","v610-analysis","v610-summary","train-file",
        "runtime-script"
    ):
        ap.add_argument("--"+k,required=True)
    a=ap.parse_args()

    rt=load_module(a.runtime_script,"v611_runtime")
    root=Path(a.root)

    v610_bridge=Path(a.v610_bridge)
    v610_report=Path(a.v610_report)
    v610_analysis=Path(a.v610_analysis)
    v610_summary=Path(a.v610_summary)
    v69_report=Path(a.v69_report)
    v69_summary=Path(a.v69_summary)
    v69_detail=Path(a.v69_detail)
    v69_family=Path(a.v69_target_family)
    trainf=Path(a.train_file)

    for p in (
        Path(a.base_model),Path(a.source_adapter),Path(a.v67_patch),v610_bridge,
        v610_report,v610_analysis,v610_summary,v69_report,v69_summary,
        v69_detail,v69_family,trainf
    ):
        if not p.exists():
            raise SystemExit("Missing required source: "+str(p))

    if rt.sha256_file(v610_report)!=EXPECTED_V610_REPORT_SHA:
        raise SystemExit("v6.10 anchor report SHA mismatch")
    if rt.sha256_file(v610_analysis)!=EXPECTED_V610_ANALYSIS_SHA:
        raise SystemExit("v6.10 analysis SHA mismatch")
    if rt.sha256_file(v610_summary)!=EXPECTED_V610_SUMMARY_SHA:
        raise SystemExit("v6.10 summary SHA mismatch")
    if rt.folder_manifest_sha(v610_bridge)!=EXPECTED_V610_PATCH_MANIFEST_SHA:
        raise SystemExit("v6.10 patch manifest SHA mismatch")
    if rt.sha256_file(v610_bridge/"semantic_bridge.safetensors")!=EXPECTED_V610_BRIDGE_FILE_SHA:
        raise SystemExit("v6.10 bridge file SHA mismatch")
    if rt.sha256_file(v69_report)!=EXPECTED_V69_REPORT_SHA:
        raise SystemExit("v6.9 report SHA mismatch")
    if rt.sha256_file(v69_summary)!=EXPECTED_V69_SUMMARY_SHA:
        raise SystemExit("v6.9 summary SHA mismatch")

    r610=rt.read_json(v610_report)
    a610=rt.read_json(v610_analysis)
    s610=rt.read_json(v610_summary)
    if int(r610.get("discriminative_anchor_pass_count",-1))!=0:
        raise SystemExit("Expected v6.10 PASS=0")
    if int(r610.get("anchor_hit_max_count",-1))!=10:
        raise SystemExit("Expected v6.10 HIT_MAX=10")
    if int(r610.get("first_token_top1_count",-1))!=0:
        raise SystemExit("Expected v6.10 first-token TOP1=0")
    if abs(float(r610.get("first_token_mean_rank",-1))-59.7)>1e-9:
        raise SystemExit("Unexpected v6.10 first-token mean rank")
    if float(r610.get("positive_minus_negative_logp_mean",999))>=0:
        raise SystemExit("Expected v6.10 positive-minus-negative logp to remain negative")
    if a610.get("classification")!="SEMANTIC_CRITERION_AWARE_DISCRIMINATIVE_TRAINING_INSUFFICIENT":
        raise SystemExit("v6.10 analysis classification mismatch")
    if int(a610.get("same_generated_text_as_v6_8_rows",-1))!=19:
        raise SystemExit("Expected v6.10 same-text-as-v6.8=19/20")
    if s610.get("milestone_complete") is not True:
        raise SystemExit("v6.10 milestone not complete")
    if s610.get("retained_holdout_opened") is not False:
        raise SystemExit("retained holdout must remain closed")
    if s610.get("next_milestone")!="v6.11-semantic-representation-family-redesign-milestone":
        raise SystemExit("v6.10 route mismatch")

    r69=rt.read_json(v69_report)
    if rt.sha256_file(v69_detail)!=r69.get("detail_file_sha256"):
        raise SystemExit("v6.9 detail SHA mismatch")
    if rt.sha256_file(v69_family)!=r69.get("target_family_candidate_file_sha256"):
        raise SystemExit("v6.9 target-family SHA mismatch")
    if int(r69.get("best_existing_source_semantic_pass_count",-1))!=20:
        raise SystemExit("Expected 20/20 criterion-valid positive targets")

    train_rows=rt.read_jsonl(trainf)
    anchors=[r for r in train_rows if r.get("v5_9_2_role")=="residual_anchor"]
    if len(anchors)!=20:
        raise SystemExit("Expected 20 residual anchors")
    by_train={rt.cid(r):r for r in anchors}
    family={str(r.get("source_case_id")):r for r in rt.read_jsonl(v69_family)}
    detail={str(r.get("id")):r for r in rt.read_jsonl(v69_detail)}
    if len(by_train)!=20 or len(family)!=20 or len(detail)!=20:
        raise SystemExit("Expected 20-row train/family/detail maps")

    print("========== ZANT-LLM v6.11 SEMANTIC REPRESENTATION FAMILY REDESIGN ==========")
    print("NO_TRAINING=True")
    print("NO_NEW_RULES=True")
    print("SOURCE_V6_10_COMPLETE=True")
    print("SOURCE_V6_10_PASS=0/20")
    print("SOURCE_V6_10_HIT_MAX=10")
    print("SOURCE_V6_10_FIRST_TOKEN_TOP1=0/20")
    print("SOURCE_V6_10_FIRST_TOKEN_MEAN_RANK=59.7")
    print("SOURCE_V6_10_POSITIVE_MINUS_NEGATIVE_LOGP=-1.4009976446628571")
    print("SCAN=ALL_35_TEXT_LAYERS")
    print("SIGNAL=CRITERION_VALID_POSITIVE_FIRST_TOKEN_VS_SEMANTIC_FAIL_NEGATIVE_FIRST_TOKEN")
    print("SOURCE_MODEL=V6_7_DISTRIBUTED_RESIDUAL_BEFORE_FINAL_SEMANTIC_BRIDGE")
    print("RETAINED_HOLDOUT_EVALUATED=False")
    print("NO_GITHUB_PUSH=True")

    import torch
    torch.backends.cuda.enable_flash_sdp(False)
    torch.backends.cuda.enable_mem_efficient_sdp(False)
    torch.backends.cuda.enable_math_sdp(True)

    tok,model,info=rt.load_base_with_v67_residual(
        Path(a.base_model),Path(a.source_adapter),Path(a.v67_patch)
    )
    layers_name,layers=rt.find_text_layers(model)
    if layers is None or len(layers)!=35:
        raise SystemExit("Expected exactly 35 text layers")
    final_norm=info["_final_norm"]
    lm_head=model.get_output_embeddings()
    if lm_head is None:
        raise SystemExit("Could not resolve LM head")

    captures={}
    handles=[]
    for idx in range(35):
        def make_hook(i):
            def hook(module,args,out):
                h=rt.extract_hidden(out)
                captures[i]=h[:,-1:,:].detach()
            return hook
        handles.append(layers[idx].register_forward_hook(make_hook(idx)))

    rows=[]
    family_layer_rows=defaultdict(list)

    for case_idx,r in enumerate(anchors,1):
        rid=rt.cid(r)
        fr=family[rid]
        dr=detail[rid]
        positive=str(fr.get("target_family_candidate") or "").strip()
        negative=str(dr.get("generated_text") or "").strip()
        if not positive or not negative:
            raise SystemExit("Empty positive/negative text for "+rid)
        pos_id=positive_first_token_id(tok,positive)
        neg_id=generated_first_token_id(tok,negative)
        prompt,_=rt.prompt_target(r)
        pids=prompt_ids(tok,prompt)
        ii=torch.tensor([pids],dtype=torch.long,device="cuda:0")
        mm=torch.ones_like(ii)

        captures.clear()
        with torch.no_grad():
            oo=model(input_ids=ii,attention_mask=mm,use_cache=False,return_dict=True)
        if len(captures)!=35:
            raise RuntimeError(f"Captured {len(captures)} layers, expected 35 for {rid}")

        stack=torch.cat([captures[i] for i in range(35)],dim=0)
        # [35,1,H] -> norm -> LM-head in one batched projection.
        with torch.no_grad():
            normed=final_norm(stack)
            logits=lm_head(normed)[:,0,:].float()

        for layer in range(35):
            rank,margin,win=rank_and_margin(logits[layer],pos_id,neg_id)
            rec={
                "id":rid,
                "language":rt.lang(r),
                "family":rt.family(r),
                "layer":layer,
                "positive_target_source":fr.get("target_family_source"),
                "positive_first_token_id":pos_id,
                "negative_first_token_id":neg_id,
                "positive_first_token_rank":rank,
                "positive_minus_negative_first_token_logit":margin,
                "positive_beats_negative_first_token":win,
            }
            rows.append(rec)
            family_layer_rows[rt.family(r)].append(rec)

        print(
            f"CASE_{case_idx}_OF_20={rid} LANG={rt.lang(r)} FAMILY={rt.family(r)} "
            f"L0_RANK={rows[-35]['positive_first_token_rank']} "
            f"L34_RANK={rows[-1]['positive_first_token_rank']}"
        )

        del ii,mm,oo,stack,normed,logits
        torch.cuda.empty_cache()

    for h in handles:
        h.remove()

    stats=[summarize_layer(rows,i) for i in range(35)]
    best=select_best(stats)
    final=stats[34]

    # Per-language best layers.
    def lang_view(s,language):
        return {
            "layer":s["layer"],
            "rows":s[language]["rows"],
            "mean_rank":s[language]["mean_rank"],
            "top10_count":s[language]["top10_count"],
            "positive_vs_negative_win_count":s[language]["positive_vs_negative_win_count"],
            "mean_positive_minus_negative_first_token_logit":s[language]["mean_positive_minus_negative_first_token_logit"],
        }
    best_en=min(
        (lang_view(s,"en") for s in stats),
        key=lambda x:(-x["positive_vs_negative_win_count"],-x["top10_count"],x["mean_rank"],x["layer"])
    )
    best_zh=min(
        (lang_view(s,"zh") for s in stats),
        key=lambda x:(-x["positive_vs_negative_win_count"],-x["top10_count"],x["mean_rank"],x["layer"])
    )

    # Per-family best layers, useful if semantics localize differently by family.
    family_best={}
    for fam,frows in family_layer_rows.items():
        fstats=[]
        for layer in range(35):
            xs=[x for x in frows if x["layer"]==layer]
            ranks=[x["positive_first_token_rank"] for x in xs]
            wins=[x["positive_beats_negative_first_token"] for x in xs if x["positive_beats_negative_first_token"] is not None]
            margins=[x["positive_minus_negative_first_token_logit"] for x in xs if x["positive_minus_negative_first_token_logit"] is not None]
            fstats.append({
                "layer":layer,
                "rows":len(xs),
                "mean_rank":float(statistics.mean(ranks)),
                "top10_count":sum(int(x<=10) for x in ranks),
                "positive_vs_negative_win_count":sum(int(x) for x in wins),
                "mean_margin":float(statistics.mean(margins)) if margins else None,
            })
        family_best[fam]=min(
            fstats,
            key=lambda x:(-x["positive_vs_negative_win_count"],-x["top10_count"],x["mean_rank"],x["layer"])
        )

    improvement_ratio=(final["mean_rank"]/best["mean_rank"]) if best["mean_rank"]>0 else None
    layer_gap=abs(int(best_en["layer"])-int(best_zh["layer"]))

    # Automatic macro route.
    if (
        best["layer"] < 34
        and best["positive_vs_negative_win_count"] >= 16
        and best["top10_count"] >= 8
        and best["mean_rank"] <= final["mean_rank"]*0.75
    ):
        classification="UPSTREAM_SEMANTIC_SIGNAL_STRONGER_THAN_FINAL_REPRESENTATION"
        next_milestone="v6.12-cross-layer-semantic-bridge-training-milestone"
        training_authorized=True
        selected_layers=[int(best["layer"])]
    elif (
        best_en["positive_vs_negative_win_count"] >= 8
        and best_zh["positive_vs_negative_win_count"] >= 8
        and layer_gap >= 4
    ):
        classification="BILINGUAL_SEMANTIC_SIGNAL_LOCALIZES_TO_DIFFERENT_LAYER_FAMILIES"
        next_milestone="v6.12-bilingual-dual-source-semantic-bridge-training-milestone"
        training_authorized=True
        selected_layers=sorted(set([int(best_en["layer"]),int(best_zh["layer"])]))
    elif (
        best["positive_vs_negative_win_count"] >= 14
        and best["mean_rank"] <= 32
    ):
        classification="SEMANTIC_SIGNAL_EXISTS_BUT_IS_NOT_STRONGLY_LOST_AT_FINAL_LAYER"
        next_milestone="v6.12-decoding-policy-coupling-milestone"
        training_authorized=False
        selected_layers=[int(best["layer"])]
    else:
        classification="NO_LAYER_EXHIBITS_SUFFICIENT_CRITERION_ALIGNED_SEMANTIC_SEPARABILITY"
        next_milestone="v6.12-semantic-representation-family-reconstruction-milestone"
        training_authorized=False
        selected_layers=[]

    work=root/"diagnostics/v6_11_semantic_representation_family_redesign_milestone"
    work.mkdir(parents=True,exist_ok=True)
    detailp=work/"v6_11_layer_logit_lens_detail.jsonl"
    statsp=work/"v6_11_layer_logit_lens_summary.json"
    planp=work/"v6_11_representation_redesign_plan.json"
    finalp=work/"v6_11_milestone_summary.json"

    write_jsonl(detailp,rows)
    write_json(statsp,{
        "schema":"ZANT_LLM_V6_11_LAYER_LOGIT_LENS_SUMMARY_V1",
        "layers":stats,
        "best_overall":best,
        "final_layer":final,
        "best_english":best_en,
        "best_chinese":best_zh,
        "family_best_layers":family_best,
        "best_vs_final_mean_rank_improvement_ratio":improvement_ratio,
        "best_en_zh_layer_gap":layer_gap,
        "source_v6_10_first_token_mean_rank":59.7,
        "source_v6_8_first_token_mean_rank":24.25,
    })

    write_json(planp,{
        "schema":"ZANT_LLM_V6_11_REPRESENTATION_REDESIGN_PLAN_V1",
        "classification":classification,
        "training_authorized":training_authorized,
        "selected_layers":selected_layers,
        "best_overall_layer":int(best["layer"]),
        "best_overall_mean_rank":best["mean_rank"],
        "best_overall_top10_count":best["top10_count"],
        "best_overall_positive_vs_negative_win_count":best["positive_vs_negative_win_count"],
        "best_overall_mean_margin":best["mean_positive_minus_negative_first_token_logit"],
        "final_layer_mean_rank":final["mean_rank"],
        "final_layer_positive_vs_negative_win_count":final["positive_vs_negative_win_count"],
        "best_english_layer":int(best_en["layer"]),
        "best_chinese_layer":int(best_zh["layer"]),
        "language_layer_gap":layer_gap,
        "next_milestone":next_milestone,
        "retained_holdout_evaluated":False,
    })

    write_json(finalp,{
        "schema":"ZANT_LLM_V6_11_SEMANTIC_REPRESENTATION_FAMILY_REDESIGN_MILESTONE_V1",
        "milestone_complete":True,
        "no_training":True,
        "source_v6_10_complete":True,
        "source_v6_10_anchor_pass_count":0,
        "source_v6_10_hit_max_count":10,
        "source_v6_10_first_token_top1_count":0,
        "source_v6_10_first_token_mean_rank":59.7,
        "source_v6_10_positive_minus_negative_logp_mean":-1.4009976446628571,
        "scanned_text_layers":35,
        "best_layer":int(best["layer"]),
        "best_layer_mean_rank":best["mean_rank"],
        "best_layer_top10_count":best["top10_count"],
        "best_layer_positive_vs_negative_win_count":best["positive_vs_negative_win_count"],
        "final_layer_mean_rank":final["mean_rank"],
        "best_english_layer":int(best_en["layer"]),
        "best_chinese_layer":int(best_zh["layer"]),
        "milestone_status":classification,
        "training_authorized":training_authorized,
        "retained_holdout_opened":False,
        "next_milestone":next_milestone,
        "github_push_performed":False,
    })

    print("========== V6.11 REPRESENTATION SCAN FINAL ==========")
    print("V6_11_MILESTONE_COMPLETE=True")
    print("NO_TRAINING=True")
    print("SCANNED_TEXT_LAYERS=35")
    print("BEST_LAYER="+str(best["layer"]))
    print("BEST_LAYER_MEAN_RANK="+str(best["mean_rank"]))
    print("BEST_LAYER_TOP10_COUNT="+str(best["top10_count"])+"/20")
    print("BEST_LAYER_POSITIVE_VS_NEGATIVE_WIN_COUNT="+str(best["positive_vs_negative_win_count"])+"/20")
    print("BEST_LAYER_MEAN_POSITIVE_MINUS_NEGATIVE_LOGIT="+str(best["mean_positive_minus_negative_first_token_logit"]))
    print("FINAL_LAYER_MEAN_RANK="+str(final["mean_rank"]))
    print("FINAL_LAYER_POSITIVE_VS_NEGATIVE_WIN_COUNT="+str(final["positive_vs_negative_win_count"])+"/20")
    print("BEST_ENGLISH_LAYER="+str(best_en["layer"]))
    print("BEST_CHINESE_LAYER="+str(best_zh["layer"]))
    print("LANGUAGE_LAYER_GAP="+str(layer_gap))
    print("TRAINING_AUTHORIZED="+str(training_authorized))
    print("RETAINED_HOLDOUT_OPENED=False")
    print("MILESTONE_STATUS="+classification)
    print("DETAIL_SHA256="+rt.sha256_file(detailp))
    print("LAYER_SUMMARY_SHA256="+rt.sha256_file(statsp))
    print("PLAN_SHA256="+rt.sha256_file(planp))
    print("FINAL_SUMMARY_SHA256="+rt.sha256_file(finalp))
    print("NEXT_MILESTONE="+next_milestone)
    print("GITHUB_PUSH_PERFORMED=False")

    del model
    gc.collect()
    torch.cuda.empty_cache()

if __name__=="__main__":
    main()
