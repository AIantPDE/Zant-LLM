$ErrorActionPreference = "Stop"

$ROOT = "C:\Users\Administrator\Desktop\Zant-LLM"
$PYTHON = "C:\Users\Administrator\AppData\Local\Programs\Python\Python311\python.exe"
$BASE_MODEL = "E:\gemma-4-E2B-it"

$SOURCE_ADAPTER = Join-Path $ROOT "artifacts\Zant-LLM-v5_9_25-first-token-logit-margin-rank16-adapter"
$V67_PATCH = Join-Path $ROOT "artifacts\Zant-LLM-v6_7-reconstructed-canonical-target-alignment-pilot"
$V610_BRIDGE = Join-Path $ROOT "artifacts\Zant-LLM-v6_10-semantic-criterion-aware-discriminative-bridge"

$V69_REPORT = Join-Path $ROOT "diagnostics\v6_9_semantic_criterion_and_target_family_redesign_milestone\v6_9_semantic_criterion_report.json"
$V69_SUMMARY = Join-Path $ROOT "diagnostics\v6_9_semantic_criterion_and_target_family_redesign_milestone\v6_9_milestone_summary.json"
$V69_DETAIL = Join-Path $ROOT "diagnostics\v6_9_semantic_criterion_and_target_family_redesign_milestone\v6_9_semantic_criterion_audit_detail.jsonl"
$V69_TARGET_FAMILY = Join-Path $ROOT "full_training\v6_9_semantic_criterion_and_target_family_redesign\v6_9_target_family_candidates_20.jsonl"

$V610_REPORT = Join-Path $ROOT "diagnostics\v6_10_semantic_criterion_aware_discriminative_training_milestone\v6_10_anchor20_report.json"
$V610_ANALYSIS = Join-Path $ROOT "diagnostics\v6_10_semantic_criterion_aware_discriminative_training_milestone\v6_10_milestone_analysis.json"
$V610_SUMMARY = Join-Path $ROOT "diagnostics\v6_10_semantic_criterion_aware_discriminative_training_milestone\v6_10_milestone_summary.json"

$TRAIN_FILE = Join-Path $ROOT "full_training\v5_9_2_residual_training_dataset\train_v5_9_2_round2_100.jsonl"

$ORCH = Join-Path $ROOT "full_training\run_v6_11_semantic_representation_family_redesign_milestone.py"
$RUNTIME = Join-Path $ROOT "full_training\v6_11_internal\runtime_v6_11.py"
$WORKER = Join-Path $ROOT "full_training\v6_11_internal\run_v6_11_semantic_representation_scan.py"

Write-Host "========== ZANT-LLM v6.11 SEMANTIC REPRESENTATION FAMILY REDESIGN =========="
Write-Host "NO_TRAINING=True"
Write-Host "NO_NEW_RULES=True"
Write-Host "SOURCE_V6_10_COMPLETE=True"
Write-Host "SOURCE_V6_10_PASS=0/20"
Write-Host "SOURCE_V6_10_HIT_MAX=10"
Write-Host "SOURCE_V6_10_FIRST_TOKEN_TOP1=0/20"
Write-Host "SOURCE_V6_10_FIRST_TOKEN_MEAN_RANK=59.7"
Write-Host "SOURCE_V6_10_POSITIVE_MINUS_NEGATIVE_LOGP=-1.4009976446628571"
Write-Host "SCAN_ALL_35_TEXT_LAYERS=True"
Write-Host "SIGNAL=POSITIVE_FIRST_TOKEN_VS_SEMANTIC_FAIL_NEGATIVE_FIRST_TOKEN"
Write-Host "RETAINED_HOLDOUT_EVALUATED=False"
Write-Host "NO_GITHUB_PUSH=True"

foreach ($p in @($PYTHON,$BASE_MODEL,$SOURCE_ADAPTER,$V67_PATCH,$V610_BRIDGE,$V69_REPORT,$V69_SUMMARY,$V69_DETAIL,$V69_TARGET_FAMILY,$V610_REPORT,$V610_ANALYSIS,$V610_SUMMARY,$TRAIN_FILE,$ORCH,$RUNTIME,$WORKER)) {
    if (!(Test-Path $p)) { throw "Required path not found: $p" }
}

& $PYTHON $ORCH `
    --root $ROOT `
    --base-model $BASE_MODEL `
    --source-adapter $SOURCE_ADAPTER `
    --v67-patch $V67_PATCH `
    --v610-bridge $V610_BRIDGE `
    --v69-report $V69_REPORT `
    --v69-summary $V69_SUMMARY `
    --v69-detail $V69_DETAIL `
    --v69-target-family $V69_TARGET_FAMILY `
    --v610-report $V610_REPORT `
    --v610-analysis $V610_ANALYSIS `
    --v610-summary $V610_SUMMARY `
    --train-file $TRAIN_FILE `
    --runtime-script $RUNTIME `
    --worker $WORKER

$exit=$LASTEXITCODE
Write-Host "V6_11_PROCESS_EXIT=$exit"
if ($exit -ne 0) { throw "v6.11 milestone failed (exit=$exit)" }
Write-Host "========== v6.11 ONE-CLICK DONE =========="
