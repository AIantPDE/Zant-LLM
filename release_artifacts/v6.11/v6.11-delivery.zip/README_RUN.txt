Zant-LLM v6.11 — Semantic Representation Family Redesign Milestone

Authoritative v6.10 result
--------------------------
v6.10 is COMPLETE / CLOSED.

Training completed:
- 20 optimizer steps
- v6.8 final-hidden semantic bridge continued training
- 394,753 trainable parameters
- criterion-valid positives = 20
- semantic-fail negatives = 20

But the final result regressed:
- PASS = 0/20
- HIT_MAX = 10
- first-token TOP1 = 0/20
- first-token mean rank = 59.7
- positive-minus-negative mean sequence log-prob margin = -1.4009976446628571
- same generated text as v6.8 = 19/20

Therefore another blind preference-strength increase is not justified.

Purpose
-------
v6.11 performs NO TRAINING.

It asks a structural question:

Where in the 35-layer text stack does criterion-valid semantic signal exist?

The source model for the layer scan is:
- frozen 4-bit base
- frozen v5.9.25 rank16 LoRA
- frozen v6.7 distributed residual blocks 27 / 29 / 33
- NO v6.8/v6.10 final-hidden bridge

This is intentional: v6.8 and v6.10 bridges operate after the decoder stack, so
their failure does not tell us whether a better semantic signal already exists
at an upstream layer.

For each of the 20 anchors and each of all 35 text layers, v6.11:
1. captures the last prompt-token hidden representation;
2. applies the real final text norm;
3. projects it through the real LM head;
4. measures the rank of the v6.9 criterion-valid positive first token;
5. compares the positive first-token logit to the first token of the audited
   v6.8 semantic-fail negative output.

Metrics per layer:
- mean / median positive first-token rank
- TOP1 / TOP5 / TOP10 / TOP32 counts
- positive-vs-negative first-token win count
- mean positive-minus-negative first-token logit margin
- separate EN and ZH metrics

It also records:
- best overall layer
- best English layer
- best Chinese layer
- best layer for each semantic family

Automatic route
---------------
Strong upstream signal:
  -> v6.12 cross-layer semantic bridge training

Strong but language-localized signal:
  -> v6.12 bilingual dual-source semantic bridge training

Semantic signal exists but is not lost at final layer:
  -> v6.12 decoding-policy coupling

No layer shows sufficient criterion-aligned separability:
  -> v6.12 semantic-representation-family reconstruction

Retained holdout is not evaluated.
No GitHub push.
