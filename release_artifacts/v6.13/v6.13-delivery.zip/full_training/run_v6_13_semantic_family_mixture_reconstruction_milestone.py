from pathlib import Path
import argparse,subprocess,sys

def main():
    ap=argparse.ArgumentParser()
    for k in ("root","v612-report","v612-analysis","v612-summary",
              "v611-detail","v611-layer-summary","v611-plan","v611-summary",
              "v69-report","v69-family","worker"):
        ap.add_argument("--"+k,required=True)
    a=ap.parse_args()

    print("========== ZANT-LLM v6.13 SEMANTIC-FAMILY MIXTURE RECONSTRUCTION ==========")
    print("NO_TRAINING=True")
    print("NO_NEW_RULES=True")
    print("SOURCE_V6_12_COMPLETE=True")
    print("SOURCE_V6_12_PASS=0/20")
    print("SOURCE_V6_12_FIRST_TOKEN_MEAN_RANK=59.85")
    print("SOURCE_V6_12_POS_NEG_WINS=7/20")
    print("SOURCE_V6_12_LANGUAGE_SPECIALIZED_ROUTING=False")
    print("SOURCE_V6_12_SAME_TEXT_AS_V6_10=20/20")
    print("RECONSTRUCTION_AXIS=SEMANTIC_FAMILY")
    print("RETAINED_HOLDOUT_EVALUATED=False")
    print("NO_GITHUB_PUSH=True")

    cmd=[
        Path(sys.executable),a.worker,
        "--root",a.root,
        "--v612-report",a.v612_report,
        "--v612-analysis",a.v612_analysis,
        "--v612-summary",a.v612_summary,
        "--v611-detail",a.v611_detail,
        "--v611-layer-summary",a.v611_layer_summary,
        "--v611-plan",a.v611_plan,
        "--v611-summary",a.v611_summary,
        "--v69-report",a.v69_report,
        "--v69-family",a.v69_family,
    ]
    print("RUN="+subprocess.list2cmdline([str(x) for x in cmd]))
    p=subprocess.run([str(x) for x in cmd])
    if p.returncode!=0:
        raise SystemExit("v6.13 worker failed exit="+str(p.returncode))
    print("V6_13_PROCESS_EXIT=0")
    print("========== v6.13 ONE-CLICK DONE ==========")

if __name__=="__main__":
    main()
