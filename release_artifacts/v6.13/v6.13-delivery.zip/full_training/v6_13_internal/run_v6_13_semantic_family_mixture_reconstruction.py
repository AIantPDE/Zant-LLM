from pathlib import Path
import argparse,json,hashlib,statistics
from collections import defaultdict

EXPECTED_V612_REPORT_SHA="1ff97a29520b9ecfa159de6a52af228a7d046822010fa23f62a63b3ef2f9af09"
EXPECTED_V612_ANALYSIS_SHA="d114635ea18cc40ce4110ec43dacd4cbb0bc7c88ab3691ed15d089ac83f2403f"
EXPECTED_V612_SUMMARY_SHA="b3b87d85c87df73d872f3c2182eb8385e3b5b8730e03a7ae6efb0f5b5e25b28e"
EXPECTED_V611_DETAIL_SHA="866de080c2ea4d33935259b6e87640135077ca71dadce1fb39a9fc125ec7b4b1"
EXPECTED_V611_LAYER_SUMMARY_SHA="4e12b7700188b8ece6b7852b6b33e9002788278d3f23b727b1f45dca1cba2def"
EXPECTED_V611_PLAN_SHA="d764e2e088198f493c21b173aeda2491b368f652c441dd649a38856ef4e60e19"
EXPECTED_V611_SUMMARY_SHA="d406f2e12e7bd6549a0fb59ee4a65ed53a08ba0213446573f63073d5e54d6d44"
EXPECTED_V69_REPORT_SHA="ccad373c434e536ad109c1079dce704cf29a90894573ad4667b5cc084712331d"

def sha(path):
    h=hashlib.sha256()
    with Path(path).open("rb") as f:
        for b in iter(lambda:f.read(1048576),b""):
            h.update(b)
    return h.hexdigest()

def readj(path):
    return json.loads(Path(path).read_text(encoding="utf-8-sig"))

def readl(path):
    with Path(path).open("r",encoding="utf-8-sig") as f:
        return [json.loads(x) for x in f if x.strip()]

def writej(path,obj):
    Path(path).parent.mkdir(parents=True,exist_ok=True)
    Path(path).write_text(json.dumps(obj,ensure_ascii=False,indent=2)+"\n",
                          encoding="utf-8",newline="\n")

def writel(path,rows):
    Path(path).parent.mkdir(parents=True,exist_ok=True)
    with Path(path).open("w",encoding="utf-8",newline="\n") as f:
        for r in rows:
            f.write(json.dumps(r,ensure_ascii=False,separators=(",",":"))+"\n")

def score_layer(xs):
    ranks=[int(x["positive_first_token_rank"]) for x in xs]
    margins=[float(x["positive_minus_negative_first_token_logit"]) for x in xs]
    wins=[bool(x["positive_beats_negative_first_token"]) for x in xs]
    return {
        "layer":int(xs[0]["layer"]),
        "rows":len(xs),
        "positive_vs_negative_win_count":sum(int(x) for x in wins),
        "top10_count":sum(int(x<=10) for x in ranks),
        "top32_count":sum(int(x<=32) for x in ranks),
        "top64_count":sum(int(x<=64) for x in ranks),
        "mean_rank":float(statistics.mean(ranks)),
        "mean_margin":float(statistics.mean(margins)),
    }

def choose(stats):
    return min(stats,key=lambda x:(
        -int(x["positive_vs_negative_win_count"]),
        -int(x["top32_count"]),
        -int(x["top64_count"]),
        float(x["mean_rank"]),
        -float(x["mean_margin"]),
        int(x["layer"]),
    ))

def main():
    ap=argparse.ArgumentParser()
    for k in ("root","v612-report","v612-analysis","v612-summary",
              "v611-detail","v611-layer-summary","v611-plan","v611-summary",
              "v69-report","v69-family"):
        ap.add_argument("--"+k,required=True)
    a=ap.parse_args()
    root=Path(a.root)

    p612r=Path(a.v612_report); p612a=Path(a.v612_analysis); p612s=Path(a.v612_summary)
    p611d=Path(a.v611_detail); p611l=Path(a.v611_layer_summary)
    p611p=Path(a.v611_plan); p611s=Path(a.v611_summary)
    p69r=Path(a.v69_report); p69f=Path(a.v69_family)

    for p in (p612r,p612a,p612s,p611d,p611l,p611p,p611s,p69r,p69f):
        if not p.exists(): raise SystemExit("Missing required source: "+str(p))

    checks=[
        (p612r,EXPECTED_V612_REPORT_SHA,"v6.12 report"),
        (p612a,EXPECTED_V612_ANALYSIS_SHA,"v6.12 analysis"),
        (p612s,EXPECTED_V612_SUMMARY_SHA,"v6.12 summary"),
        (p611d,EXPECTED_V611_DETAIL_SHA,"v6.11 detail"),
        (p611l,EXPECTED_V611_LAYER_SUMMARY_SHA,"v6.11 layer summary"),
        (p611p,EXPECTED_V611_PLAN_SHA,"v6.11 plan"),
        (p611s,EXPECTED_V611_SUMMARY_SHA,"v6.11 summary"),
        (p69r,EXPECTED_V69_REPORT_SHA,"v6.9 report"),
    ]
    for p,e,label in checks:
        if sha(p)!=e: raise SystemExit(label+" SHA mismatch")

    r612=readj(p612r); a612=readj(p612a); s612=readj(p612s)
    if int(r612.get("dual_source_anchor_pass_count",-1))!=0: raise SystemExit("Expected v6.12 PASS=0")
    if int(r612.get("anchor_hit_max_count",-1))!=10: raise SystemExit("Expected v6.12 HIT_MAX=10")
    if int(r612.get("first_token_top1_count",-1))!=0: raise SystemExit("Expected v6.12 TOP1=0")
    if abs(float(r612.get("first_token_mean_rank",-1))-59.85)>1e-9: raise SystemExit("Unexpected v6.12 mean rank")
    if int(r612.get("positive_vs_negative_first_token_win_count",-1))!=7: raise SystemExit("Expected v6.12 wins=7")
    if a612.get("classification")!="BILINGUAL_DUAL_SOURCE_SEMANTIC_BRIDGE_INSUFFICIENT":
        raise SystemExit("v6.12 classification mismatch")
    if a612.get("language_specialized_routing_observed") is not False:
        raise SystemExit("v6.12 routing-specialization state mismatch")
    if int(a612.get("same_generated_text_as_v6_10_rows",-1))!=20:
        raise SystemExit("Expected v6.12 same text as v6.10=20/20")
    if s612.get("milestone_complete") is not True or s612.get("retained_holdout_opened") is not False:
        raise SystemExit("v6.12 closure mismatch")
    if s612.get("next_milestone")!="v6.13-semantic-family-mixture-reconstruction-milestone":
        raise SystemExit("v6.12 route mismatch")

    r69=readj(p69r)
    if sha(p69f)!=r69.get("target_family_candidate_file_sha256"):
        raise SystemExit("v6.9 family candidate SHA mismatch")

    detail=readl(p611d)
    family_rows=readl(p69f)
    family_by_id={str(x.get("source_case_id")):str(x.get("family")) for x in family_rows}
    # v6.9 family file may not preserve family in all historical variants; fall back to v6.11 detail.
    for x in detail:
        rid=str(x.get("id"))
        if rid not in family_by_id or family_by_id[rid] in ("","None"):
            family_by_id[rid]=str(x.get("family") or "unknown")

    if len(detail)!=700:
        raise SystemExit("Expected 700 v6.11 detail rows (20x35), got "+str(len(detail)))

    by_family_layer=defaultdict(lambda:defaultdict(list))
    by_layer=defaultdict(list)
    for x in detail:
        fam=str(x.get("family") or family_by_id.get(str(x.get("id")),"unknown"))
        layer=int(x["layer"])
        by_family_layer[fam][layer].append(x)
        by_layer[layer].append(x)

    global_stats=[score_layer(by_layer[i]) for i in range(35)]
    best_global=choose(global_stats)

    family_plan={}
    for fam,layers in sorted(by_family_layer.items()):
        stats=[score_layer(layers[i]) for i in sorted(layers)]
        family_plan[fam]=choose(stats)

    # Apply each family's selected layer back to its rows.
    selected_rows=[]
    for fam,layers in by_family_layer.items():
        sel=int(family_plan[fam]["layer"])
        selected_rows.extend(layers[sel])

    wins=sum(int(bool(x["positive_beats_negative_first_token"])) for x in selected_rows)
    top10=sum(int(int(x["positive_first_token_rank"])<=10) for x in selected_rows)
    top32=sum(int(int(x["positive_first_token_rank"])<=32) for x in selected_rows)
    top64=sum(int(int(x["positive_first_token_rank"])<=64) for x in selected_rows)
    mean_rank=float(statistics.mean(int(x["positive_first_token_rank"]) for x in selected_rows))
    mean_margin=float(statistics.mean(float(x["positive_minus_negative_first_token_logit"]) for x in selected_rows))
    usable64=sum(int(bool(x["positive_beats_negative_first_token"]) and int(x["positive_first_token_rank"])<=64) for x in selected_rows)

    distinct_layers=sorted(set(int(v["layer"]) for v in family_plan.values()))
    layer_use_counts={}
    for v in family_plan.values():
        layer_use_counts[str(int(v["layer"]))]=layer_use_counts.get(str(int(v["layer"])),0)+1

    print("========== ZANT-LLM v6.13 SEMANTIC-FAMILY MIXTURE RECONSTRUCTION ==========")
    print("NO_TRAINING=True")
    print("NO_NEW_RULES=True")
    print("SOURCE_V6_12_COMPLETE=True")
    print("SOURCE_V6_12_PASS=0/20")
    print("SOURCE_V6_12_FIRST_TOKEN_MEAN_RANK=59.85")
    print("SOURCE_V6_12_POS_NEG_WINS=7/20")
    print("SOURCE_V6_12_LANGUAGE_SPECIALIZED_ROUTING=False")
    print("SOURCE_V6_12_SAME_TEXT_AS_V6_10=20/20")
    print("SOURCE_V6_11_SCAN_ROWS=700")
    print("RECONSTRUCTION_AXIS=SEMANTIC_FAMILY")
    print("RETAINED_HOLDOUT_EVALUATED=False")
    print("NO_GITHUB_PUSH=True")

    for fam in sorted(family_plan):
        x=family_plan[fam]
        print(
            "FAMILY="+fam+
            " BEST_LAYER="+str(x["layer"])+
            " WINS="+str(x["positive_vs_negative_win_count"])+"/"+str(x["rows"])+
            " TOP32="+str(x["top32_count"])+"/"+str(x["rows"])+
            " MEAN_RANK="+str(x["mean_rank"])+
            " MEAN_MARGIN="+str(x["mean_margin"])
        )

    if usable64>=16 and wins>=16:
        cls="SEMANTIC_FAMILY_LAYER_MIXTURE_RECOVERS_USABLE_CRITERION_ALIGNED_SIGNAL"
        nxt="v6.14-family-mixture-router-bridge-training-milestone"
        auth=True
    elif wins>=16 and top32>=8:
        cls="SEMANTIC_FAMILY_LAYER_MIXTURE_RECOVERS_RELATIVE_SIGNAL_WITH_PARTIAL_ABSOLUTE_ACCESS"
        nxt="v6.14-family-mixture-projection-training-milestone"
        auth=True
    elif wins>=16:
        cls="SEMANTIC_FAMILY_RELATIVE_SIGNAL_EXISTS_BUT_ABSOLUTE_TOKEN_ACCESS_REMAINS_WEAK"
        nxt="v6.14-semantic-family-output-projection-redesign-milestone"
        auth=False
    else:
        cls="SEMANTIC_FAMILY_LAYER_MIXTURE_INSUFFICIENT"
        nxt="v6.14-semantic-state-reconstruction-milestone"
        auth=False

    work=root/"diagnostics/v6_13_semantic_family_mixture_reconstruction_milestone"
    work.mkdir(parents=True,exist_ok=True)
    planp=work/"v6_13_semantic_family_layer_plan.json"
    summaryp=work/"v6_13_milestone_summary.json"
    selectedp=work/"v6_13_selected_family_layer_rows.jsonl"

    writel(selectedp,selected_rows)
    writej(planp,{
        "schema":"ZANT_LLM_V6_13_SEMANTIC_FAMILY_LAYER_PLAN_V1",
        "family_plan":family_plan,
        "distinct_selected_layers":distinct_layers,
        "selected_layer_use_counts":layer_use_counts,
        "family_plan_positive_vs_negative_win_count":wins,
        "family_plan_top10_count":top10,
        "family_plan_top32_count":top32,
        "family_plan_top64_count":top64,
        "family_plan_usable_rank64_and_win_count":usable64,
        "family_plan_mean_rank":mean_rank,
        "family_plan_mean_margin":mean_margin,
        "best_global_layer":best_global,
        "classification":cls,
        "training_authorized":auth,
        "next_milestone":nxt,
        "retained_holdout_evaluated":False,
    })
    writej(summaryp,{
        "schema":"ZANT_LLM_V6_13_SEMANTIC_FAMILY_MIXTURE_RECONSTRUCTION_MILESTONE_V1",
        "milestone_complete":True,
        "no_training":True,
        "source_v6_12_complete":True,
        "source_v6_12_anchor_pass_count":0,
        "source_v6_12_first_token_mean_rank":59.85,
        "source_v6_12_positive_vs_negative_win_count":7,
        "source_v6_12_language_specialized_routing_observed":False,
        "source_v6_12_same_text_as_v6_10_rows":20,
        "family_count":len(family_plan),
        "distinct_selected_layers":distinct_layers,
        "family_plan_positive_vs_negative_win_count":wins,
        "family_plan_top10_count":top10,
        "family_plan_top32_count":top32,
        "family_plan_top64_count":top64,
        "family_plan_usable_rank64_and_win_count":usable64,
        "family_plan_mean_rank":mean_rank,
        "family_plan_mean_margin":mean_margin,
        "milestone_status":cls,
        "training_authorized":auth,
        "retained_holdout_opened":False,
        "next_milestone":nxt,
        "github_push_performed":False,
    })

    print("========== V6.13 MILESTONE FINAL ==========")
    print("V6_13_MILESTONE_COMPLETE=True")
    print("NO_TRAINING=True")
    print("SEMANTIC_FAMILY_COUNT="+str(len(family_plan)))
    print("DISTINCT_SELECTED_LAYERS="+json.dumps(distinct_layers))
    print("FAMILY_PLAN_POSITIVE_VS_NEGATIVE_WIN_COUNT="+str(wins)+"/20")
    print("FAMILY_PLAN_TOP10_COUNT="+str(top10)+"/20")
    print("FAMILY_PLAN_TOP32_COUNT="+str(top32)+"/20")
    print("FAMILY_PLAN_TOP64_COUNT="+str(top64)+"/20")
    print("FAMILY_PLAN_USABLE_RANK64_AND_WIN_COUNT="+str(usable64)+"/20")
    print("FAMILY_PLAN_MEAN_RANK="+str(mean_rank))
    print("FAMILY_PLAN_MEAN_MARGIN="+str(mean_margin))
    print("TRAINING_AUTHORIZED="+str(auth))
    print("RETAINED_HOLDOUT_OPENED=False")
    print("MILESTONE_STATUS="+cls)
    print("PLAN_SHA256="+sha(planp))
    print("FINAL_SUMMARY_SHA256="+sha(summaryp))
    print("NEXT_MILESTONE="+nxt)
    print("GITHUB_PUSH_PERFORMED=False")

if __name__=="__main__":
    main()
