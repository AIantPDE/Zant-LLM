Zant-LLM v6.13 — Semantic-Family Mixture Reconstruction Milestone

Authoritative v6.12 result
--------------------------
v6.12 is COMPLETE / CLOSED.

Training itself succeeded:
- source layers = 7 / 32
- trainable params = 396,290
- optimizer steps = 20

But the learned router did not specialize by language:
- EN layer7 gate  = 0.0277
- EN layer32 gate = 0.9724
- ZH layer7 gate  = 0.1689
- ZH layer32 gate = 0.8310

Anchor result:
- PASS = 0/20
- HIT_MAX = 10
- first-token TOP1 = 0/20
- first-token mean rank = 59.85
- positive-vs-negative wins = 7/20
- mean positive-minus-negative first-token logit = -1.4642
- same generated text as v6.10 = 20/20

Diagnosis:
BILINGUAL_DUAL_SOURCE_SEMANTIC_BRIDGE_INSUFFICIENT

Purpose of v6.13
----------------
v6.11 showed that semantic signal localization differs across the decoder stack.
v6.12 compressed that into a language-only split (English layer7, Chinese
layer32), but the learned gate collapsed toward layer32 for both languages.

v6.13 therefore removes the language-level assumption and reconstructs the
source mixture by SEMANTIC FAMILY.

v6.13 performs NO TRAINING and does not touch retained holdout20.

It reuses the complete 20x35 layer scan produced by v6.11:
- 20 anchors
- 35 text layers
- 700 criterion-aligned layer observations

For every semantic family, v6.13 selects the layer that best balances:
1. criterion-valid positive first-token beating the audited negative first token;
2. TOP32 / TOP64 absolute token access;
3. mean positive-token rank;
4. positive-minus-negative logit margin.

The resulting family plan is an ORACLE DIAGNOSTIC PLAN ONLY.
It is not a hard-coded inference rule.

If family-level layer selection restores sufficient usable signal, v6.14 will
train a learned router/bridge so production inference does not need explicit
family labels.

Automatic v6.14 route
---------------------
>=16/20 rows have rank<=64 AND positive>negative:
  -> v6.14 family-mixture router bridge training

>=16/20 positive-vs-negative wins and >=8/20 TOP32:
  -> v6.14 family-mixture projection training

>=16/20 relative wins but poor absolute access:
  -> v6.14 semantic-family output-projection redesign

Otherwise:
  -> v6.14 semantic-state reconstruction

No GitHub push.
