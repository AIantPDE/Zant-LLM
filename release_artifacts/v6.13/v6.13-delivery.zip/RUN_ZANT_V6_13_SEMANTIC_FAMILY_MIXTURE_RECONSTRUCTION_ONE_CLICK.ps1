$ErrorActionPreference = "Stop"

$ROOT = "C:\Users\Administrator\Desktop\Zant-LLM"
$PYTHON = "C:\Users\Administrator\AppData\Local\Programs\Python\Python311\python.exe"

$V612_REPORT = Join-Path $ROOT "diagnostics\v6_12_bilingual_dual_source_semantic_bridge_milestone\v6_12_anchor20_report.json"
$V612_ANALYSIS = Join-Path $ROOT "diagnostics\v6_12_bilingual_dual_source_semantic_bridge_milestone\v6_12_milestone_analysis.json"
$V612_SUMMARY = Join-Path $ROOT "diagnostics\v6_12_bilingual_dual_source_semantic_bridge_milestone\v6_12_milestone_summary.json"

$V611_DETAIL = Join-Path $ROOT "diagnostics\v6_11_semantic_representation_family_redesign_milestone\v6_11_layer_logit_lens_detail.jsonl"
$V611_LAYER_SUMMARY = Join-Path $ROOT "diagnostics\v6_11_semantic_representation_family_redesign_milestone\v6_11_layer_logit_lens_summary.json"
$V611_PLAN = Join-Path $ROOT "diagnostics\v6_11_semantic_representation_family_redesign_milestone\v6_11_representation_redesign_plan.json"
$V611_SUMMARY = Join-Path $ROOT "diagnostics\v6_11_semantic_representation_family_redesign_milestone\v6_11_milestone_summary.json"

$V69_REPORT = Join-Path $ROOT "diagnostics\v6_9_semantic_criterion_and_target_family_redesign_milestone\v6_9_semantic_criterion_report.json"
$V69_FAMILY = Join-Path $ROOT "full_training\v6_9_semantic_criterion_and_target_family_redesign\v6_9_target_family_candidates_20.jsonl"

$ORCH = Join-Path $ROOT "full_training\run_v6_13_semantic_family_mixture_reconstruction_milestone.py"
$WORKER = Join-Path $ROOT "full_training\v6_13_internal\run_v6_13_semantic_family_mixture_reconstruction.py"

Write-Host "========== ZANT-LLM v6.13 SEMANTIC-FAMILY MIXTURE RECONSTRUCTION =========="
Write-Host "NO_TRAINING=True"
Write-Host "NO_NEW_RULES=True"
Write-Host "SOURCE_V6_12_COMPLETE=True"
Write-Host "SOURCE_V6_12_PASS=0/20"
Write-Host "SOURCE_V6_12_FIRST_TOKEN_MEAN_RANK=59.85"
Write-Host "SOURCE_V6_12_POS_NEG_WINS=7/20"
Write-Host "SOURCE_V6_12_LANGUAGE_SPECIALIZED_ROUTING=False"
Write-Host "SOURCE_V6_12_SAME_TEXT_AS_V6_10=20/20"
Write-Host "RECONSTRUCTION_AXIS=SEMANTIC_FAMILY"
Write-Host "RETAINED_HOLDOUT_EVALUATED=False"
Write-Host "NO_GITHUB_PUSH=True"

foreach ($p in @($PYTHON,$V612_REPORT,$V612_ANALYSIS,$V612_SUMMARY,$V611_DETAIL,$V611_LAYER_SUMMARY,$V611_PLAN,$V611_SUMMARY,$V69_REPORT,$V69_FAMILY,$ORCH,$WORKER)) {
    if (!(Test-Path $p)) { throw "Required path not found: $p" }
}

& $PYTHON $ORCH `
    --root $ROOT `
    --v612-report $V612_REPORT `
    --v612-analysis $V612_ANALYSIS `
    --v612-summary $V612_SUMMARY `
    --v611-detail $V611_DETAIL `
    --v611-layer-summary $V611_LAYER_SUMMARY `
    --v611-plan $V611_PLAN `
    --v611-summary $V611_SUMMARY `
    --v69-report $V69_REPORT `
    --v69-family $V69_FAMILY `
    --worker $WORKER

$exit=$LASTEXITCODE
Write-Host "V6_13_PROCESS_EXIT=$exit"
if ($exit -ne 0) { throw "v6.13 milestone failed (exit=$exit)" }
Write-Host "========== v6.13 ONE-CLICK DONE =========="
