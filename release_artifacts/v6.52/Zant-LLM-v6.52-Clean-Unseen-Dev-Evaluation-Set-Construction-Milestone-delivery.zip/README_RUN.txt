Zant-LLM v6.52
Clean Unseen-Dev Evaluation Set Construction Milestone
=======================================================

SOURCE v6.51
------------
v6.51 completed successfully:

  UNSEEN_DEV_AVAILABLE=False
  UNSEEN_DEV_CASES=0
  RUNTIME_ROBUSTNESS_PASS=True

Final v6.51 status:

  RUNTIME_IS_ROBUST_BUT_NO_CLEAN_UNSEEN_DEV_SET_IS_AVAILABLE

Selected v6.52 objective:

  ZERO_TRAIN_CALIBRATION_OVERLAP
  + LABELED_UNSEEN_DEV
  + LANGUAGE_FAMILY_COVERAGE
  + RUNTIME_EVAL


PURPOSE
-------
v6.52 does NOT change the model.

The missing component is now evaluation data, not runtime behavior.

v6.52 therefore:

  1. searches existing project source files more deeply than v6.51;

  2. requires explicit eval/dev/validation/test metadata either in the path
     OR in row-level fields such as split/role/subset/usage;

  3. excludes all explicit train/training and retained/holdout sources;

  4. excludes every v6.44 train + anchor source ID;

  5. excludes every exact normalized prompt overlap;

  6. excludes every prompt+target-token signature overlap;

  7. balances selected cases across language and task family;

  8. if enough clean cases exist, immediately evaluates BASELINE vs GATED
     without recalibrating the gate.


NO MODEL TRAINING
-----------------
NO_MODEL_TRAINING=True

No base-model change.

No bridge change.

No gate change.

No v6.31 controller change.

Retained holdout remains CLOSED.

No GitHub push.


WHY v6.52 SEARCHES MORE DEEPLY THAN v6.51
-----------------------------------------
v6.51 required an eval/dev/test signal in the FILE PATH.

That found zero cases.

v6.52 additionally accepts rows where the file has a generic name but the ROW
itself explicitly declares an evaluation role, for example:

  split = dev

  split = validation

  source_role = evaluation

  subset = test

It still rejects:

  train
  training
  retained
  holdout


SUPPORTED SOURCE FORMATS
------------------------
v6.52 scans:

  *.jsonl

  *.json

JSON may contain a top-level list or a list under:

  rows
  data
  examples
  cases
  items
  records


REQUIRED CASE CONTENT
---------------------
Prompt may be stored as:

  prompt
  input
  instruction
  query
  question
  user

Target may be stored as:

  target_token_ids

or labeled text under:

  target_text
  target
  answer
  response
  completion
  canonical_target
  expected
  output


ZERO-OVERLAP GOVERNANCE
-----------------------
Every selected case must pass:

  source_row_id overlap with v6.44 = 0

  normalized prompt overlap with v6.44 = 0

  prompt + target-token signature overlap with v6.44 = 0

This covers both:

  80 v6.44 training source rows

and:

  20 anchor calibration/validation source rows

v6.46 on-policy data came from the same 80 train sources, and v6.49/v6.50
calibration came from the same 20 anchors, so these exclusions cover the
current controlled-generation train/calibration lineage.


TARGET SET SIZE
---------------
Target:

  24 clean cases

Maximum:

  40

Minimum for runtime evaluation:

  8

Minimum for dataset-ready classification:

  12


LANGUAGE + FAMILY COVERAGE
--------------------------
Selection is round-robin across:

  language

  task family

Language is taken from metadata when available, otherwise inferred from the
prompt.

Family is taken from fields such as:

  family
  category
  task
  task_type
  type
  topic
  domain
  source_family


RUNTIME EVALUATION
------------------
If at least 8 clean cases are constructed, v6.52 immediately runs:

  BASELINE

vs

  GATED v6.50 runtime

The gate is NOT recalibrated.

Metrics include:

  token matches

  first-token matches

  exact sequences

  gated token gain

  gated first-token gain

  latency ratio

  peak-memory delta


OUTPUT DIRECTORY
----------------
full_training\
v6_52_clean_unseen_dev_evaluation_set\

  v6_52_clean_unseen_dev.jsonl

  v6_52_candidate_audit.json

  v6_52_dataset_manifest.json

  v6_52_runtime_eval_detail.jsonl

  v6_52_runtime_eval_report.json

  v6_52_construction_report.json

  v6_52_milestone_analysis.json

  v6_52_milestone_summary.json


AUTOMATIC v6.53 ROUTING
-----------------------
A. Clean set is ready, language/family coverage is sufficient, and gated
   runtime generalizes:

  v6.53-broader-generalization-and-retained-holdout-readiness-review-milestone


B. Clean set is ready but unseen runtime gain is positive and weak:

  v6.53-unseen-dev-failure-topology-and-gate-transfer-milestone


C. Clean set is ready but gated runtime does not generalize:

  v6.53-generalization-representation-and-runtime-gate-redesign-milestone


D. Some clean cases exist but language/family coverage is insufficient:

  v6.53-clean-unseen-dev-language-family-coverage-augmentation-milestone


E. Some cases exist but the set is too small:

  v6.53-clean-unseen-dev-source-expansion-milestone


F. No existing project source can provide any clean unseen-dev case:

  v6.53-external-clean-unseen-dev-data-authoring-and-import-milestone


IMPORTANT
---------
A zero-case result is a valid data-governance conclusion.

v6.52 will not silently recycle v6.44 training or the 20 anchors and call them
"unseen".

It also will not open the retained holdout to fill the gap.


RUN
---
Extract into:

  C:\Users\Administrator\Desktop\Zant-LLM

Then run:

  powershell.exe -ExecutionPolicy Bypass -File "C:\Users\Administrator\Desktop\Zant-LLM\RUN_ZANT_V6_52_CLEAN_UNSEEN_DEV_EVALUATION_SET_CONSTRUCTION_ONE_CLICK.ps1"
