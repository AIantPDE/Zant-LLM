$ErrorActionPreference = "Stop"

$ROOT = "C:\Users\Administrator\Desktop\Zant-LLM"
$PY = "C:\Users\Administrator\AppData\Local\Programs\Python\Python311\python.exe"
$BASE_MODEL = "E:\gemma-4-E2B-it"

$SOURCE_ADAPTER = Join-Path $ROOT "artifacts\Zant-LLM-v5_9_25-first-token-logit-margin-rank16-adapter"
$V67_PATCH = Join-Path $ROOT "artifacts\Zant-LLM-v6_7-reconstructed-canonical-target-alignment-pilot"
$RUNNER = Join-Path $ROOT "full_training\run_v6_52_clean_unseen_dev_evaluation_set_construction_milestone.py"

$env:CUDA_LAUNCH_BLOCKING = "1"

Write-Host "========== ZANT-LLM v6.52 CLEAN UNSEEN-DEV CONSTRUCTION =========="
Write-Host "NO_MODEL_TRAINING=True"
Write-Host "SOURCE_V6_51_COMPLETE=True"
Write-Host "SOURCE_RUNTIME_ROBUSTNESS_PASS=True"
Write-Host "SOURCE_UNSEEN_DEV_AVAILABLE=False"
Write-Host "OBJECTIVE=ZERO_TRAIN_CALIBRATION_OVERLAP+LABELED_UNSEEN_DEV+LANGUAGE_FAMILY_COVERAGE+RUNTIME_EVAL"
Write-Host "CUDA_LAUNCH_BLOCKING=1"
Write-Host "RETAINED_HOLDOUT_EVALUATED=False"
Write-Host "NO_GITHUB_PUSH=True"

if (!(Test-Path $PY)) { throw "Python not found: $PY" }
if (!(Test-Path $RUNNER)) { throw "v6.52 runner not found: $RUNNER" }
if (!(Test-Path $BASE_MODEL)) { throw "Base model not found: $BASE_MODEL" }
if (!(Test-Path $SOURCE_ADAPTER)) { throw "Source adapter not found: $SOURCE_ADAPTER" }
if (!(Test-Path $V67_PATCH)) { throw "v6.7 patch not found: $V67_PATCH" }

& $PY $RUNNER `
  --root $ROOT `
  --base-model $BASE_MODEL `
  --source-adapter $SOURCE_ADAPTER `
  --v67-patch $V67_PATCH

$exit = $LASTEXITCODE

Write-Host ("V6_52_PROCESS_EXIT=" + $exit)

if ($exit -ne 0) {
    throw "v6.52 milestone failed (exit=$exit)"
}

Write-Host "========== v6.52 ONE-CLICK DONE =========="
