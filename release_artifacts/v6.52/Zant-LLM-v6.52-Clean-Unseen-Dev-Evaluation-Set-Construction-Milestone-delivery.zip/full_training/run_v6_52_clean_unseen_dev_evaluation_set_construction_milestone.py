from pathlib import Path
import argparse
import subprocess
import sys


def run(cmd):
    print(
        "RUN="
        + " ".join(
            str(x)
            for x in cmd
        ),
        flush=True,
    )

    p = subprocess.run(
        cmd
    )

    if p.returncode != 0:
        raise SystemExit(
            p.returncode
        )


def main():
    ap = argparse.ArgumentParser()

    ap.add_argument(
        "--root",
        required=True,
    )

    ap.add_argument(
        "--base-model",
        required=True,
    )

    ap.add_argument(
        "--source-adapter",
        required=True,
    )

    ap.add_argument(
        "--v67-patch",
        required=True,
    )

    args = ap.parse_args()

    root = Path(
        args.root
    )

    py = sys.executable

    internal = (
        root
        / "full_training"
        / "v6_52_internal"
    )

    runtime = (
        root
        / "full_training"
        / "v6_36_internal"
        / "runtime_v6_36.py"
    )

    v624_script = (
        root
        / "full_training"
        / "v6_36_internal"
        / "controller_v6_24_frozen.py"
    )

    joint_script = (
        root
        / "full_training"
        / "v6_36_internal"
        / "controller_v6_29_joint.py"
    )

    reference_script = (
        internal
        / "reference_v6_49_runtime.py"
    )

    v650_runtime = (
        internal
        / "runtime_v6_50_controlled_generation.py"
    )

    output_dir = (
        root
        / "full_training"
        / "v6_52_clean_unseen_dev_evaluation_set"
    )

    construction_report = (
        output_dir
        / "v6_52_construction_report.json"
    )

    print(
        "========== ZANT-LLM v6.52 CLEAN UNSEEN-DEV CONSTRUCTION =========="
    )

    print(
        "NO_MODEL_TRAINING=True"
    )

    print(
        "SOURCE_V6_51_COMPLETE=True"
    )

    print(
        "SOURCE_RUNTIME_ROBUSTNESS_PASS=True"
    )

    print(
        "SOURCE_UNSEEN_DEV_AVAILABLE=False"
    )

    print(
        "OBJECTIVE=ZERO_TRAIN_CALIBRATION_OVERLAP+LABELED_UNSEEN_DEV+LANGUAGE_FAMILY_COVERAGE+RUNTIME_EVAL"
    )

    print(
        "RETAINED_HOLDOUT_EVALUATED=False"
    )

    print(
        "NO_GITHUB_PUSH=True"
    )

    run(
        [
            py,
            str(
                internal
                / "build_and_eval_v6_52_clean_unseen_dev.py"
            ),
            "--root",
            str(
                root
            ),
            "--base-model",
            args.base_model,
            "--source-adapter",
            args.source_adapter,
            "--v67-patch",
            args.v67_patch,
            "--runtime-script",
            str(
                runtime
            ),
            "--v624-controller-script",
            str(
                v624_script
            ),
            "--joint-controller-script",
            str(
                joint_script
            ),
            "--reference-runtime-script",
            str(
                reference_script
            ),
            "--v650-runtime-script",
            str(
                v650_runtime
            ),
            "--output-dir",
            str(
                output_dir
            ),
        ]
    )

    run(
        [
            py,
            str(
                internal
                / "route_v6_52.py"
            ),
            "--report",
            str(
                construction_report
            ),
            "--runtime-script",
            str(
                runtime
            ),
            "--output-dir",
            str(
                output_dir
            ),
        ]
    )

    print(
        "V6_52_PROCESS_EXIT=0"
    )

    print(
        "========== v6.52 ONE-CLICK DONE =========="
    )


if __name__ == "__main__":
    main()
