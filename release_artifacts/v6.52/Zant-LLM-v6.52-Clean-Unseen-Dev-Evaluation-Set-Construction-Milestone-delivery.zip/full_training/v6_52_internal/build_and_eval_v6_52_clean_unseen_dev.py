from pathlib import Path
import argparse
import importlib.util
import hashlib
import json
import time
import gc
import re
from collections import Counter, defaultdict

EXPECTED_V651_REPORT_SHA = "dae48da7c21ef1add993367ac8456bf060da5edbd24b504d93056a79e8e28a15"
EXPECTED_V651_ANALYSIS_SHA = "cc5642c31d73d5d7b908bcff735b0ab167751cb60b9111764c86e138407e23cf"
EXPECTED_V651_SUMMARY_SHA = "71530aa448aa0fb2dcd33d40b2355ed7ded2c9b74f5e8e07c2a102f2b2190fc8"
EXPECTED_V650_BUNDLE_SHA = "53ba47a6cf1db43da713e09b5bc11fd533b1e949dfac0aec112679d2444d0944"

TARGET_CASES = 24
MAX_CASES = 40
MIN_EVAL_CASES = 8
MIN_READY_CASES = 12
MAX_NEW_TOKENS = 8

PROMPT_KEYS = (
    "prompt",
    "input",
    "instruction",
    "query",
    "question",
    "user",
)

TARGET_TEXT_KEYS = (
    "target_text",
    "target",
    "answer",
    "response",
    "completion",
    "canonical_target",
    "expected",
    "output",
)

ID_KEYS = (
    "source_row_id",
    "case_id",
    "id",
    "example_id",
    "sample_id",
    "row_id",
)

SPLIT_KEYS = (
    "split",
    "source_split",
    "role",
    "source_role",
    "subset",
    "usage",
    "partition",
    "set",
    "purpose",
)

LANG_KEYS = (
    "language",
    "lang",
    "locale",
)

FAMILY_KEYS = (
    "family",
    "category",
    "task",
    "task_type",
    "type",
    "topic",
    "domain",
    "source_family",
)

POSITIVE_EVAL_TERMS = (
    "eval",
    "evaluation",
    "dev",
    "validation",
    "valid",
    "test",
    "benchmark",
)

NEGATIVE_SPLIT_TERMS = (
    "train",
    "training",
    "retained",
    "holdout",
)

PATH_HARD_EXCLUDES = (
    "/artifacts/",
    "/diagnostics/",
    "/.git/",
    "/__pycache__/",
    "/v6_44_dedicated_transition_supervision_dataset/",
    "/v6_46_free_run_transition_context_dataset/",
    "/v6_47_",
    "/v6_48_",
    "/v6_49_",
    "/v6_50_",
    "/v6_51_",
)

RETAINED_TERMS = (
    "retained",
    "holdout",
    "final_holdout",
)


def load_module(path, name):
    spec = importlib.util.spec_from_file_location(
        name,
        str(path),
    )
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def write_json(path, obj):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        json.dumps(
            obj,
            ensure_ascii=False,
            indent=2,
        )
        + "\n",
        encoding="utf-8",
        newline="\n",
    )


def write_jsonl(path, rows):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)

    with path.open(
        "w",
        encoding="utf-8",
        newline="\n",
    ) as f:
        for row in rows:
            f.write(
                json.dumps(
                    row,
                    ensure_ascii=False,
                    separators=(",", ":"),
                )
                + "\n"
            )


def read_jsonl(path):
    rows = []

    with Path(path).open(
        "r",
        encoding="utf-8",
        errors="replace",
    ) as f:
        for line in f:
            if not line.strip():
                continue

            try:
                obj = json.loads(line)
            except Exception:
                continue

            if isinstance(obj, dict):
                rows.append(obj)

    return rows


def read_json_rows(path):
    try:
        obj = json.loads(
            Path(path).read_text(
                encoding="utf-8",
                errors="replace",
            )
        )
    except Exception:
        return []

    if isinstance(obj, list):
        return [
            x
            for x in obj
            if isinstance(x, dict)
        ]

    if isinstance(obj, dict):
        for key in (
            "rows",
            "data",
            "examples",
            "cases",
            "items",
            "records",
        ):
            value = obj.get(key)

            if isinstance(value, list):
                return [
                    x
                    for x in value
                    if isinstance(x, dict)
                ]

    return []


def normalize_text(text):
    return " ".join(
        str(text).strip().split()
    )


def sha256_text(text):
    return hashlib.sha256(
        text.encode("utf-8")
    ).hexdigest()


def first_present(row, keys):
    for key in keys:
        value = row.get(key)

        if value is not None:
            return value

    return None


def normalize_path(path):
    return (
        "/"
        + str(path)
        .replace("\\", "/")
        .lower()
        .lstrip("/")
    )


def path_is_forbidden(path):
    text = normalize_path(path)

    if any(
        term in text
        for term in RETAINED_TERMS
    ):
        return True

    if any(
        term in text
        for term in PATH_HARD_EXCLUDES
    ):
        return True

    # Construction may inspect generic source files, but never a path that is
    # explicitly a training corpus.
    components = [
        x
        for x in text.split("/")
        if x
    ]

    for part in components:
        if part in (
            "train",
            "training",
            "train_data",
            "training_data",
        ):
            return True

        if part.startswith(
            "train_"
        ) or part.startswith(
            "training_"
        ):
            return True

    return False


def row_eval_signal(row, path):
    values = []

    for key in SPLIT_KEYS:
        value = row.get(key)

        if value is not None:
            values.append(
                str(value).lower()
            )

    merged = " ".join(values)

    if any(
        term in merged
        for term in NEGATIVE_SPLIT_TERMS
    ):
        return False, "row_split_rejected"

    if any(
        term in merged
        for term in POSITIVE_EVAL_TERMS
    ):
        return True, "row_metadata"

    path_text = normalize_path(path)

    if any(
        term in path_text
        for term in POSITIVE_EVAL_TERMS
    ):
        return True, "path_metadata"

    return False, "no_explicit_eval_signal"


def infer_language(row, prompt):
    for key in LANG_KEYS:
        value = row.get(key)

        if value is None:
            continue

        s = str(value).strip().lower()

        if s in (
            "zh",
            "zh-cn",
            "zh_cn",
            "chinese",
            "cn",
        ) or "chinese" in s:
            return "zh"

        if s in (
            "en",
            "en-us",
            "en_us",
            "english",
        ) or "english" in s:
            return "en"

        if s:
            return s[:24]

    cjk = len(
        re.findall(
            r"[\u4e00-\u9fff]",
            prompt,
        )
    )

    latin = len(
        re.findall(
            r"[A-Za-z]",
            prompt,
        )
    )

    if cjk >= max(
        2,
        latin // 4,
    ):
        return "zh"

    if latin > 0:
        return "en"

    return "unknown"


def infer_family(row):
    for key in FAMILY_KEYS:
        value = row.get(key)

        if value is None:
            continue

        s = normalize_text(
            value
        ).lower()

        if s:
            return s[:64]

    return "unknown"


def extract_case(
    tok,
    row,
    source_path,
    row_index,
):
    prompt = first_present(
        row,
        PROMPT_KEYS,
    )

    if not isinstance(
        prompt,
        str,
    ):
        return None, "missing_prompt"

    prompt = normalize_text(
        prompt
    )

    if not prompt:
        return None, "empty_prompt"

    raw_id = first_present(
        row,
        ID_KEYS,
    )

    if raw_id is None:
        raw_id = (
            source_path.name
            + "::"
            + str(row_index)
        )

    target_ids = row.get(
        "target_token_ids"
    )

    target_text = first_present(
        row,
        TARGET_TEXT_KEYS,
    )

    tids = []

    if isinstance(
        target_ids,
        list,
    ) and target_ids:
        try:
            tids = [
                int(x)
                for x in target_ids
            ]
        except Exception:
            tids = []

    if not tids:
        if not isinstance(
            target_text,
            str,
        ):
            return None, "missing_target"

        target_text = normalize_text(
            target_text
        )

        if not target_text:
            return None, "empty_target"

        tids = [
            int(x)
            for x in tok(
                target_text,
                add_special_tokens=False,
            ).input_ids
        ]

    if not tids:
        return None, "empty_target_tokens"

    target_text_norm = (
        normalize_text(
            target_text
        )
        if isinstance(
            target_text,
            str,
        )
        else ""
    )

    signature_payload = (
        prompt
        + "\n"
        + ",".join(
            str(x)
            for x in tids
        )
    )

    return {
        "schema": "ZANT_LLM_V6_52_CLEAN_UNSEEN_DEV_CASE_V1",
        "case_id": str(raw_id),
        "source_row_id": str(raw_id),
        "source_path": str(source_path),
        "source_row_index": int(row_index),
        "prompt": prompt,
        "target_text": target_text_norm,
        "target_token_ids": tids[
            :MAX_NEW_TOKENS
        ],
        "full_target_token_count": int(
            len(tids)
        ),
        "language": infer_language(
            row,
            prompt,
        ),
        "family": infer_family(
            row
        ),
        "prompt_sha256": sha256_text(
            prompt
        ),
        "prompt_target_signature": sha256_text(
            signature_payload
        ),
        "do_not_train": True,
        "retained_holdout": False,
    }, "ok"


def build_exclusion_sets(
    train_rows,
    anchor_rows,
):
    rows = train_rows + anchor_rows

    ids = set()
    prompts = set()
    signatures = set()

    for row in rows:
        sid = row.get(
            "source_row_id"
        )

        if sid is not None:
            ids.add(
                str(sid)
            )

        prompt = row.get(
            "prompt"
        )

        tids = row.get(
            "target_token_ids"
        )

        if isinstance(
            prompt,
            str,
        ):
            p = normalize_text(
                prompt
            )
            prompts.add(
                sha256_text(
                    p
                )
            )

            if isinstance(
                tids,
                list,
            ):
                payload = (
                    p
                    + "\n"
                    + ",".join(
                        str(
                            int(x)
                        )
                        for x in tids
                    )
                )

                signatures.add(
                    sha256_text(
                        payload
                    )
                )

    return ids, prompts, signatures


def discover_candidates(
    root,
    tok,
    excluded_ids,
    excluded_prompt_hashes,
    excluded_signatures,
):
    accepted = []
    audit = {
        "files_scanned": 0,
        "files_with_explicit_eval_rows": 0,
        "rows_seen": 0,
        "accepted_before_dedup": 0,
        "rejection_counts": Counter(),
        "accepted_files": [],
    }

    paths = sorted(
        list(
            root.rglob(
                "*.jsonl"
            )
        )
        + list(
            root.rglob(
                "*.json"
            )
        )
    )

    for path in paths:
        if path_is_forbidden(
            path
        ):
            continue

        try:
            if (
                path.stat().st_size
                <= 0
                or path.stat().st_size
                > 64
                * 1024
                * 1024
            ):
                continue
        except Exception:
            continue

        audit[
            "files_scanned"
        ] += 1

        if path.suffix.lower() == ".jsonl":
            rows = read_jsonl(
                path
            )
        else:
            rows = read_json_rows(
                path
            )

        if not rows:
            continue

        accepted_here = 0

        for idx, row in enumerate(
            rows
        ):
            audit[
                "rows_seen"
            ] += 1

            explicit_eval, signal = row_eval_signal(
                row,
                path,
            )

            if not explicit_eval:
                audit[
                    "rejection_counts"
                ][signal] += 1
                continue

            case, reason = extract_case(
                tok,
                row,
                path,
                idx,
            )

            if case is None:
                audit[
                    "rejection_counts"
                ][reason] += 1
                continue

            if case[
                "source_row_id"
            ] in excluded_ids:
                audit[
                    "rejection_counts"
                ][
                    "source_id_overlap"
                ] += 1
                continue

            if case[
                "prompt_sha256"
            ] in excluded_prompt_hashes:
                audit[
                    "rejection_counts"
                ][
                    "prompt_overlap"
                ] += 1
                continue

            if case[
                "prompt_target_signature"
            ] in excluded_signatures:
                audit[
                    "rejection_counts"
                ][
                    "prompt_target_overlap"
                ] += 1
                continue

            case[
                "eval_signal"
            ] = signal

            accepted.append(
                case
            )
            accepted_here += 1

        if accepted_here:
            audit[
                "files_with_explicit_eval_rows"
            ] += 1

            audit[
                "accepted_files"
            ].append(
                {
                    "path": str(
                        path
                    ),
                    "accepted_rows": int(
                        accepted_here
                    ),
                }
            )

    audit[
        "accepted_before_dedup"
    ] = len(
        accepted
    )

    # Strict dedup by source row id, prompt, and prompt+target.
    unique = []
    seen_ids = set()
    seen_prompts = set()
    seen_signatures = set()

    for case in accepted:
        if case[
            "source_row_id"
        ] in seen_ids:
            audit[
                "rejection_counts"
            ][
                "dedup_source_id"
            ] += 1
            continue

        if case[
            "prompt_sha256"
        ] in seen_prompts:
            audit[
                "rejection_counts"
            ][
                "dedup_prompt"
            ] += 1
            continue

        if case[
            "prompt_target_signature"
        ] in seen_signatures:
            audit[
                "rejection_counts"
            ][
                "dedup_signature"
            ] += 1
            continue

        seen_ids.add(
            case[
                "source_row_id"
            ]
        )
        seen_prompts.add(
            case[
                "prompt_sha256"
            ]
        )
        seen_signatures.add(
            case[
                "prompt_target_signature"
            ]
        )

        unique.append(
            case
        )

    audit[
        "accepted_after_dedup"
    ] = len(
        unique
    )

    audit[
        "rejection_counts"
    ] = dict(
        audit[
            "rejection_counts"
        ]
    )

    return unique, audit


def balanced_select(
    candidates,
    target_cases=TARGET_CASES,
    max_cases=MAX_CASES,
):
    if not candidates:
        return []

    # Deterministic buckets by language+family. Round-robin selection prevents
    # one large source family from dominating the new dev set.
    buckets = defaultdict(
        list
    )

    for case in sorted(
        candidates,
        key=lambda x: (
            x[
                "language"
            ],
            x[
                "family"
            ],
            x[
                "source_path"
            ],
            x[
                "source_row_id"
            ],
        ),
    ):
        buckets[
            (
                case[
                    "language"
                ],
                case[
                    "family"
                ],
            )
        ].append(
            case
        )

    keys = sorted(
        buckets.keys()
    )

    selected = []
    index = 0

    while (
        len(
            selected
        )
        < min(
            target_cases,
            max_cases,
            len(
                candidates
            ),
        )
        and keys
    ):
        key = keys[
            index
            % len(
                keys
            )
        ]

        bucket = buckets[
            key
        ]

        if bucket:
            selected.append(
                bucket.pop(
                    0
                )
            )

        keys = [
            k
            for k in keys
            if buckets[
                k
            ]
        ]

        if not keys:
            break

        index += 1

    return selected


def coverage_summary(
    rows,
):
    lang = Counter(
        r[
            "language"
        ]
        for r in rows
    )

    family = Counter(
        r[
            "family"
        ]
        for r in rows
    )

    known_families = [
        k
        for k in family
        if k
        != "unknown"
    ]

    zh = int(
        lang.get(
            "zh",
            0,
        )
    )

    en = int(
        lang.get(
            "en",
            0,
        )
    )

    language_coverage_sufficient = bool(
        (
            zh >= 4
            and en >= 4
        )
        or (
            len(
                lang
            )
            >= 2
            and len(
                rows
            )
            >= MIN_READY_CASES
        )
    )

    family_coverage_sufficient = bool(
        len(
            known_families
        )
        >= 3
        or len(
            family
        )
        >= 4
    )

    return {
        "language_counts": dict(
            lang
        ),
        "family_counts": dict(
            family
        ),
        "language_coverage_sufficient": language_coverage_sufficient,
        "family_coverage_sufficient": family_coverage_sufficient,
        "known_family_count": int(
            len(
                known_families
            )
        ),
    }


def token_metrics(
    cases,
    outputs,
):
    total = 0
    matches = 0
    first = 0
    exact = 0

    for case in cases:
        cid = case[
            "case_id"
        ]

        target = case[
            "target_token_ids"
        ][
            :MAX_NEW_TOKENS
        ]

        pred = outputs[
            cid
        ]

        first += int(
            bool(
                target
            )
            and bool(
                pred
            )
            and int(
                target[
                    0
                ]
            )
            == int(
                pred[
                    0
                ]
            )
        )

        exact += int(
            pred[
                :len(
                    target
                )
            ]
            == target
        )

        for step, tid in enumerate(
            target
        ):
            total += 1

            if (
                step
                < len(
                    pred
                )
                and int(
                    pred[
                        step
                    ]
                )
                == int(
                    tid
                )
            ):
                matches += 1

    return {
        "cases": int(
            len(
                cases
            )
        ),
        "total_decisions": int(
            total
        ),
        "token_matches": int(
            matches
        ),
        "first_token_top1": int(
            first
        ),
        "exact_sequences": int(
            exact
        ),
    }


def main():
    ap = argparse.ArgumentParser()

    for name in (
        "root",
        "base-model",
        "source-adapter",
        "v67-patch",
        "runtime-script",
        "v624-controller-script",
        "joint-controller-script",
        "reference-runtime-script",
        "v650-runtime-script",
        "output-dir",
    ):
        ap.add_argument(
            "--"
            + name,
            required=True,
        )

    a = ap.parse_args()

    root = Path(
        a.root
    )

    outdir = Path(
        a.output_dir
    )

    outdir.mkdir(
        parents=True,
        exist_ok=True,
    )

    rt = load_module(
        a.runtime_script,
        "v652_rt",
    )

    ref = load_module(
        a.reference_runtime_script,
        "v652_ref",
    )

    v650rt = load_module(
        a.v650_runtime_script,
        "v652_v650rt",
    )

    v624mod = load_module(
        a.v624_controller_script,
        "v652_v624",
    )

    jointmod = load_module(
        a.joint_controller_script,
        "v652_joint",
    )

    d51 = (
        root
        / "diagnostics"
        / "v6_51_controlled_generation_generalization_and_runtime_robustness_milestone"
    )

    report51 = (
        d51
        / "v6_51_generalization_and_robustness_report.json"
    )

    analysis51 = (
        d51
        / "v6_51_milestone_analysis.json"
    )

    summary51 = (
        d51
        / "v6_51_milestone_summary.json"
    )

    d50 = (
        root
        / "artifacts"
        / "Zant-LLM-v6_50-controlled-generation-runtime"
    )

    bundle_path = (
        d50
        / "v6_50_controlled_generation_runtime_bundle.pt"
    )

    d44 = (
        root
        / "full_training"
        / "v6_44_dedicated_transition_supervision_dataset"
    )

    train44 = (
        d44
        / "v6_44_dedicated_train_transitions.jsonl"
    )

    anchor44 = (
        d44
        / "v6_44_anchor_validation_transitions_DO_NOT_TRAIN.jsonl"
    )

    required = (
        report51,
        analysis51,
        summary51,
        bundle_path,
        train44,
        anchor44,
    )

    for p in required:
        if not p.exists():
            raise SystemExit(
                "Missing prerequisite: "
                + str(
                    p
                )
            )

    lineage = (
        (
            report51,
            EXPECTED_V651_REPORT_SHA,
            "v6.51 report",
        ),
        (
            analysis51,
            EXPECTED_V651_ANALYSIS_SHA,
            "v6.51 analysis",
        ),
        (
            summary51,
            EXPECTED_V651_SUMMARY_SHA,
            "v6.51 summary",
        ),
        (
            bundle_path,
            EXPECTED_V650_BUNDLE_SHA,
            "v6.50 bundle",
        ),
    )

    for p, expected, label in lineage:
        got = rt.sha256_file(
            p
        )

        if got != expected:
            raise SystemExit(
                label
                + " SHA mismatch: "
                + got
            )

    s51 = rt.read_json(
        summary51
    )

    expected51 = {
        "milestone_complete": True,
        "no_model_training": True,
        "unseen_dev_available": False,
        "unseen_dev_cases": 0,
        "runtime_robustness_pass": True,
        "training_authorized": False,
        "retained_holdout_opened": False,
        "milestone_status": "RUNTIME_IS_ROBUST_BUT_NO_CLEAN_UNSEEN_DEV_SET_IS_AVAILABLE",
        "selected_v6_52_objective": "ZERO_TRAIN_CALIBRATION_OVERLAP+LABELED_UNSEEN_DEV+LANGUAGE_FAMILY_COVERAGE+RUNTIME_EVAL",
        "next_milestone": "v6.52-clean-unseen-dev-evaluation-set-construction-milestone",
    }

    for key, expected in expected51.items():
        if s51.get(
            key
        ) != expected:
            raise SystemExit(
                "v6.51 summary mismatch: "
                + key
                + "="
                + repr(
                    s51.get(
                        key
                    )
                )
            )

    print(
        "========== ZANT-LLM v6.52 CLEAN UNSEEN-DEV CONSTRUCTION =========="
    )

    print(
        "NO_MODEL_TRAINING=True"
    )

    print(
        "SOURCE_V6_51_COMPLETE=True"
    )

    print(
        "SOURCE_RUNTIME_ROBUSTNESS_PASS=True"
    )

    print(
        "SOURCE_UNSEEN_DEV_AVAILABLE=False"
    )

    print(
        "OBJECTIVE=ZERO_TRAIN_CALIBRATION_OVERLAP+LABELED_UNSEEN_DEV+LANGUAGE_FAMILY_COVERAGE+RUNTIME_EVAL"
    )

    print(
        "RETAINED_HOLDOUT_EVALUATED=False"
    )

    print(
        "NO_GITHUB_PUSH=True"
    )

    import torch

    torch.backends.cuda.enable_flash_sdp(
        False
    )
    torch.backends.cuda.enable_mem_efficient_sdp(
        False
    )
    torch.backends.cuda.enable_math_sdp(
        True
    )

    tok, model, info = rt.load_base_with_v67_residual(
        Path(
            a.base_model
        ),
        Path(
            a.source_adapter
        ),
        Path(
            a.v67_patch
        ),
    )

    model.eval()

    for p in model.parameters():
        p.requires_grad_(
            False
        )

    bundle = torch.load(
        bundle_path,
        map_location="cpu",
        weights_only=False,
    )

    if bundle.get(
        "schema"
    ) != "ZANT_LLM_V6_50_CONTROLLED_GENERATION_RUNTIME_BUNDLE_V1":
        raise SystemExit(
            "Unexpected v6.50 runtime bundle schema"
        )

    bridge = bundle[
        "bridge"
    ]

    train_rows = read_jsonl(
        train44
    )

    anchor_rows = read_jsonl(
        anchor44
    )

    (
        excluded_ids,
        excluded_prompt_hashes,
        excluded_signatures,
    ) = build_exclusion_sets(
        train_rows,
        anchor_rows,
    )

    candidates, audit = discover_candidates(
        root,
        tok,
        excluded_ids,
        excluded_prompt_hashes,
        excluded_signatures,
    )

    selected = balanced_select(
        candidates,
        target_cases=TARGET_CASES,
        max_cases=MAX_CASES,
    )

    coverage = coverage_summary(
        selected
    )

    dataset_path = (
        outdir
        / "v6_52_clean_unseen_dev.jsonl"
    )

    audit_path = (
        outdir
        / "v6_52_candidate_audit.json"
    )

    manifest_path = (
        outdir
        / "v6_52_dataset_manifest.json"
    )

    eval_detail_path = (
        outdir
        / "v6_52_runtime_eval_detail.jsonl"
    )

    eval_report_path = (
        outdir
        / "v6_52_runtime_eval_report.json"
    )

    write_jsonl(
        dataset_path,
        selected,
    )

    audit.update(
        {
            "candidate_rows_after_dedup": int(
                len(
                    candidates
                )
            ),
            "selected_rows": int(
                len(
                    selected
                )
            ),
            "selection_target": TARGET_CASES,
            "selection_max": MAX_CASES,
            "explicit_eval_metadata_required": True,
            "retained_paths_excluded": True,
            "training_paths_excluded": True,
        }
    )

    write_json(
        audit_path,
        audit,
    )

    selected_ids = {
        r[
            "source_row_id"
        ]
        for r in selected
    }

    selected_prompt_hashes = {
        r[
            "prompt_sha256"
        ]
        for r in selected
    }

    selected_signatures = {
        r[
            "prompt_target_signature"
        ]
        for r in selected
    }

    source_id_overlap = len(
        selected_ids
        & excluded_ids
    )

    prompt_overlap = len(
        selected_prompt_hashes
        & excluded_prompt_hashes
    )

    signature_overlap = len(
        selected_signatures
        & excluded_signatures
    )

    dataset_ready = bool(
        len(
            selected
        )
        >= MIN_READY_CASES
        and source_id_overlap
        == 0
        and prompt_overlap
        == 0
        and signature_overlap
        == 0
    )

    language_coverage = bool(
        coverage[
            "language_coverage_sufficient"
        ]
    )

    family_coverage = bool(
        coverage[
            "family_coverage_sufficient"
        ]
    )

    manifest = {
        "schema": "ZANT_LLM_V6_52_CLEAN_UNSEEN_DEV_MANIFEST_V1",
        "dataset_rows": int(
            len(
                selected
            )
        ),
        "candidate_rows_after_dedup": int(
            len(
                candidates
            )
        ),
        "minimum_ready_rows": MIN_READY_CASES,
        "minimum_runtime_eval_rows": MIN_EVAL_CASES,
        "target_rows": TARGET_CASES,
        "source_id_overlap_with_v6_44": int(
            source_id_overlap
        ),
        "prompt_overlap_with_v6_44": int(
            prompt_overlap
        ),
        "prompt_target_signature_overlap_with_v6_44": int(
            signature_overlap
        ),
        "language_counts": coverage[
            "language_counts"
        ],
        "family_counts": coverage[
            "family_counts"
        ],
        "language_coverage_sufficient": bool(
            language_coverage
        ),
        "family_coverage_sufficient": bool(
            family_coverage
        ),
        "dataset_ready": bool(
            dataset_ready
        ),
        "runtime_eval_eligible": bool(
            len(
                selected
            )
            >= MIN_EVAL_CASES
        ),
        "retained_holdout_evaluated": False,
        "do_not_train": True,
        "dataset_sha256": rt.sha256_file(
            dataset_path
        ),
        "candidate_audit_sha256": rt.sha256_file(
            audit_path
        ),
    }

    write_json(
        manifest_path,
        manifest,
    )

    print(
        "CANDIDATE_ROWS_AFTER_DEDUP="
        + str(
            len(
                candidates
            )
        )
    )

    print(
        "CLEAN_UNSEEN_DEV_ROWS="
        + str(
            len(
                selected
            )
        )
    )

    print(
        "SOURCE_ID_OVERLAP_WITH_V6_44="
        + str(
            source_id_overlap
        )
    )

    print(
        "PROMPT_OVERLAP_WITH_V6_44="
        + str(
            prompt_overlap
        )
    )

    print(
        "PROMPT_TARGET_SIGNATURE_OVERLAP_WITH_V6_44="
        + str(
            signature_overlap
        )
    )

    print(
        "LANGUAGE_COUNTS="
        + json.dumps(
            coverage[
                "language_counts"
            ],
            ensure_ascii=False,
            sort_keys=True,
        )
    )

    print(
        "FAMILY_COUNTS="
        + json.dumps(
            coverage[
                "family_counts"
            ],
            ensure_ascii=False,
            sort_keys=True,
        )
    )

    print(
        "LANGUAGE_COVERAGE_SUFFICIENT="
        + str(
            language_coverage
        )
    )

    print(
        "FAMILY_COVERAGE_SUFFICIENT="
        + str(
            family_coverage
        )
    )

    print(
        "DATASET_READY="
        + str(
            dataset_ready
        )
    )

    runtime_eval_performed = False
    eval_report = {
        "schema": "ZANT_LLM_V6_52_CLEAN_UNSEEN_DEV_RUNTIME_EVAL_REPORT_V1",
        "runtime_eval_performed": False,
        "runtime_eval_cases": 0,
        "retained_holdout_evaluated": False,
    }

    detail_rows = []

    if len(
        selected
    ) >= MIN_EVAL_CASES:
        runtime_eval_performed = True

        plan_states_tensor = bundle[
            "plan_train_prompt_states"
        ].float()

        plan_states = [
            plan_states_tensor[
                i
            ]
            for i in range(
                int(
                    plan_states_tensor.shape[
                        0
                    ]
                )
            )
        ]

        plan_labels = [
            int(x)
            for x in bundle[
                "plan_train_labels"
            ].tolist()
        ]

        Wcpu = (
            model.get_output_embeddings()
            .weight
            .detach()
            .float()
            .cpu()
        )

        projection = bridge[
            "projection_matrix"
        ].float()

        bridge_weight = bridge[
            "state_dict"
        ][
            "weight"
        ].float()

        feature_weights = dict(
            bridge[
                "feature_weights"
            ]
        )

        residual_clip = float(
            bridge[
                "residual_clip"
            ]
        )

        beta = float(
            bundle[
                "gate"
            ][
                "beta"
            ]
        )

        threshold = float(
            bundle[
                "gate"
            ][
                "threshold"
            ]
        )

        requests = []

        for case in selected:
            case[
                "pids"
            ] = ref.prompt_ids(
                tok,
                case[
                    "prompt"
                ],
            )

            requests.append(
                (
                    (
                        "V652",
                        case[
                            "case_id"
                        ],
                    ),
                    case[
                        "pids"
                    ],
                )
            )

        prompt_states = ref.capture_raw_states(
            torch,
            model,
            rt,
            requests,
        )

        outputs = {
            "baseline": {},
            "gated": {},
        }

        latencies = {
            "baseline": [],
            "gated": [],
        }

        peaks = {
            "baseline": [],
            "gated": [],
        }

        for mode in (
            "baseline",
            "gated",
        ):
            for idx, case in enumerate(
                selected,
                1,
            ):
                state = prompt_states[
                    (
                        "V652",
                        case[
                            "case_id"
                        ],
                    )
                ]

                plan, plan_conf = ref.plan_knn(
                    torch,
                    plan_states,
                    plan_labels,
                    state,
                )

                joint = ref.load_joint_controller(
                    torch,
                    rt,
                    v624mod,
                    jointmod,
                    root,
                )

                torch.cuda.synchronize()
                torch.cuda.reset_peak_memory_stats()

                t0 = time.perf_counter()

                pred, steps, fallback_count = v650rt.safe_live_generate(
                    torch,
                    model,
                    rt,
                    jointmod,
                    joint,
                    ref,
                    {
                        "pids": case[
                            "pids"
                        ],
                    },
                    state,
                    plan,
                    plan_conf,
                    Wcpu,
                    projection,
                    feature_weights,
                    bridge_weight,
                    residual_clip,
                    beta,
                    threshold,
                    mode=mode,
                    max_new_tokens=min(
                        MAX_NEW_TOKENS,
                        max(
                            1,
                            len(
                                case[
                                    "target_token_ids"
                                ]
                            ),
                        ),
                    ),
                )

                torch.cuda.synchronize()

                elapsed = (
                    time.perf_counter()
                    - t0
                )

                peak = int(
                    torch.cuda.max_memory_allocated()
                )

                outputs[
                    mode
                ][
                    case[
                        "case_id"
                    ]
                ] = pred

                latencies[
                    mode
                ].append(
                    float(
                        elapsed
                    )
                )

                peaks[
                    mode
                ].append(
                    peak
                )

                detail_rows.append(
                    {
                        "case_id": case[
                            "case_id"
                        ],
                        "mode": mode,
                        "language": case[
                            "language"
                        ],
                        "family": case[
                            "family"
                        ],
                        "source_path": case[
                            "source_path"
                        ],
                        "target_token_ids": case[
                            "target_token_ids"
                        ],
                        "generated_token_ids": pred,
                        "predicted_plan": int(
                            plan
                        ),
                        "plan_confidence": float(
                            plan_conf
                        ),
                        "fallback_count": int(
                            fallback_count
                        ),
                        "elapsed_sec": float(
                            elapsed
                        ),
                        "peak_memory_bytes": int(
                            peak
                        ),
                        "steps": steps,
                    }
                )

                if idx % 5 == 0:
                    print(
                        "RUNTIME_EVAL_PROGRESS="
                        + mode
                        + ":"
                        + str(
                            idx
                        )
                        + "/"
                        + str(
                            len(
                                selected
                            )
                        ),
                        flush=True,
                    )

        baseline_metrics = token_metrics(
            selected,
            outputs[
                "baseline"
            ],
        )

        gated_metrics = token_metrics(
            selected,
            outputs[
                "gated"
            ],
        )

        baseline_latency = sum(
            latencies[
                "baseline"
            ]
        ) / len(
            latencies[
                "baseline"
            ]
        )

        gated_latency = sum(
            latencies[
                "gated"
            ]
        ) / len(
            latencies[
                "gated"
            ]
        )

        latency_ratio = (
            gated_latency
            / max(
                baseline_latency,
                1e-6,
            )
        )

        baseline_peak = max(
            peaks[
                "baseline"
            ]
        )

        gated_peak = max(
            peaks[
                "gated"
            ]
        )

        memory_delta_mb = (
            gated_peak
            - baseline_peak
        ) / (
            1024
            * 1024
        )

        eval_report = {
            "schema": "ZANT_LLM_V6_52_CLEAN_UNSEEN_DEV_RUNTIME_EVAL_REPORT_V1",
            "runtime_eval_performed": True,
            "runtime_eval_cases": int(
                len(
                    selected
                )
            ),
            "baseline": baseline_metrics,
            "gated": gated_metrics,
            "gated_token_gain": int(
                gated_metrics[
                    "token_matches"
                ]
                - baseline_metrics[
                    "token_matches"
                ]
            ),
            "gated_first_token_gain": int(
                gated_metrics[
                    "first_token_top1"
                ]
                - baseline_metrics[
                    "first_token_top1"
                ]
            ),
            "baseline_mean_latency_sec": float(
                baseline_latency
            ),
            "gated_mean_latency_sec": float(
                gated_latency
            ),
            "gated_latency_ratio": float(
                latency_ratio
            ),
            "baseline_peak_memory_bytes": int(
                baseline_peak
            ),
            "gated_peak_memory_bytes": int(
                gated_peak
            ),
            "gated_peak_memory_delta_mb": float(
                memory_delta_mb
            ),
            "retained_holdout_evaluated": False,
        }

        print(
            "RUNTIME_EVAL_PERFORMED=True"
        )

        print(
            "BASELINE_UNSEEN_TOKEN_MATCH="
            + str(
                baseline_metrics[
                    "token_matches"
                ]
            )
            + "/"
            + str(
                baseline_metrics[
                    "total_decisions"
                ]
            )
        )

        print(
            "GATED_UNSEEN_TOKEN_MATCH="
            + str(
                gated_metrics[
                    "token_matches"
                ]
            )
            + "/"
            + str(
                gated_metrics[
                    "total_decisions"
                ]
            )
        )

        print(
            "GATED_UNSEEN_TOKEN_GAIN="
            + str(
                eval_report[
                    "gated_token_gain"
                ]
            )
        )

        print(
            "GATED_UNSEEN_FIRST_TOKEN_GAIN="
            + str(
                eval_report[
                    "gated_first_token_gain"
                ]
            )
        )

        print(
            "GATED_UNSEEN_LATENCY_RATIO=%.6f"
            % float(
                latency_ratio
            )
        )

        print(
            "GATED_UNSEEN_PEAK_MEMORY_DELTA_MB=%.3f"
            % float(
                memory_delta_mb
            )
        )

    else:
        print(
            "RUNTIME_EVAL_PERFORMED=False"
        )

    write_jsonl(
        eval_detail_path,
        detail_rows,
    )

    eval_report[
        "dataset_sha256"
    ] = rt.sha256_file(
        dataset_path
    )

    eval_report[
        "eval_detail_sha256"
    ] = rt.sha256_file(
        eval_detail_path
    )

    write_json(
        eval_report_path,
        eval_report,
    )

    construction_report_path = (
        outdir
        / "v6_52_construction_report.json"
    )

    construction_report = {
        "schema": "ZANT_LLM_V6_52_CLEAN_UNSEEN_DEV_CONSTRUCTION_REPORT_V1",
        "milestone_construction_complete": True,
        "no_model_training": True,
        "candidate_rows_after_dedup": int(
            len(
                candidates
            )
        ),
        "clean_unseen_dev_rows": int(
            len(
                selected
            )
        ),
        "source_id_overlap": int(
            source_id_overlap
        ),
        "prompt_overlap": int(
            prompt_overlap
        ),
        "prompt_target_signature_overlap": int(
            signature_overlap
        ),
        "language_coverage_sufficient": bool(
            language_coverage
        ),
        "family_coverage_sufficient": bool(
            family_coverage
        ),
        "dataset_ready": bool(
            dataset_ready
        ),
        "runtime_eval_performed": bool(
            runtime_eval_performed
        ),
        "runtime_eval_report": eval_report,
        "retained_holdout_evaluated": False,
        "github_push_performed": False,
        "dataset_sha256": rt.sha256_file(
            dataset_path
        ),
        "manifest_sha256": rt.sha256_file(
            manifest_path
        ),
        "candidate_audit_sha256": rt.sha256_file(
            audit_path
        ),
        "runtime_eval_report_sha256": rt.sha256_file(
            eval_report_path
        ),
    }

    write_json(
        construction_report_path,
        construction_report,
    )

    print(
        "========== V6.52 CONSTRUCTION SUMMARY =========="
    )

    print(
        "V6_52_CONSTRUCTION_COMPLETE=True"
    )

    print(
        "NO_MODEL_TRAINING=True"
    )

    print(
        "CLEAN_UNSEEN_DEV_ROWS="
        + str(
            len(
                selected
            )
        )
    )

    print(
        "DATASET_READY="
        + str(
            dataset_ready
        )
    )

    print(
        "LANGUAGE_COVERAGE_SUFFICIENT="
        + str(
            language_coverage
        )
    )

    print(
        "FAMILY_COVERAGE_SUFFICIENT="
        + str(
            family_coverage
        )
    )

    print(
        "RUNTIME_EVAL_PERFORMED="
        + str(
            runtime_eval_performed
        )
    )

    print(
        "DATASET_SHA256="
        + rt.sha256_file(
            dataset_path
        )
    )

    print(
        "MANIFEST_SHA256="
        + rt.sha256_file(
            manifest_path
        )
    )

    print(
        "CONSTRUCTION_REPORT_SHA256="
        + rt.sha256_file(
            construction_report_path
        )
    )

    print(
        "RETAINED_HOLDOUT_EVALUATED=False"
    )

    print(
        "NO_GITHUB_PUSH=True"
    )


if __name__ == "__main__":
    main()
