from pathlib import Path
import argparse
import importlib.util


def load_module(path, name):
    spec = importlib.util.spec_from_file_location(
        name,
        str(path),
    )
    mod = importlib.util.module_from_spec(
        spec
    )
    spec.loader.exec_module(
        mod
    )
    return mod


def main():
    ap = argparse.ArgumentParser()

    ap.add_argument(
        "--report",
        required=True,
    )

    ap.add_argument(
        "--runtime-script",
        required=True,
    )

    ap.add_argument(
        "--output-dir",
        required=True,
    )

    a = ap.parse_args()

    rt = load_module(
        a.runtime_script,
        "v652_route_rt",
    )

    report = rt.read_json(
        Path(
            a.report
        )
    )

    outdir = Path(
        a.output_dir
    )

    if report.get(
        "milestone_construction_complete"
    ) is not True:
        raise SystemExit(
            "v6.52 construction incomplete"
        )

    rows = int(
        report[
            "clean_unseen_dev_rows"
        ]
    )

    ready = bool(
        report[
            "dataset_ready"
        ]
    )

    lang_ok = bool(
        report[
            "language_coverage_sufficient"
        ]
    )

    family_ok = bool(
        report[
            "family_coverage_sufficient"
        ]
    )

    eval_performed = bool(
        report[
            "runtime_eval_performed"
        ]
    )

    eval_report = report[
        "runtime_eval_report"
    ]

    if ready and eval_performed:
        token_gain = int(
            eval_report[
                "gated_token_gain"
            ]
        )

        first_gain = int(
            eval_report[
                "gated_first_token_gain"
            ]
        )

        latency_ratio = float(
            eval_report[
                "gated_latency_ratio"
            ]
        )

        memory_delta = float(
            eval_report[
                "gated_peak_memory_delta_mb"
            ]
        )

        total = int(
            eval_report[
                "baseline"
            ][
                "total_decisions"
            ]
        )

        required_gain = max(
            4,
            int(
                round(
                    0.05
                    * total
                )
            ),
        )

    else:
        token_gain = None
        first_gain = None
        latency_ratio = None
        memory_delta = None
        required_gain = None

    if (
        ready
        and lang_ok
        and family_ok
        and eval_performed
        and token_gain
        >= required_gain
        and first_gain
        >= 0
        and latency_ratio
        <= 2.50
        and memory_delta
        <= 768.0
    ):
        status = "CLEAN_UNSEEN_DEV_SET_CONSTRUCTED_AND_CONTROLLED_RUNTIME_GENERALIZES"
        nxt = "v6.53-broader-generalization-and-retained-holdout-readiness-review-milestone"
        obj = "MULTI_SPLIT_GENERALIZATION+FAILURE_TAXONOMY+LATENCY_BUDGET+RETAINED_HOLDOUT_READINESS_REVIEW"

    elif (
        ready
        and eval_performed
        and token_gain is not None
        and token_gain > 0
    ):
        status = "CLEAN_UNSEEN_DEV_SET_CONSTRUCTED_BUT_RUNTIME_GENERALIZATION_IS_POSITIVE_AND_WEAK"
        nxt = "v6.53-unseen-dev-failure-topology-and-gate-transfer-milestone"
        obj = "UNSEEN_DEV_FAILURE_TOPOLOGY+LANGUAGE_FAMILY_BREAKDOWN+PLAN_TRANSFER+GATE_TRANSFER"

    elif (
        ready
        and eval_performed
    ):
        status = "CLEAN_UNSEEN_DEV_SET_CONSTRUCTED_BUT_RUNTIME_DOES_NOT_GENERALIZE"
        nxt = "v6.53-generalization-representation-and-runtime-gate-redesign-milestone"
        obj = "UNSEEN_CONTEXT_REPRESENTATION+PLAN_GENERALIZATION+GATE_TRANSFER_WITHOUT_ANCHOR_OVERFIT"

    elif (
        rows
        >= 8
        and not (
            lang_ok
            and family_ok
        )
    ):
        status = "PARTIAL_CLEAN_UNSEEN_DEV_SET_EXISTS_BUT_LANGUAGE_FAMILY_COVERAGE_IS_INSUFFICIENT"
        nxt = "v6.53-clean-unseen-dev-language-family-coverage-augmentation-milestone"
        obj = "UNDERREPRESENTED_LANGUAGE_FAMILY_AUGMENTATION+ZERO_OVERLAP+LABELED_EVAL"

    elif rows > 0:
        status = "CLEAN_UNSEEN_DEV_CANDIDATES_EXIST_BUT_THE_SET_IS_TOO_SMALL"
        nxt = "v6.53-clean-unseen-dev-source-expansion-milestone"
        obj = "NEW_EVAL_SOURCE_IMPORT+ZERO_TRAIN_CALIBRATION_OVERLAP+LABELED_CASE_EXPANSION"

    else:
        status = "NO_EXISTING_PROJECT_SOURCE_CAN_PROVIDE_A_CLEAN_UNSEEN_DEV_SET"
        nxt = "v6.53-external-clean-unseen-dev-data-authoring-and-import-milestone"
        obj = "NEW_LABELED_UNSEEN_DEV_AUTHORING+EN_CN_BALANCE+FAMILY_COVERAGE+ZERO_PROJECT_OVERLAP"

    analysis = {
        "schema": "ZANT_LLM_V6_52_MILESTONE_ANALYSIS_V1",
        "clean_unseen_dev_rows": rows,
        "dataset_ready": ready,
        "language_coverage_sufficient": lang_ok,
        "family_coverage_sufficient": family_ok,
        "runtime_eval_performed": eval_performed,
        "gated_token_gain": token_gain,
        "gated_first_token_gain": first_gain,
        "gated_latency_ratio": latency_ratio,
        "gated_peak_memory_delta_mb": memory_delta,
        "classification": status,
        "training_authorized": False,
        "retained_holdout_opened": False,
        "selected_v6_53_objective": obj,
        "next_milestone": nxt,
    }

    analysis_path = (
        outdir
        / "v6_52_milestone_analysis.json"
    )

    rt.write_json(
        analysis_path,
        analysis,
    )

    summary = {
        "schema": "ZANT_LLM_V6_52_CLEAN_UNSEEN_DEV_EVALUATION_SET_CONSTRUCTION_MILESTONE_V1",
        "milestone_complete": True,
        "no_model_training": True,
        "clean_unseen_dev_rows": rows,
        "dataset_ready": ready,
        "language_coverage_sufficient": lang_ok,
        "family_coverage_sufficient": family_ok,
        "runtime_eval_performed": eval_performed,
        "training_authorized": False,
        "retained_holdout_opened": False,
        "milestone_status": status,
        "selected_v6_53_objective": obj,
        "next_milestone": nxt,
        "github_push_performed": False,
    }

    if token_gain is not None:
        summary[
            "gated_unseen_token_gain"
        ] = token_gain

        summary[
            "gated_unseen_first_token_gain"
        ] = first_gain

        summary[
            "gated_unseen_latency_ratio"
        ] = latency_ratio

        summary[
            "gated_unseen_peak_memory_delta_mb"
        ] = memory_delta

    summary_path = (
        outdir
        / "v6_52_milestone_summary.json"
    )

    rt.write_json(
        summary_path,
        summary,
    )

    print(
        "========== V6.52 MILESTONE FINAL =========="
    )

    print(
        "V6_52_MILESTONE_COMPLETE=True"
    )

    print(
        "NO_MODEL_TRAINING=True"
    )

    print(
        "CLEAN_UNSEEN_DEV_ROWS="
        + str(
            rows
        )
    )

    print(
        "DATASET_READY="
        + str(
            ready
        )
    )

    print(
        "LANGUAGE_COVERAGE_SUFFICIENT="
        + str(
            lang_ok
        )
    )

    print(
        "FAMILY_COVERAGE_SUFFICIENT="
        + str(
            family_ok
        )
    )

    print(
        "RUNTIME_EVAL_PERFORMED="
        + str(
            eval_performed
        )
    )

    if token_gain is not None:
        print(
            "GATED_UNSEEN_TOKEN_GAIN="
            + str(
                token_gain
            )
        )

        print(
            "GATED_UNSEEN_FIRST_TOKEN_GAIN="
            + str(
                first_gain
            )
        )

        print(
            "GATED_UNSEEN_LATENCY_RATIO=%.6f"
            % float(
                latency_ratio
            )
        )

        print(
            "GATED_UNSEEN_PEAK_MEMORY_DELTA_MB=%.3f"
            % float(
                memory_delta
            )
        )

    print(
        "TRAINING_AUTHORIZED=False"
    )

    print(
        "RETAINED_HOLDOUT_OPENED=False"
    )

    print(
        "MILESTONE_STATUS="
        + status
    )

    print(
        "SELECTED_V6_53_OBJECTIVE="
        + obj
    )

    print(
        "ANALYSIS_SHA256="
        + rt.sha256_file(
            analysis_path
        )
    )

    print(
        "FINAL_SUMMARY_SHA256="
        + rt.sha256_file(
            summary_path
        )
    )

    print(
        "NEXT_MILESTONE="
        + nxt
    )

    print(
        "GITHUB_PUSH_PERFORMED=False"
    )


if __name__ == "__main__":
    main()
