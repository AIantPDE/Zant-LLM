# Zant-LLM v2.9 Semantic Stop Stable Closeout

## Status

`STABLE_CLOSEOUT_READY=True`

v2.9 closes the Semantic Stop cycle on top of the frozen v2.8 closeout.

## Frozen source hashes

- v2.9 Stable Validation ZIP SHA256: `ea83d2adec74cacb52581ffd2b57bb1c32aab7da9d2fa111408fb22dc48cd878`
- v2.8 Stable Closeout SHA256: `3c54c0d0eb142b8ba4b91fa81a019357dd32dedacc5d688bf233cc56990c97c9`
- v2.9 Second Fresh Dataset SHA256: `893a63b01fe466c116e52629222cc11e419cb06bd8467ad154b55efaf007f37c`
- Adapter Model SHA256: `c509c640a3a7653b9536078bd25fddc22f2b2cdaa2eb22a45272ad4ffe077314`
- Adapter Config SHA256: `cf2bd15f43a766bdce290604a6b6a08eaf4ebabf6bd04632b94e01bd7c587898`

## Frozen runtime profile

- router: `scoped_policy_router_v2_9_semantic_stop_v1_1`
- profile: `concise_early_completion_prompt_v1_1`
- semantic stopper: `semantic_completion_stopper_v1`
- EC_ZH patch: `ec_zh_reconciliation_prompt_v1_1`
- max_new_tokens: `96`
- do_sample: `False`
- strict text only: `True`
- quantization: `4-bit NF4`

## Evidence chain

1. Stage 1 A/B passed.
2. First Fresh Confirmation preserved one EC_ZH prompt-coverage failure in both baseline and candidate; stopper did not trigger on that failed case.
3. EC_ZH Fix v1.1 applied a narrow prompt-only patch with target-only regeneration.
4. Second Fresh Confirmation passed strictly on 20 new cases.

## Efficiency evidence

Stage 1:
- average token reduction: `46.21%`
- average latency reduction: `46.54%`

Second Fresh:
- average token reduction: `41.06%`
- average latency reduction: `41.22%`
- hit-max: `5 -> 0`
- semantic stopper triggers: `16 / 16`

## Limitation

This closeout freezes the validated behavior for the current model, adapter, router, prompt profile, evaluator, and test evidence. It does not claim universal semantic-stop correctness for arbitrary prompts.

## Safety / release state

- `NO_TRAINING=True`
- `GITHUB_PUSH_PERFORMED=False`
- `PUBLIC_RELEASE_PUBLISHED=False`
- `RUNTIME_AUTHORITY_GRANTED=False`
- `PROVIDER_DISPATCH_ENABLED=False`
