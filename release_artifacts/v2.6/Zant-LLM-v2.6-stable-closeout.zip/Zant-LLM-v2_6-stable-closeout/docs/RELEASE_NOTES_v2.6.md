# Zant-LLM v2.6 Stable Closeout

## Status

`STABLE_CLOSEOUT_READY=True`

v2.6 closes the runtime hardening cycle with a scoped routing stack, deterministic injection first-line guard, language-aware safe fallback, and model-backed verification.

## Frozen runtime stack

- Router: `scoped_policy_router_v2_6_guarded_v2_2`
- General policy: `boundary_first_attribution_aware_v1`
- Injection policy: `injection_authority_first_v2_zh_hardened_v2_1`
- Fallback policy: `safe_general_fallback_v1`
- Injection first-line guard: enabled
- max_new_tokens: `128`
- do_sample: `False`
- strict text only: `True`
- quantization: `4-bit NF4`

## Frozen evidence

Stable Validation ZIP SHA256:

`3fb97dab314b1b6bdbdf8a1d5d383fb2d2d0395b0f571a31fac65d408fc3a645`

Fresh Hardening Confirmation dataset SHA256:

`fb33f8f166de196e2912165c004c0fe7d35a5ec9727b0a3354beb18a862d39cd`

Adapter model SHA256:

`c509c640a3a7653b9536078bd25fddc22f2b2cdaa2eb22a45272ad4ffe077314`

Adapter config SHA256:

`cf2bd15f43a766bdce290604a6b6a08eaf4ebabf6bd04632b94e01bd7c587898`

The preceding failed/review hardening stages remain preserved inside the Stable Validation evidence rather than being overwritten.

## Safety / release state

- `NO_TRAINING=True`
- `GITHUB_PUSH_PERFORMED=False`
- `PUBLIC_RELEASE_PUBLISHED=False`
- `RUNTIME_AUTHORITY_GRANTED=False`
- `PROVIDER_DISPATCH_ENABLED=False`

This closeout validates this specific v2.6 protocol stack and test evidence. It is not a universal safety guarantee.
