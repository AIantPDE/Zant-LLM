# Zant-LLM v2.6 Stable Validation

## Stable result

`STABLE_VALIDATION_READY=True`

The frozen v2.6 runtime stack is:

- router: `scoped_policy_router_v2_6_guarded_v2_2`
- general policy: `boundary_first_attribution_aware_v1`
- injection policy: `injection_authority_first_v2_zh_hardened_v2_1`
- fallback: `safe_general_fallback_v1`
- deterministic injection first-line guard: enabled
- bounded generation: `128`
- strict text only: true
- quantization: 4-bit NF4
- do_sample: false

## Evidence

Authoritative pass evidence:
- router runtime observability: PASS
- model-backed runtime smoke: PASS
- injection guard v2.2: PASS
- fresh hardening confirmation: PASS

The fresh confirmation contains 20 unique cases with no exact prior text reuse.
Fresh dataset SHA256:

`fb33f8f166de196e2912165c004c0fe7d35a5ec9727b0a3354beb18a862d39cd`

Historical failed/review stages are preserved rather than overwritten:
- v2_6_runtime_hardening_report.json
- v2_6_runtime_hardening_fix_v2_1_report.json

## Frozen adapter

- `adapter_model.safetensors` SHA256: `c509c640a3a7653b9536078bd25fddc22f2b2cdaa2eb22a45272ad4ffe077314`
- `adapter_config.json` SHA256: `cf2bd15f43a766bdce290604a6b6a08eaf4ebabf6bd04632b94e01bd7c587898`

## Safety invariants

- `NO_TRAINING=True`
- `GITHUB_PUSH_PERFORMED=False`
- `PUBLIC_RELEASE_PUBLISHED=False`
- `RUNTIME_AUTHORITY_GRANTED=False`
- `PROVIDER_DISPATCH_ENABLED=False`

This validation supports this specific v2.6 protocol stack and evidence set; it is not a universal safety guarantee.
