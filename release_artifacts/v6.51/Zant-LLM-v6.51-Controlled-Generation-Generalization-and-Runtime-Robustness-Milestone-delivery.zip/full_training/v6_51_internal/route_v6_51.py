from pathlib import Path
import argparse
import importlib.util


def load_module(path, name):
    spec = importlib.util.spec_from_file_location(
        name,
        str(path),
    )
    mod = importlib.util.module_from_spec(
        spec
    )
    spec.loader.exec_module(
        mod
    )
    return mod


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument(
        "--report",
        required=True,
    )
    ap.add_argument(
        "--runtime-script",
        required=True,
    )
    ap.add_argument(
        "--diagnostics-dir",
        required=True,
    )
    a = ap.parse_args()

    rt = load_module(
        a.runtime_script,
        "v651_route_rt",
    )

    report = rt.read_json(
        Path(
            a.report
        )
    )

    outdir = Path(
        a.diagnostics_dir
    )

    if report.get(
        "milestone_diagnostic_complete"
    ) is not True:
        raise SystemExit(
            "v6.51 diagnostic incomplete"
        )

    unseen_available = bool(
        report[
            "unseen_dev_available"
        ]
    )

    unseen_cases = int(
        report[
            "unseen_dev_cases"
        ]
    )

    robustness = bool(
        report[
            "runtime_robustness"
        ][
            "overall_pass"
        ]
    )

    metrics = report.get(
        "unseen_dev_metrics"
    )

    if not robustness:
        status = "CONTROLLED_GENERATION_RUNTIME_FAILS_ROBUSTNESS_STRESS"
        nxt = "v6.52-controlled-generation-runtime-robustness-hotspot-repair-milestone"
        obj = "DETERMINISM+NUMERICAL_FALLBACK+STEP_RANGE_GUARD+INFERENCE_PACKAGE_REPAIR"

    elif not unseen_available:
        status = "RUNTIME_IS_ROBUST_BUT_NO_CLEAN_UNSEEN_DEV_SET_IS_AVAILABLE"
        nxt = "v6.52-clean-unseen-dev-evaluation-set-construction-milestone"
        obj = "ZERO_TRAIN_CALIBRATION_OVERLAP+LABELED_UNSEEN_DEV+LANGUAGE_FAMILY_COVERAGE+RUNTIME_EVAL"

    else:
        token_gain = int(
            metrics[
                "gated_token_gain"
            ]
        )

        first_gain = int(
            metrics[
                "gated_first_token_gain"
            ]
        )

        latency_ratio = float(
            metrics[
                "gated_latency_ratio"
            ]
        )

        memory_delta = float(
            metrics[
                "gated_peak_memory_delta_mb"
            ]
        )

        total = int(
            metrics[
                "baseline"
            ][
                "total_decisions"
            ]
        )

        # Generalization threshold is deliberately absolute + relative:
        # at least +4 token decisions and at least +5% of evaluated decisions.
        required_gain = max(
            4,
            int(
                round(
                    0.05
                    * total
                )
            ),
        )

        if (
            token_gain >= required_gain
            and first_gain >= 0
            and latency_ratio <= 2.50
            and memory_delta <= 768.0
        ):
            status = "CONTROLLED_GENERATION_RUNTIME_GENERALIZES_TO_CLEAN_UNSEEN_DEV_AND_PASSES_ROBUSTNESS"
            nxt = "v6.52-broader-generalization-and-retained-holdout-readiness-review-milestone"
            obj = "MULTI_SPLIT_GENERALIZATION+FAILURE_TAXONOMY+LATENCY_BUDGET+RETAINED_HOLDOUT_READINESS_REVIEW"

        elif (
            token_gain > 0
            and first_gain >= -1
        ):
            status = "CONTROLLED_GENERATION_RUNTIME_SHOWS_POSITIVE_BUT_WEAK_UNSEEN_DEV_GENERALIZATION"
            nxt = "v6.52-generalization-failure-topology-and-gate-transfer-milestone"
            obj = "UNSEEN_DEV_FAILURE_TOPOLOGY+PLAN_TRANSFER+GATE_TRANSFER+DOMAIN_SHIFT"

        else:
            status = "CONTROLLED_GENERATION_RUNTIME_DOES_NOT_YET_GENERALIZE_BEYOND_DEVELOPMENT_ANCHORS"
            nxt = "v6.52-generalization-representation-and-runtime-gate-redesign-milestone"
            obj = "UNSEEN_CONTEXT_REPRESENTATION+PLAN_GENERALIZATION+GATE_RECALIBRATION_WITHOUT_ANCHOR_OVERFIT"

    analysis = {
        "schema": "ZANT_LLM_V6_51_MILESTONE_ANALYSIS_V1",
        "unseen_dev_available": unseen_available,
        "unseen_dev_cases": unseen_cases,
        "unseen_dev_metrics": metrics,
        "runtime_robustness_pass": robustness,
        "classification": status,
        "training_authorized": False,
        "retained_holdout_opened": False,
        "selected_v6_52_objective": obj,
        "next_milestone": nxt,
    }

    analysis_path = (
        outdir
        / "v6_51_milestone_analysis.json"
    )

    rt.write_json(
        analysis_path,
        analysis,
    )

    summary = {
        "schema": "ZANT_LLM_V6_51_CONTROLLED_GENERATION_GENERALIZATION_AND_RUNTIME_ROBUSTNESS_MILESTONE_V1",
        "milestone_complete": True,
        "no_model_training": True,
        "unseen_dev_available": unseen_available,
        "unseen_dev_cases": unseen_cases,
        "runtime_robustness_pass": robustness,
        "training_authorized": False,
        "retained_holdout_opened": False,
        "milestone_status": status,
        "selected_v6_52_objective": obj,
        "next_milestone": nxt,
        "github_push_performed": False,
    }

    if metrics is not None:
        summary[
            "unseen_gated_token_gain"
        ] = int(
            metrics[
                "gated_token_gain"
            ]
        )
        summary[
            "unseen_gated_first_token_gain"
        ] = int(
            metrics[
                "gated_first_token_gain"
            ]
        )
        summary[
            "unseen_gated_latency_ratio"
        ] = float(
            metrics[
                "gated_latency_ratio"
            ]
        )
        summary[
            "unseen_gated_peak_memory_delta_mb"
        ] = float(
            metrics[
                "gated_peak_memory_delta_mb"
            ]
        )

    summary_path = (
        outdir
        / "v6_51_milestone_summary.json"
    )

    rt.write_json(
        summary_path,
        summary,
    )

    print(
        "========== V6.51 MILESTONE FINAL =========="
    )

    print(
        "V6_51_MILESTONE_COMPLETE=True"
    )

    print(
        "NO_MODEL_TRAINING=True"
    )

    print(
        "UNSEEN_DEV_AVAILABLE="
        + str(
            unseen_available
        )
    )

    print(
        "UNSEEN_DEV_CASES="
        + str(
            unseen_cases
        )
    )

    print(
        "RUNTIME_ROBUSTNESS_PASS="
        + str(
            robustness
        )
    )

    if metrics is not None:
        print(
            "UNSEEN_GATED_TOKEN_GAIN="
            + str(
                metrics[
                    "gated_token_gain"
                ]
            )
        )

        print(
            "UNSEEN_GATED_FIRST_TOKEN_GAIN="
            + str(
                metrics[
                    "gated_first_token_gain"
                ]
            )
        )

        print(
            "UNSEEN_GATED_LATENCY_RATIO=%.6f"
            % float(
                metrics[
                    "gated_latency_ratio"
                ]
            )
        )

        print(
            "UNSEEN_GATED_PEAK_MEMORY_DELTA_MB=%.3f"
            % float(
                metrics[
                    "gated_peak_memory_delta_mb"
                ]
            )
        )

    print(
        "TRAINING_AUTHORIZED=False"
    )

    print(
        "RETAINED_HOLDOUT_OPENED=False"
    )

    print(
        "MILESTONE_STATUS="
        + status
    )

    print(
        "SELECTED_V6_52_OBJECTIVE="
        + obj
    )

    print(
        "ANALYSIS_SHA256="
        + rt.sha256_file(
            analysis_path
        )
    )

    print(
        "FINAL_SUMMARY_SHA256="
        + rt.sha256_file(
            summary_path
        )
    )

    print(
        "NEXT_MILESTONE="
        + nxt
    )

    print(
        "GITHUB_PUSH_PERFORMED=False"
    )


if __name__ == "__main__":
    main()
