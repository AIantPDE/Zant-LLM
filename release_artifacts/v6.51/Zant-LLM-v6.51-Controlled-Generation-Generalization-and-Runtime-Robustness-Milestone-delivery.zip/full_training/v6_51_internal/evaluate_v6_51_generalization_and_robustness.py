from pathlib import Path
import argparse
import importlib.util
import json
import time
import math
import gc

EXPECTED_V650_BUNDLE_SHA = "53ba47a6cf1db43da713e09b5bc11fd533b1e949dfac0aec112679d2444d0944"
EXPECTED_V650_REPORT_SHA = "3197c19439555adc38c83ac4b08bd6038f2ddd1895f5c5f3e7d78b7e426c8f65"
EXPECTED_V650_ANALYSIS_SHA = "f0ee336f8028a0396cd8543301b900ad66bda3459ef22563e9df64ec0005cf25"
EXPECTED_V650_SUMMARY_SHA = "dcb83d139392382e166eeac57df45d29934b72949f9b7ca5baf79c160648fe7f"

MAX_NEW_TOKENS = 8
UNSEEN_MAX_CASES = 40
UNSEEN_MIN_CASES = 8

RESERVED_PATH_TERMS = (
    "retained",
    "holdout",
    "final_holdout",
)

EVAL_PATH_TERMS = (
    "eval",
    "evaluation",
    "dev",
    "validation",
    "valid",
    "test",
)

TRAIN_PATH_TERMS = (
    "train",
    "training",
)

PROMPT_KEYS = (
    "prompt",
    "input",
    "instruction",
    "query",
    "question",
)

TARGET_TEXT_KEYS = (
    "target_text",
    "target",
    "answer",
    "response",
    "completion",
    "canonical_target",
    "expected",
)

ID_KEYS = (
    "source_row_id",
    "case_id",
    "id",
    "example_id",
    "sample_id",
)


def load_module(path, name):
    spec = importlib.util.spec_from_file_location(
        name,
        str(path),
    )
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def read_jsonl(path):
    rows = []

    with Path(path).open(
        "r",
        encoding="utf-8",
        errors="replace",
    ) as f:
        for line in f:
            if not line.strip():
                continue

            try:
                rows.append(
                    json.loads(line)
                )
            except Exception:
                continue

    return rows


def write_json(path, obj):
    path = Path(path)
    path.parent.mkdir(
        parents=True,
        exist_ok=True,
    )

    path.write_text(
        json.dumps(
            obj,
            ensure_ascii=False,
            indent=2,
        )
        + "\n",
        encoding="utf-8",
        newline="\n",
    )


def write_jsonl(path, rows):
    path = Path(path)
    path.parent.mkdir(
        parents=True,
        exist_ok=True,
    )

    with path.open(
        "w",
        encoding="utf-8",
        newline="\n",
    ) as f:
        for row in rows:
            f.write(
                json.dumps(
                    row,
                    ensure_ascii=False,
                    separators=(",", ":"),
                )
                + "\n"
            )


def first_present(row, keys):
    for key in keys:
        value = row.get(
            key
        )

        if value is not None:
            return value

    return None


def normalize_path_text(path):
    return str(
        path
    ).replace(
        "\\",
        "/",
    ).lower()


def candidate_path_allowed(path):
    text = normalize_path_text(
        path
    )

    if any(
        term in text
        for term in RESERVED_PATH_TERMS
    ):
        return False

    # Require an explicit development/evaluation signal in the path.
    if not any(
        term in text
        for term in EVAL_PATH_TERMS
    ):
        return False

    # Files/directories that explicitly say train/training are not unseen-dev.
    if any(
        term in text
        for term in TRAIN_PATH_TERMS
    ):
        return False

    return True


def extract_case(
    tok,
    row,
    source_path,
    row_index,
):
    prompt = first_present(
        row,
        PROMPT_KEYS,
    )

    if not isinstance(
        prompt,
        str,
    ) or not prompt.strip():
        return None

    raw_id = first_present(
        row,
        ID_KEYS,
    )

    if raw_id is None:
        raw_id = (
            source_path.name
            + "::"
            + str(
                row_index
            )
        )

    target_ids = row.get(
        "target_token_ids"
    )

    if isinstance(
        target_ids,
        list,
    ) and target_ids:
        try:
            tids = [
                int(
                    x
                )
                for x in target_ids
            ]
        except Exception:
            tids = []
    else:
        target_text = first_present(
            row,
            TARGET_TEXT_KEYS,
        )

        if not isinstance(
            target_text,
            str,
        ) or not target_text.strip():
            return None

        tids = [
            int(
                x
            )
            for x in tok(
                target_text,
                add_special_tokens=False,
            ).input_ids
        ]

    if not tids:
        return None

    return {
        "id": str(
            raw_id
        ),
        "prompt": prompt,
        "target_ids": tids[
            :MAX_NEW_TOKENS
        ],
        "source_path": str(
            source_path
        ),
        "source_row_index": int(
            row_index
        ),
    }


def discover_unseen_dev(
    root,
    tok,
    excluded_ids,
    excluded_prompts,
):
    candidates = []
    inspected = 0
    accepted_files = []

    for path in sorted(
        root.rglob(
            "*.jsonl"
        )
    ):
        if not candidate_path_allowed(
            path
        ):
            continue

        try:
            size = path.stat().st_size
        except Exception:
            continue

        # Keep discovery bounded and avoid huge corpora.
        if size <= 0 or size > 50 * 1024 * 1024:
            continue

        inspected += 1

        rows = read_jsonl(
            path
        )

        accepted_here = 0

        for idx, row in enumerate(
            rows
        ):
            if not isinstance(
                row,
                dict,
            ):
                continue

            split = str(
                row.get(
                    "split",
                    row.get(
                        "source_split",
                        "",
                    ),
                )
            ).lower()

            if split and any(
                term in split
                for term in (
                    "train",
                    "training",
                    "retained",
                    "holdout",
                )
            ):
                continue

            case = extract_case(
                tok,
                row,
                path,
                idx,
            )

            if case is None:
                continue

            if case["id"] in excluded_ids:
                continue

            normalized_prompt = " ".join(
                case[
                    "prompt"
                ].split()
            )

            if normalized_prompt in excluded_prompts:
                continue

            case[
                "normalized_prompt"
            ] = normalized_prompt

            candidates.append(
                case
            )
            accepted_here += 1

            if len(
                candidates
            ) >= UNSEEN_MAX_CASES:
                break

        if accepted_here:
            accepted_files.append(
                {
                    "path": str(
                        path
                    ),
                    "accepted_cases": int(
                        accepted_here
                    ),
                }
            )

        if len(
            candidates
        ) >= UNSEEN_MAX_CASES:
            break

    # Deduplicate by normalized prompt and id.
    unique = []
    seen_ids = set()
    seen_prompts = set()

    for case in candidates:
        if case["id"] in seen_ids:
            continue

        if case[
            "normalized_prompt"
        ] in seen_prompts:
            continue

        seen_ids.add(
            case["id"]
        )
        seen_prompts.add(
            case[
                "normalized_prompt"
            ]
        )
        unique.append(
            case
        )

    return (
        unique[
            :UNSEEN_MAX_CASES
        ],
        {
            "jsonl_files_inspected": int(
                inspected
            ),
            "accepted_files": accepted_files,
        },
    )


def unit(torch, x):
    x = x.float()
    return x / x.norm().clamp_min(
        1e-8
    )


def predict_plan(
    torch,
    ref,
    train_states,
    train_labels,
    state,
):
    return ref.plan_knn(
        torch,
        train_states,
        train_labels,
        state,
    )


def token_metrics(cases, outputs):
    total = 0
    matches = 0
    first = 0
    exact = 0

    for case in cases:
        cid = case["id"]
        target = case[
            "target_ids"
        ][
            :MAX_NEW_TOKENS
        ]
        pred = outputs[
            cid
        ]

        first += int(
            bool(
                target
            )
            and bool(
                pred
            )
            and int(
                target[
                    0
                ]
            )
            == int(
                pred[
                    0
                ]
            )
        )

        exact += int(
            pred[
                :len(
                    target
                )
            ]
            == target
        )

        for step, tid in enumerate(
            target
        ):
            total += 1

            if (
                step
                < len(
                    pred
                )
                and int(
                    pred[
                        step
                    ]
                )
                == int(
                    tid
                )
            ):
                matches += 1

    return {
        "cases": int(
            len(
                cases
            )
        ),
        "total_decisions": int(
            total
        ),
        "token_matches": int(
            matches
        ),
        "first_token_top1": int(
            first
        ),
        "exact_sequences": int(
            exact
        ),
    }


def main():
    ap = argparse.ArgumentParser()

    for name in (
        "root",
        "base-model",
        "source-adapter",
        "v67-patch",
        "runtime-script",
        "v624-controller-script",
        "joint-controller-script",
        "reference-runtime-script",
        "v650-runtime-script",
        "diagnostics-dir",
    ):
        ap.add_argument(
            "--"
            + name,
            required=True,
        )

    a = ap.parse_args()

    root = Path(
        a.root
    )

    outdir = Path(
        a.diagnostics_dir
    )

    outdir.mkdir(
        parents=True,
        exist_ok=True,
    )

    rt = load_module(
        a.runtime_script,
        "v651_rt",
    )

    ref = load_module(
        a.reference_runtime_script,
        "v651_ref",
    )

    v650rt = load_module(
        a.v650_runtime_script,
        "v651_v650rt",
    )

    v624mod = load_module(
        a.v624_controller_script,
        "v651_v624",
    )

    jointmod = load_module(
        a.joint_controller_script,
        "v651_joint",
    )

    d50 = (
        root
        / "artifacts"
        / "Zant-LLM-v6_50-controlled-generation-runtime"
    )

    bundle_path = (
        d50
        / "v6_50_controlled_generation_runtime_bundle.pt"
    )

    report50 = (
        d50
        / "v6_50_integration_report.json"
    )

    analysis50 = (
        d50
        / "v6_50_milestone_analysis.json"
    )

    summary50 = (
        d50
        / "v6_50_milestone_summary.json"
    )

    d44 = (
        root
        / "full_training"
        / "v6_44_dedicated_transition_supervision_dataset"
    )

    train44 = (
        d44
        / "v6_44_dedicated_train_transitions.jsonl"
    )

    anchor44 = (
        d44
        / "v6_44_anchor_validation_transitions_DO_NOT_TRAIN.jsonl"
    )

    required = (
        bundle_path,
        report50,
        analysis50,
        summary50,
        train44,
        anchor44,
    )

    for p in required:
        if not p.exists():
            raise SystemExit(
                "Missing prerequisite: "
                + str(
                    p
                )
            )

    lineage = (
        (
            bundle_path,
            EXPECTED_V650_BUNDLE_SHA,
            "v6.50 runtime bundle",
        ),
        (
            report50,
            EXPECTED_V650_REPORT_SHA,
            "v6.50 report",
        ),
        (
            analysis50,
            EXPECTED_V650_ANALYSIS_SHA,
            "v6.50 analysis",
        ),
        (
            summary50,
            EXPECTED_V650_SUMMARY_SHA,
            "v6.50 summary",
        ),
    )

    for p, expected, label in lineage:
        got = rt.sha256_file(
            p
        )

        if got != expected:
            raise SystemExit(
                label
                + " SHA mismatch: "
                + got
            )

    s50 = rt.read_json(
        summary50
    )

    expected50 = {
        "milestone_complete": True,
        "no_model_training": True,
        "runtime_bundle_created": True,
        "runtime_parity_pass": True,
        "runtime_safety_fallback_contract_pass": True,
        "baseline_live_token_matches": 2,
        "gated_live_token_matches": 69,
        "baseline_live_first_token_top1": 0,
        "gated_live_first_token_top1": 10,
        "baseline_live_hard52_matches": 0,
        "gated_live_hard52_matches": 32,
        "training_authorized": False,
        "retained_holdout_opened": False,
        "milestone_status": "CONTROLLED_GENERATION_RUNTIME_PACKAGE_REPRODUCES_V6_49_AND_IS_READY_FOR_GENERALIZATION_EVAL",
        "selected_v6_51_objective": "UNSEEN_DEV_GENERALIZATION+LATENCY_MEMORY+FALLBACK_STRESS+INFERENCE_PACKAGE_VALIDATION",
        "next_milestone": "v6.51-controlled-generation-generalization-and-runtime-robustness-milestone",
    }

    for key, expected in expected50.items():
        if s50.get(
            key
        ) != expected:
            raise SystemExit(
                "v6.50 summary mismatch: "
                + key
                + "="
                + repr(
                    s50.get(
                        key
                    )
                )
            )

    print(
        "========== ZANT-LLM v6.51 GENERALIZATION + RUNTIME ROBUSTNESS =========="
    )
    print(
        "NO_MODEL_TRAINING=True"
    )
    print(
        "SOURCE_V6_50_COMPLETE=True"
    )
    print(
        "OBJECTIVE=UNSEEN_DEV_GENERALIZATION+LATENCY_MEMORY+FALLBACK_STRESS+INFERENCE_PACKAGE_VALIDATION"
    )
    print(
        "UNSEEN_DEV_MUST_HAVE_ZERO_V6_44_SOURCE_ID_AND_PROMPT_OVERLAP=True"
    )
    print(
        "RETAINED_HOLDOUT_EVALUATED=False"
    )
    print(
        "NO_GITHUB_PUSH=True"
    )

    import torch

    torch.backends.cuda.enable_flash_sdp(
        False
    )

    torch.backends.cuda.enable_mem_efficient_sdp(
        False
    )

    torch.backends.cuda.enable_math_sdp(
        True
    )

    tok, model, info = rt.load_base_with_v67_residual(
        Path(
            a.base_model
        ),
        Path(
            a.source_adapter
        ),
        Path(
            a.v67_patch
        ),
    )

    model.eval()

    for p in model.parameters():
        p.requires_grad_(
            False
        )

    bundle = torch.load(
        bundle_path,
        map_location="cpu",
        weights_only=False,
    )

    if bundle.get(
        "schema"
    ) != "ZANT_LLM_V6_50_CONTROLLED_GENERATION_RUNTIME_BUNDLE_V1":
        raise SystemExit(
            "Unexpected v6.50 runtime bundle schema"
        )

    bridge = bundle[
        "bridge"
    ]

    projection = bridge[
        "projection_matrix"
    ].float()

    bridge_weight = bridge[
        "state_dict"
    ][
        "weight"
    ].float()

    feature_weights = dict(
        bridge[
            "feature_weights"
        ]
    )

    residual_clip = float(
        bridge[
            "residual_clip"
        ]
    )

    beta = float(
        bundle[
            "gate"
        ][
            "beta"
        ]
    )

    threshold = float(
        bundle[
            "gate"
        ][
            "threshold"
        ]
    )

    train_prompt_states_tensor = bundle[
        "plan_train_prompt_states"
    ].float()

    plan_train_states = [
        train_prompt_states_tensor[
            i
        ]
        for i in range(
            int(
                train_prompt_states_tensor.shape[
                    0
                ]
            )
        )
    ]

    plan_train_labels = [
        int(
            x
        )
        for x in bundle[
            "plan_train_labels"
        ].tolist()
    ]

    if len(
        plan_train_states
    ) != 80:
        raise SystemExit(
            "Expected 80 plan train states"
        )

    Wcpu = (
        model.get_output_embeddings()
        .weight
        .detach()
        .float()
        .cpu()
    )

    train_rows = read_jsonl(
        train44
    )
    anchor_rows = read_jsonl(
        anchor44
    )

    excluded_ids = {
        str(
            r[
                "source_row_id"
            ]
        )
        for r in (
            train_rows
            + anchor_rows
        )
        if isinstance(
            r,
            dict,
        )
        and r.get(
            "source_row_id"
        )
        is not None
    }

    excluded_prompts = {
        " ".join(
            str(
                r[
                    "prompt"
                ]
            ).split()
        )
        for r in (
            train_rows
            + anchor_rows
        )
        if isinstance(
            r,
            dict,
        )
        and isinstance(
            r.get(
                "prompt"
            ),
            str,
        )
    }

    unseen_cases, discovery = discover_unseen_dev(
        root,
        tok,
        excluded_ids,
        excluded_prompts,
    )

    unseen_available = (
        len(
            unseen_cases
        )
        >= UNSEEN_MIN_CASES
    )

    print(
        "UNSEEN_DEV_DISCOVERED_CASES="
        + str(
            len(
                unseen_cases
            )
        )
    )

    print(
        "UNSEEN_DEV_AVAILABLE="
        + str(
            unseen_available
        )
    )

    unseen_report = {
        "available": bool(
            unseen_available
        ),
        "cases_discovered": int(
            len(
                unseen_cases
            )
        ),
        "minimum_required": UNSEEN_MIN_CASES,
        "discovery": discovery,
        "source_id_overlap_with_v6_44": 0,
        "prompt_overlap_with_v6_44": 0,
    }

    unseen_detail = []
    unseen_metrics = None

    if unseen_available:
        # Capture unseen prompt states only. Gold targets are not used by the
        # plan predictor or runtime gate.
        requests = []

        for case in unseen_cases:
            case[
                "pids"
            ] = ref.prompt_ids(
                tok,
                case[
                    "prompt"
                ],
            )

            requests.append(
                (
                    (
                        "UNSEEN_PROMPT",
                        case[
                            "id"
                        ],
                    ),
                    case[
                        "pids"
                    ],
                )
            )

        prompt_states = ref.capture_raw_states(
            torch,
            model,
            rt,
            requests,
        )

        outputs = {
            "baseline": {},
            "gated": {},
        }

        latency = {
            "baseline_sec": [],
            "gated_sec": [],
        }

        peak_memory = {
            "baseline_bytes": [],
            "gated_bytes": [],
        }

        for mode in (
            "baseline",
            "gated",
        ):
            for idx, case in enumerate(
                unseen_cases,
                1,
            ):
                state = prompt_states[
                    (
                        "UNSEEN_PROMPT",
                        case[
                            "id"
                        ],
                    )
                ]

                plan, plan_conf = predict_plan(
                    torch,
                    ref,
                    plan_train_states,
                    plan_train_labels,
                    state,
                )

                joint = ref.load_joint_controller(
                    torch,
                    rt,
                    v624mod,
                    jointmod,
                    root,
                )

                torch.cuda.synchronize()
                torch.cuda.reset_peak_memory_stats()

                t0 = time.perf_counter()

                pred, steps, fallback_count = v650rt.safe_live_generate(
                    torch,
                    model,
                    rt,
                    jointmod,
                    joint,
                    ref,
                    case,
                    state,
                    plan,
                    plan_conf,
                    Wcpu,
                    projection,
                    feature_weights,
                    bridge_weight,
                    residual_clip,
                    beta,
                    threshold,
                    mode=mode,
                    max_new_tokens=min(
                        MAX_NEW_TOKENS,
                        max(
                            1,
                            len(
                                case[
                                    "target_ids"
                                ]
                            ),
                        ),
                    ),
                )

                torch.cuda.synchronize()
                elapsed = time.perf_counter() - t0
                peak = int(
                    torch.cuda.max_memory_allocated()
                )

                outputs[
                    mode
                ][
                    case[
                        "id"
                    ]
                ] = pred

                latency[
                    mode
                    + "_sec"
                ].append(
                    float(
                        elapsed
                    )
                )

                peak_memory[
                    mode
                    + "_bytes"
                ].append(
                    peak
                )

                unseen_detail.append(
                    {
                        "id": case[
                            "id"
                        ],
                        "mode": mode,
                        "source_path": case[
                            "source_path"
                        ],
                        "target_token_ids": case[
                            "target_ids"
                        ],
                        "generated_token_ids": pred,
                        "predicted_plan": int(
                            plan
                        ),
                        "plan_confidence": float(
                            plan_conf
                        ),
                        "fallback_count": int(
                            fallback_count
                        ),
                        "elapsed_sec": float(
                            elapsed
                        ),
                        "peak_memory_bytes": int(
                            peak
                        ),
                        "steps": steps,
                    }
                )

                if idx % 5 == 0:
                    print(
                        "UNSEEN_DEV_PROGRESS="
                        + mode
                        + ":"
                        + str(
                            idx
                        )
                        + "/"
                        + str(
                            len(
                                unseen_cases
                            )
                        ),
                        flush=True,
                    )

        baseline_metrics = token_metrics(
            unseen_cases,
            outputs[
                "baseline"
            ],
        )

        gated_metrics = token_metrics(
            unseen_cases,
            outputs[
                "gated"
            ],
        )

        baseline_mean_latency = sum(
            latency[
                "baseline_sec"
            ]
        ) / len(
            latency[
                "baseline_sec"
            ]
        )

        gated_mean_latency = sum(
            latency[
                "gated_sec"
            ]
        ) / len(
            latency[
                "gated_sec"
            ]
        )

        latency_ratio = (
            gated_mean_latency
            / max(
                baseline_mean_latency,
                1e-6,
            )
        )

        baseline_peak = max(
            peak_memory[
                "baseline_bytes"
            ]
        )

        gated_peak = max(
            peak_memory[
                "gated_bytes"
            ]
        )

        memory_delta_mb = (
            gated_peak
            - baseline_peak
        ) / (
            1024
            * 1024
        )

        unseen_metrics = {
            "baseline": baseline_metrics,
            "gated": gated_metrics,
            "gated_token_gain": int(
                gated_metrics[
                    "token_matches"
                ]
                - baseline_metrics[
                    "token_matches"
                ]
            ),
            "gated_first_token_gain": int(
                gated_metrics[
                    "first_token_top1"
                ]
                - baseline_metrics[
                    "first_token_top1"
                ]
            ),
            "baseline_mean_latency_sec": float(
                baseline_mean_latency
            ),
            "gated_mean_latency_sec": float(
                gated_mean_latency
            ),
            "gated_latency_ratio": float(
                latency_ratio
            ),
            "baseline_peak_memory_bytes": int(
                baseline_peak
            ),
            "gated_peak_memory_bytes": int(
                gated_peak
            ),
            "gated_peak_memory_delta_mb": float(
                memory_delta_mb
            ),
        }

        print(
            "UNSEEN_BASELINE_TOKEN_MATCH="
            + str(
                baseline_metrics[
                    "token_matches"
                ]
            )
            + "/"
            + str(
                baseline_metrics[
                    "total_decisions"
                ]
            )
        )

        print(
            "UNSEEN_GATED_TOKEN_MATCH="
            + str(
                gated_metrics[
                    "token_matches"
                ]
            )
            + "/"
            + str(
                gated_metrics[
                    "total_decisions"
                ]
            )
        )

        print(
            "UNSEEN_GATED_TOKEN_GAIN="
            + str(
                unseen_metrics[
                    "gated_token_gain"
                ]
            )
        )

        print(
            "UNSEEN_BASELINE_FIRST_TOKEN="
            + str(
                baseline_metrics[
                    "first_token_top1"
                ]
            )
            + "/"
            + str(
                len(
                    unseen_cases
                )
            )
        )

        print(
            "UNSEEN_GATED_FIRST_TOKEN="
            + str(
                gated_metrics[
                    "first_token_top1"
                ]
            )
            + "/"
            + str(
                len(
                    unseen_cases
                )
            )
        )

        print(
            "UNSEEN_GATED_LATENCY_RATIO=%.6f"
            % float(
                latency_ratio
            )
        )

        print(
            "UNSEEN_GATED_PEAK_MEMORY_DELTA_MB=%.3f"
            % float(
                memory_delta_mb
            )
        )

    # Runtime robustness uses a known development prompt only as an engineering
    # stress harness. It is NOT counted as unseen generalization.
    anchor_groups = {}

    for r in anchor_rows:
        sid = str(
            r[
                "source_row_id"
            ]
        )

        anchor_groups.setdefault(
            sid,
            {
                "prompt": str(
                    r[
                        "prompt"
                    ]
                ),
                "target_ids": [
                    int(
                        x
                    )
                    for x in r[
                        "target_token_ids"
                    ]
                ],
            },
        )

    stress_sid = sorted(
        anchor_groups
    )[0]

    stress_case = anchor_groups[
        stress_sid
    ]

    stress_case[
        "pids"
    ] = ref.prompt_ids(
        tok,
        stress_case[
            "prompt"
        ],
    )

    stress_state = ref.capture_raw_states(
        torch,
        model,
        rt,
        [
            (
                (
                    "STRESS_PROMPT",
                    stress_sid,
                ),
                stress_case[
                    "pids"
                ],
            )
        ],
    )[
        (
            "STRESS_PROMPT",
            stress_sid,
        )
    ]

    stress_plan, stress_plan_conf = predict_plan(
        torch,
        ref,
        plan_train_states,
        plan_train_labels,
        stress_state,
    )

    # Determinism: same prompt, same gated runtime, same output.
    gated_runs = []

    for _ in range(
        2
    ):
        joint = ref.load_joint_controller(
            torch,
            rt,
            v624mod,
            jointmod,
            root,
        )

        pred, steps, fallback_count = v650rt.safe_live_generate(
            torch,
            model,
            rt,
            jointmod,
            joint,
            ref,
            stress_case,
            stress_state,
            stress_plan,
            stress_plan_conf,
            Wcpu,
            projection,
            feature_weights,
            bridge_weight,
            residual_clip,
            beta,
            threshold,
            mode="gated",
            max_new_tokens=8,
        )

        gated_runs.append(
            pred
        )

    deterministic = (
        gated_runs[
            0
        ]
        == gated_runs[
            1
        ]
    )

    # NaN bridge-weight stress: every bridge attempt must safely fall back to
    # the baseline token path rather than crash.
    nan_weight = bridge_weight.clone()
    nan_weight[
        0,
        0,
    ] = float(
        "nan"
    )

    joint = ref.load_joint_controller(
        torch,
        rt,
        v624mod,
        jointmod,
        root,
    )

    nan_pred, nan_steps, nan_fallback_count = v650rt.safe_live_generate(
        torch,
        model,
        rt,
        jointmod,
        joint,
        ref,
        stress_case,
        stress_state,
        stress_plan,
        stress_plan_conf,
        Wcpu,
        projection,
        feature_weights,
        nan_weight,
        residual_clip,
        beta,
        threshold,
        mode="gated",
        max_new_tokens=3,
    )

    nan_fallback_pass = bool(
        nan_fallback_count
        >= 1
        and all(
            int(
                row[
                    "chosen_token_id"
                ]
            )
            == int(
                row[
                    "baseline_token_id"
                ]
            )
            for row in nan_steps
        )
    )

    # Step-range stress: after calibrated steps 0..7, the bridge must be
    # disabled and baseline chosen.
    joint = ref.load_joint_controller(
        torch,
        rt,
        v624mod,
        jointmod,
        root,
    )

    long_pred, long_steps, long_fallback_count = v650rt.safe_live_generate(
        torch,
        model,
        rt,
        jointmod,
        joint,
        ref,
        stress_case,
        stress_state,
        stress_plan,
        stress_plan_conf,
        Wcpu,
        projection,
        feature_weights,
        bridge_weight,
        residual_clip,
        beta,
        threshold,
        mode="gated",
        max_new_tokens=10,
    )

    post8 = [
        row
        for row in long_steps
        if int(
            row[
                "step"
            ]
        )
        >= 8
    ]

    step_range_fallback_pass = bool(
        len(
            post8
        )
        == 2
        and all(
            str(
                row.get(
                    "fallback_reason",
                    "",
                )
            )
            == "step_out_of_calibrated_range"
            and bool(
                row[
                    "gate_activated"
                ]
            )
            is False
            and int(
                row[
                    "chosen_token_id"
                ]
            )
            == int(
                row[
                    "baseline_token_id"
                ]
            )
            for row in post8
        )
    )

    # Neutral prompt inference-package smoke, no correctness claim.
    neutral_prompt = (
        "Explain the evidence carefully and distinguish what is known "
        "from what remains uncertain."
    )

    neutral_pids = ref.prompt_ids(
        tok,
        neutral_prompt,
    )

    neutral_state = ref.capture_raw_states(
        torch,
        model,
        rt,
        [
            (
                (
                    "PACKAGE_SMOKE",
                    "neutral",
                ),
                neutral_pids,
            )
        ],
    )[
        (
            "PACKAGE_SMOKE",
            "neutral",
        )
    ]

    neutral_plan, neutral_conf = predict_plan(
        torch,
        ref,
        plan_train_states,
        plan_train_labels,
        neutral_state,
    )

    neutral_case = {
        "pids": neutral_pids,
    }

    joint = ref.load_joint_controller(
        torch,
        rt,
        v624mod,
        jointmod,
        root,
    )

    neutral_pred, neutral_steps, neutral_fallback = v650rt.safe_live_generate(
        torch,
        model,
        rt,
        jointmod,
        joint,
        ref,
        neutral_case,
        neutral_state,
        neutral_plan,
        neutral_conf,
        Wcpu,
        projection,
        feature_weights,
        bridge_weight,
        residual_clip,
        beta,
        threshold,
        mode="gated",
        max_new_tokens=4,
    )

    package_smoke_pass = bool(
        len(
            neutral_pred
        )
        == 4
        and len(
            neutral_steps
        )
        == 4
    )

    robustness_pass = bool(
        deterministic
        and nan_fallback_pass
        and step_range_fallback_pass
        and package_smoke_pass
    )

    print(
        "DETERMINISM_STRESS_PASS="
        + str(
            deterministic
        )
    )

    print(
        "NAN_BRIDGE_FALLBACK_PASS="
        + str(
            nan_fallback_pass
        )
    )

    print(
        "STEP_RANGE_FALLBACK_PASS="
        + str(
            step_range_fallback_pass
        )
    )

    print(
        "INFERENCE_PACKAGE_SMOKE_PASS="
        + str(
            package_smoke_pass
        )
    )

    print(
        "RUNTIME_ROBUSTNESS_PASS="
        + str(
            robustness_pass
        )
    )

    unseen_path = (
        outdir
        / "v6_51_unseen_dev_detail.jsonl"
    )

    if unseen_detail:
        write_jsonl(
            unseen_path,
            unseen_detail,
        )
    else:
        unseen_path.write_text(
            "",
            encoding="utf-8",
        )

    discovery_path = (
        outdir
        / "v6_51_unseen_dev_discovery.json"
    )

    write_json(
        discovery_path,
        unseen_report,
    )

    report_path = (
        outdir
        / "v6_51_generalization_and_robustness_report.json"
    )

    report = {
        "schema": "ZANT_LLM_V6_51_GENERALIZATION_AND_RUNTIME_ROBUSTNESS_REPORT_V1",
        "milestone_diagnostic_complete": True,
        "no_model_training": True,
        "unseen_dev_available": bool(
            unseen_available
        ),
        "unseen_dev_cases": int(
            len(
                unseen_cases
            )
        ),
        "unseen_dev_metrics": unseen_metrics,
        "runtime_robustness": {
            "determinism_pass": bool(
                deterministic
            ),
            "nan_bridge_fallback_pass": bool(
                nan_fallback_pass
            ),
            "step_range_fallback_pass": bool(
                step_range_fallback_pass
            ),
            "inference_package_smoke_pass": bool(
                package_smoke_pass
            ),
            "overall_pass": bool(
                robustness_pass
            ),
        },
        "neutral_package_smoke_generated_token_ids": [
            int(
                x
            )
            for x in neutral_pred
        ],
        "retained_holdout_evaluated": False,
        "github_push_performed": False,
        "discovery_sha256": rt.sha256_file(
            discovery_path
        ),
        "unseen_detail_sha256": rt.sha256_file(
            unseen_path
        ),
    }

    write_json(
        report_path,
        report,
    )

    print(
        "========== V6.51 GENERALIZATION + ROBUSTNESS SUMMARY =========="
    )

    print(
        "V6_51_DIAGNOSTIC_COMPLETE=True"
    )

    print(
        "NO_MODEL_TRAINING=True"
    )

    print(
        "UNSEEN_DEV_AVAILABLE="
        + str(
            unseen_available
        )
    )

    print(
        "UNSEEN_DEV_CASES="
        + str(
            len(
                unseen_cases
            )
        )
    )

    if unseen_metrics is not None:
        print(
            "UNSEEN_GATED_TOKEN_GAIN="
            + str(
                unseen_metrics[
                    "gated_token_gain"
                ]
            )
        )

        print(
            "UNSEEN_GATED_FIRST_TOKEN_GAIN="
            + str(
                unseen_metrics[
                    "gated_first_token_gain"
                ]
            )
        )

        print(
            "UNSEEN_GATED_LATENCY_RATIO=%.6f"
            % float(
                unseen_metrics[
                    "gated_latency_ratio"
                ]
            )
        )

        print(
            "UNSEEN_GATED_PEAK_MEMORY_DELTA_MB=%.3f"
            % float(
                unseen_metrics[
                    "gated_peak_memory_delta_mb"
                ]
            )
        )

    print(
        "RUNTIME_ROBUSTNESS_PASS="
        + str(
            robustness_pass
        )
    )

    print(
        "REPORT_SHA256="
        + rt.sha256_file(
            report_path
        )
    )

    print(
        "RETAINED_HOLDOUT_EVALUATED=False"
    )

    print(
        "NO_GITHUB_PUSH=True"
    )


if __name__ == "__main__":
    main()
