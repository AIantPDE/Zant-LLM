from pathlib import Path
import argparse
import importlib.util
import json


def load_module(path, name):
    spec = importlib.util.spec_from_file_location(
        name,
        str(path),
    )
    mod = importlib.util.module_from_spec(
        spec
    )
    spec.loader.exec_module(
        mod
    )
    return mod


def main():
    ap = argparse.ArgumentParser()

    ap.add_argument(
        "--root",
        default=r"C:\Users\Administrator\Desktop\Zant-LLM",
    )

    ap.add_argument(
        "--base-model",
        default=r"E:\gemma-4-E2B-it",
    )

    ap.add_argument(
        "--prompt",
        required=True,
    )

    ap.add_argument(
        "--mode",
        choices=(
            "baseline",
            "always_on",
            "gated",
        ),
        default="gated",
    )

    ap.add_argument(
        "--max-new-tokens",
        type=int,
        default=8,
    )

    args = ap.parse_args()

    root = Path(
        args.root
    )

    source_adapter = (
        root
        / "artifacts"
        / "Zant-LLM-v5_9_25-first-token-logit-margin-rank16-adapter"
    )

    v67_patch = (
        root
        / "artifacts"
        / "Zant-LLM-v6_7-reconstructed-canonical-target-alignment-pilot"
    )

    runtime_script = (
        root
        / "full_training"
        / "v6_36_internal"
        / "runtime_v6_36.py"
    )

    v624_script = (
        root
        / "full_training"
        / "v6_36_internal"
        / "controller_v6_24_frozen.py"
    )

    joint_script = (
        root
        / "full_training"
        / "v6_36_internal"
        / "controller_v6_29_joint.py"
    )

    internal = (
        root
        / "full_training"
        / "v6_51_internal"
    )

    ref_script = (
        internal
        / "reference_v6_49_runtime.py"
    )

    v650_runtime_script = (
        internal
        / "runtime_v6_50_controlled_generation.py"
    )

    bundle_path = (
        root
        / "artifacts"
        / "Zant-LLM-v6_50-controlled-generation-runtime"
        / "v6_50_controlled_generation_runtime_bundle.pt"
    )

    rt = load_module(
        runtime_script,
        "v651_infer_rt",
    )

    ref = load_module(
        ref_script,
        "v651_infer_ref",
    )

    v650rt = load_module(
        v650_runtime_script,
        "v651_infer_runtime",
    )

    v624mod = load_module(
        v624_script,
        "v651_infer_v624",
    )

    jointmod = load_module(
        joint_script,
        "v651_infer_joint",
    )

    import torch

    torch.backends.cuda.enable_flash_sdp(
        False
    )
    torch.backends.cuda.enable_mem_efficient_sdp(
        False
    )
    torch.backends.cuda.enable_math_sdp(
        True
    )

    tok, model, info = rt.load_base_with_v67_residual(
        Path(
            args.base_model
        ),
        source_adapter,
        v67_patch,
    )

    model.eval()

    for p in model.parameters():
        p.requires_grad_(
            False
        )

    bundle = torch.load(
        bundle_path,
        map_location="cpu",
        weights_only=False,
    )

    bridge = bundle[
        "bridge"
    ]

    train_states_tensor = bundle[
        "plan_train_prompt_states"
    ].float()

    train_states = [
        train_states_tensor[
            i
        ]
        for i in range(
            int(
                train_states_tensor.shape[
                    0
                ]
            )
        )
    ]

    train_labels = [
        int(
            x
        )
        for x in bundle[
            "plan_train_labels"
        ].tolist()
    ]

    pids = ref.prompt_ids(
        tok,
        args.prompt,
    )

    state = ref.capture_raw_states(
        torch,
        model,
        rt,
        [
            (
                (
                    "USER",
                    "PROMPT",
                ),
                pids,
            )
        ],
    )[
        (
            "USER",
            "PROMPT",
        )
    ]

    plan, plan_conf = ref.plan_knn(
        torch,
        train_states,
        train_labels,
        state,
    )

    Wcpu = (
        model.get_output_embeddings()
        .weight
        .detach()
        .float()
        .cpu()
    )

    joint = ref.load_joint_controller(
        torch,
        rt,
        v624mod,
        jointmod,
        root,
    )

    pred, steps, fallback_count = v650rt.safe_live_generate(
        torch,
        model,
        rt,
        jointmod,
        joint,
        ref,
        {
            "pids": pids,
        },
        state,
        plan,
        plan_conf,
        Wcpu,
        bridge[
            "projection_matrix"
        ].float(),
        dict(
            bridge[
                "feature_weights"
            ]
        ),
        bridge[
            "state_dict"
        ][
            "weight"
        ].float(),
        float(
            bridge[
                "residual_clip"
            ]
        ),
        float(
            bundle[
                "gate"
            ][
                "beta"
            ]
        ),
        float(
            bundle[
                "gate"
            ][
                "threshold"
            ]
        ),
        mode=args.mode,
        max_new_tokens=max(
            1,
            int(
                args.max_new_tokens
            ),
        ),
    )

    result = {
        "ok": True,
        "mode": args.mode,
        "prompt": args.prompt,
        "predicted_plan": int(
            plan
        ),
        "plan_confidence": float(
            plan_conf
        ),
        "generated_token_ids": [
            int(
                x
            )
            for x in pred
        ],
        "text": tok.decode(
            pred,
            skip_special_tokens=True,
        ),
        "fallback_count": int(
            fallback_count
        ),
        "steps": steps,
    }

    print(
        json.dumps(
            result,
            ensure_ascii=False,
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
