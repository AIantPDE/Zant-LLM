from pathlib import Path
import argparse
import subprocess
import sys


def run(cmd):
    print(
        "RUN="
        + " ".join(
            str(
                x
            )
            for x in cmd
        ),
        flush=True,
    )

    p = subprocess.run(
        cmd
    )

    if p.returncode != 0:
        raise SystemExit(
            p.returncode
        )


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument(
        "--root",
        required=True,
    )
    ap.add_argument(
        "--base-model",
        required=True,
    )
    ap.add_argument(
        "--source-adapter",
        required=True,
    )
    ap.add_argument(
        "--v67-patch",
        required=True,
    )
    args = ap.parse_args()

    root = Path(
        args.root
    )

    py = sys.executable

    internal = (
        root
        / "full_training"
        / "v6_51_internal"
    )

    runtime = (
        root
        / "full_training"
        / "v6_36_internal"
        / "runtime_v6_36.py"
    )

    v624_script = (
        root
        / "full_training"
        / "v6_36_internal"
        / "controller_v6_24_frozen.py"
    )

    joint_script = (
        root
        / "full_training"
        / "v6_36_internal"
        / "controller_v6_29_joint.py"
    )

    reference_script = (
        internal
        / "reference_v6_49_runtime.py"
    )

    v650_runtime = (
        internal
        / "runtime_v6_50_controlled_generation.py"
    )

    outdir = (
        root
        / "diagnostics"
        / "v6_51_controlled_generation_generalization_and_runtime_robustness_milestone"
    )

    report = (
        outdir
        / "v6_51_generalization_and_robustness_report.json"
    )

    print(
        "========== ZANT-LLM v6.51 GENERALIZATION + RUNTIME ROBUSTNESS =========="
    )
    print(
        "NO_MODEL_TRAINING=True"
    )
    print(
        "SOURCE_V6_50_COMPLETE=True"
    )
    print(
        "OBJECTIVE=UNSEEN_DEV_GENERALIZATION+LATENCY_MEMORY+FALLBACK_STRESS+INFERENCE_PACKAGE_VALIDATION"
    )
    print(
        "RETAINED_HOLDOUT_EVALUATED=False"
    )
    print(
        "NO_GITHUB_PUSH=True"
    )

    run(
        [
            py,
            str(
                internal
                / "evaluate_v6_51_generalization_and_robustness.py"
            ),
            "--root",
            str(
                root
            ),
            "--base-model",
            args.base_model,
            "--source-adapter",
            args.source_adapter,
            "--v67-patch",
            args.v67_patch,
            "--runtime-script",
            str(
                runtime
            ),
            "--v624-controller-script",
            str(
                v624_script
            ),
            "--joint-controller-script",
            str(
                joint_script
            ),
            "--reference-runtime-script",
            str(
                reference_script
            ),
            "--v650-runtime-script",
            str(
                v650_runtime
            ),
            "--diagnostics-dir",
            str(
                outdir
            ),
        ]
    )

    run(
        [
            py,
            str(
                internal
                / "route_v6_51.py"
            ),
            "--report",
            str(
                report
            ),
            "--runtime-script",
            str(
                runtime
            ),
            "--diagnostics-dir",
            str(
                outdir
            ),
        ]
    )

    print(
        "V6_51_PROCESS_EXIT=0"
    )

    print(
        "========== v6.51 ONE-CLICK DONE =========="
    )


if __name__ == "__main__":
    main()
