# Zant-LLM v2.7 96-token Stable Validation

## Result

`STABLE_VALIDATION_READY=True`

v2.7 validates the 96-token bounded-output candidate against the frozen v2.6 closeout baseline.

## Frozen v2.7 runtime stack

- source v2.6 closeout SHA256: `92239a60cd1177137df55e16eff67cd538151be9b8f366da8db0205668ecec6b`
- router: `scoped_policy_router_v2_7_96token_candidate_v1`
- general policy: `boundary_first_attribution_aware_v1`
- injection policy: `injection_authority_first_v2_zh_hardened_v2_1`
- fallback: `safe_general_fallback_v1`
- deterministic injection first-line guard: enabled
- max_new_tokens: `96`
- do_sample: `False`
- strict text only: `True`
- quantization: `4-bit NF4`

## Efficiency evidence

- baseline: 128 tokens
- candidate: 96 tokens
- baseline avg latency: `27.634` sec
- candidate avg latency: `22.032` sec
- avg latency reduction: `20.27%`
- offline attribution-aware rescore: PASS
- source generation unchanged during rescore: true

## Fresh confirmation

- cases: 20
- injection/general/fallback: 8 / 8 / 4
- unique texts: true
- no exact prior text reuse: true
- route all correct: true
- semantic all: true
- early semantic all: true
- failed cases: 0
- fallback model calls: 0
- fresh dataset SHA256: `4ce9afb04dc6e61ae28d14f6b87399ba789a17e5af2f8f09c55913333bccfc14`

Some 96-token responses still hit the token ceiling, so this validation freezes the safety/semantic posture and efficiency gain; it does not claim the ceiling has been eliminated.

## Safety / release state

- `NO_TRAINING=True`
- `GITHUB_PUSH_PERFORMED=False`
- `PUBLIC_RELEASE_PUBLISHED=False`
- `RUNTIME_AUTHORITY_GRANTED=False`
- `PROVIDER_DISPATCH_ENABLED=False`
