# Zant-LLM v2.7 96-token Stable Closeout

## Status

`STABLE_CLOSEOUT_READY=True`

v2.7 closes the runtime-efficiency cycle by validating and freezing a 96-token bounded-output profile on top of the v2.6 stable closeout.

## Frozen runtime stack

- source v2.6 closeout SHA256: `92239a60cd1177137df55e16eff67cd538151be9b8f366da8db0205668ecec6b`
- router: `scoped_policy_router_v2_7_96token_candidate_v1`
- general policy: `boundary_first_attribution_aware_v1`
- injection policy: `injection_authority_first_v2_zh_hardened_v2_1`
- fallback policy: `safe_general_fallback_v1`
- deterministic injection first-line guard: enabled
- max_new_tokens: `96`
- do_sample: `False`
- strict text only: `True`
- quantization: `4-bit NF4`

## Validation evidence

Stable Validation ZIP SHA256:

`eef6f99037373624627b15d604476fe67d2a7713831fb29613da22d3933283ac`

Fresh 96-token Confirmation Dataset SHA256:

`4ce9afb04dc6e61ae28d14f6b87399ba789a17e5af2f8f09c55913333bccfc14`

Adapter Model SHA256:

`c509c640a3a7653b9536078bd25fddc22f2b2cdaa2eb22a45272ad4ffe077314`

Adapter Config SHA256:

`cf2bd15f43a766bdce290604a6b6a08eaf4ebabf6bd04632b94e01bd7c587898`

Average latency reduction versus the 128-token baseline:

`20.27%`

The initial A/B evaluator false negatives were preserved as historical evidence and corrected by an attribution-aware offline rescore over unchanged source generations.

## Important limitation

Some responses still hit the 96-token ceiling. The closeout freezes the demonstrated safety/semantic posture and latency improvement; it does not claim the ceiling has been eliminated.

## Safety / release state

- `NO_TRAINING=True`
- `GITHUB_PUSH_PERFORMED=False`
- `PUBLIC_RELEASE_PUBLISHED=False`
- `RUNTIME_AUTHORITY_GRANTED=False`
- `PROVIDER_DISPATCH_ENABLED=False`
