# Zant-LLM v2.8 Early Completion Stable Validation

## Result

`STABLE_VALIDATION_READY=True`

v2.8 validates the `concise_early_completion_prompt_v1_1` profile on top of the frozen v2.7 closeout.

## Frozen runtime stack

- source v2.7 closeout SHA256: `b5eadd02adcaea23d58bcb6a68ea7f9e1be2935569ebe0895f0c626d9e8da27b`
- router: `scoped_policy_router_v2_8_early_completion_v1_1`
- profile: `concise_early_completion_prompt_v1_1`
- general policy: `boundary_first_attribution_aware_v1`
- injection policy: `injection_authority_first_v2_zh_hardened_v2_1`
- fallback: `safe_general_fallback_v1`
- deterministic injection first-line guard: enabled
- max_new_tokens: `96`
- do_sample: `False`
- strict text only: `True`
- quantization: `4-bit NF4`

## A/B and fix evidence

The original early-completion candidate improved efficiency but failed two authority-boundary semantic cases. That original failed report is preserved.

Fix v1.1 reused the original baseline unchanged and regenerated only the candidate:
- semantic preserved: true
- failed candidate cases: 0
- average token reduction: `28.62%`
- average latency reduction: `28.47%`
- hit-max count: `5 -> 3`
- EOS count: `3 -> 5`

## Fresh confirmation

- cases: 20
- injection/general/fallback: 8 / 8 / 4
- unique texts: true
- no exact prior text reuse: true
- semantic strict pass: true
- efficiency pass: true
- average generated tokens: `58.375`
- average model latency: `16.068` sec
- hit-max count: `5`
- EOS count: `11 / 16`
- fresh dataset SHA256: `292912a7550bd70bf2ba6a9cba723906819c5bd629311e548b08c9334784b044`

The efficiency thresholds are validated for this test set. In particular, hit-max count and EOS count meet the acceptance thresholds but do not establish that token-ceiling behavior is eliminated universally.

## Safety / release state

- `NO_TRAINING=True`
- `GITHUB_PUSH_PERFORMED=False`
- `PUBLIC_RELEASE_PUBLISHED=False`
- `RUNTIME_AUTHORITY_GRANTED=False`
- `PROVIDER_DISPATCH_ENABLED=False`
