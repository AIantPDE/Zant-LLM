# Zant-LLM v2.8 Early Completion Stable Closeout

## Status

`STABLE_CLOSEOUT_READY=True`

v2.8 closes the Early Completion cycle on top of the frozen v2.7 closeout.

## Frozen runtime stack

- source v2.7 closeout SHA256: `b5eadd02adcaea23d58bcb6a68ea7f9e1be2935569ebe0895f0c626d9e8da27b`
- router: `scoped_policy_router_v2_8_early_completion_v1_1`
- profile: `concise_early_completion_prompt_v1_1`
- general policy: `boundary_first_attribution_aware_v1`
- injection policy: `injection_authority_first_v2_zh_hardened_v2_1`
- fallback policy: `safe_general_fallback_v1`
- deterministic injection first-line guard: enabled
- max_new_tokens: `96`
- do_sample: `False`
- strict text only: `True`
- quantization: `4-bit NF4`

## Stable Validation source

Stable Validation ZIP SHA256:

`06c50f3d7cd13041ba95a2aef6a5fad097c1f9b257b1758822e1280d43d1244f`

Fresh Confirmation Dataset SHA256:

`292912a7550bd70bf2ba6a9cba723906819c5bd629311e548b08c9334784b044`

Adapter Model SHA256:

`c509c640a3a7653b9536078bd25fddc22f2b2cdaa2eb22a45272ad4ffe077314`

Adapter Config SHA256:

`cf2bd15f43a766bdce290604a6b6a08eaf4ebabf6bd04632b94e01bd7c587898`

## Efficiency evidence

Fix v1.1:
- average token reduction: `28.62%`
- average latency reduction: `28.47%`

Fresh Confirmation:
- average generated tokens: `58.375`
- average model latency: `16.068` sec
- hit-max count: `5`
- EOS count: `11 / 16`

## Historical evidence

The initial v2.8 Early Completion candidate improved efficiency but failed two authority-boundary semantic cases.
That failed report remains preserved in the Stable Validation evidence tree.

Fix v1.1 corrected the prompt-level semantic gap without training and without modifying the v2.7 frozen baseline.

## Limitation

The 96-token ceiling is not eliminated. Fresh Confirmation reached the accepted threshold of 5 hit-max cases and 11 EOS completions out of 16 model-generated cases.
This closeout freezes the demonstrated safety, semantic correctness, and efficiency profile only.

## Safety / release state

- `NO_TRAINING=True`
- `GITHUB_PUSH_PERFORMED=False`
- `PUBLIC_RELEASE_PUBLISHED=False`
- `RUNTIME_AUTHORITY_GRANTED=False`
- `PROVIDER_DISPATCH_ENABLED=False`
