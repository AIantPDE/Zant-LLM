Zant-LLM v6.14 — Semantic-Family Output-Projection Redesign Milestone

Authoritative v6.13 result
--------------------------
v6.13 is COMPLETE / CLOSED.

- semantic-family count = 10
- family-plan positive-vs-negative wins = 20/20
- TOP10 = 5/20
- TOP32 = 6/20
- TOP64 = 11/20
- usable rank<=64 AND win = 11/20
- mean rank = 3584.35
- mean margin = +8.2814453125
- training authorized = False

Diagnosis:
SEMANTIC_FAMILY_RELATIVE_SIGNAL_EXISTS_BUT_ABSOLUTE_TOKEN_ACCESS_REMAINS_WEAK

Interpretation
--------------
The semantic-family layer plan can separate criterion-valid positive tokens from
semantic-fail negatives for all 20 anchors, but the desired token is still too
far down the full vocabulary for reliable generation.

v6.14 therefore tests the output-projection hypothesis directly.

NO TRAINING is performed.

Leave-one-out family output direction
-------------------------------------
Each semantic family contains two bilingual anchors.

For a given anchor, v6.14 NEVER uses that anchor's own target vector to build
its intervention direction.

Instead it uses the sibling anchor in the same semantic family:

direction =
    LM_HEAD_WEIGHT[sibling criterion-valid positive first token]
  - LM_HEAD_WEIGHT[sibling semantic-fail negative first token]

The direction is L2 normalized.

This is then added to the evaluated anchor's actual post-final-norm hidden
representation immediately before the LM head.

Intervention strengths:
0.01 / 0.02 / 0.05 / 0.10 / 0.20 / 0.35
times the L2 norm of the current final normalized hidden vector.

This tests whether the output space contains a family-shared cross-lingual
direction that can convert the already-observed relative semantic signal into
usable absolute token rank.

Metrics
-------
Baseline and intervention:
- criterion-valid positive first-token rank
- positive-minus-negative first-token logit margin
- positive-vs-negative win
- TOP10 / TOP32 / TOP64
- coverage success = positive wins AND rank <= 64

One strength is selected per semantic family for this ORACLE DIAGNOSTIC.
It is not a production inference rule.

Automatic v6.15 route
---------------------
Coverage >=16/20 and wins >=16/20:
  -> v6.15 family-output-projection router training

Wins >=16/20 and TOP32 >=8/20:
  -> v6.15 family-output low-rank projection training

Wins >=16/20 but absolute rank remains weak:
  -> v6.15 token-access output-head redesign

Otherwise:
  -> v6.15 semantic-state reconstruction

Retained holdout stays closed.
No GitHub push.
