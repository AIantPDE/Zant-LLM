from pathlib import Path
import argparse,json,hashlib,importlib.util,statistics,gc
from collections import defaultdict

EXPECTED_V613_PLAN_SHA="c4fa272e248bf4cd12b23d0c69abbaf8881dd532564df7a5efedb1deb8c5d2f5"
EXPECTED_V613_SUMMARY_SHA="48f283e4829af806b0fd8eb08556046f337d2f23496f8c953e9cc3ee3c860746"
EXPECTED_V69_REPORT_SHA="ccad373c434e536ad109c1079dce704cf29a90894573ad4667b5cc084712331d"
EXPECTED_V69_SUMMARY_SHA="a033d2b35428cbc74c162bb362f2c5e15c727b3acde87b376f915eec3f14d7b9"
EXPECTED_TRAIN_SHA="26a9cdb048c5e695bedcfd2a76d771d4361be79bae37a21e5432c49b4f6d9600"

STRENGTHS=(0.01,0.02,0.05,0.10,0.20,0.35)
RANK_CAP=64

def load_module(path,name):
    spec=importlib.util.spec_from_file_location(name,str(path))
    m=importlib.util.module_from_spec(spec)
    spec.loader.exec_module(m)
    return m

def write_json(path,obj):
    Path(path).parent.mkdir(parents=True,exist_ok=True)
    Path(path).write_text(
        json.dumps(obj,ensure_ascii=False,indent=2)+"\n",
        encoding="utf-8",newline="\n"
    )

def write_jsonl(path,rows):
    Path(path).parent.mkdir(parents=True,exist_ok=True)
    with Path(path).open("w",encoding="utf-8",newline="\n") as f:
        for r in rows:
            f.write(json.dumps(r,ensure_ascii=False,separators=(",",":"))+"\n")

def prompt_ids(tok,prompt):
    try:
        txt=tok.apply_chat_template(
            [{"role":"user","content":prompt}],
            tokenize=False,add_generation_prompt=True
        )
        return tok(txt,add_special_tokens=False).input_ids
    except Exception:
        return tok("User: "+prompt+"\nAssistant: ",add_special_tokens=False).input_ids

def first_id(tok,text):
    ids=tok(str(text).strip(),add_special_tokens=False).input_ids
    if not ids:
        raise RuntimeError("Empty tokenization")
    return int(ids[0])

def score(logits,pos_id,neg_id):
    pos=logits[int(pos_id)]
    rank=int((logits>pos).sum().item())+1
    margin=float((pos-logits[int(neg_id)]).item())
    return rank,margin

def norm1(x):
    return x.float().pow(2).sum().sqrt().clamp_min(1e-6)

def stat_rows(xs):
    ranks=[int(x["positive_first_token_rank"]) for x in xs]
    margins=[float(x["positive_minus_negative_first_token_logit"]) for x in xs]
    wins=[bool(x["positive_beats_negative_first_token"]) for x in xs]
    return {
        "rows":len(xs),
        "coverage_success_count":sum(
            int(bool(x["positive_beats_negative_first_token"]) and int(x["positive_first_token_rank"])<=RANK_CAP)
            for x in xs
        ),
        "positive_vs_negative_win_count":sum(int(x) for x in wins),
        "top10_count":sum(int(x<=10) for x in ranks),
        "top32_count":sum(int(x<=32) for x in ranks),
        "top64_count":sum(int(x<=64) for x in ranks),
        "mean_rank":float(statistics.mean(ranks)),
        "mean_margin":float(statistics.mean(margins)),
    }

def choose_strength(stats):
    return min(
        stats,
        key=lambda x:(
            -int(x["coverage_success_count"]),
            -int(x["positive_vs_negative_win_count"]),
            -int(x["top32_count"]),
            float(x["mean_rank"]),
            -float(x["mean_margin"]),
            float(x["strength"]),
        )
    )

def main():
    ap=argparse.ArgumentParser()
    for k in (
        "root","base-model","source-adapter","v67-patch",
        "train-file","v69-report","v69-summary","v69-detail","v69-family",
        "v613-plan","v613-summary","runtime-script"
    ):
        ap.add_argument("--"+k,required=True)
    a=ap.parse_args()

    rt=load_module(a.runtime_script,"v614_runtime")
    root=Path(a.root)

    trainf=Path(a.train_file)
    r69p=Path(a.v69_report)
    s69p=Path(a.v69_summary)
    d69p=Path(a.v69_detail)
    f69p=Path(a.v69_family)
    p613=Path(a.v613_plan)
    s613=Path(a.v613_summary)

    for p in (
        Path(a.base_model),Path(a.source_adapter),Path(a.v67_patch),
        trainf,r69p,s69p,d69p,f69p,p613,s613
    ):
        if not p.exists():
            raise SystemExit("Missing required source: "+str(p))

    if rt.sha256_file(p613)!=EXPECTED_V613_PLAN_SHA:
        raise SystemExit("v6.13 plan SHA mismatch")
    if rt.sha256_file(s613)!=EXPECTED_V613_SUMMARY_SHA:
        raise SystemExit("v6.13 summary SHA mismatch")
    if rt.sha256_file(r69p)!=EXPECTED_V69_REPORT_SHA:
        raise SystemExit("v6.9 report SHA mismatch")
    if rt.sha256_file(s69p)!=EXPECTED_V69_SUMMARY_SHA:
        raise SystemExit("v6.9 summary SHA mismatch")
    if rt.sha256_file(trainf)!=EXPECTED_TRAIN_SHA:
        raise SystemExit("train100 SHA mismatch")

    r69=rt.read_json(r69p)
    if rt.sha256_file(d69p)!=r69.get("detail_file_sha256"):
        raise SystemExit("v6.9 detail SHA mismatch")
    if rt.sha256_file(f69p)!=r69.get("target_family_candidate_file_sha256"):
        raise SystemExit("v6.9 family SHA mismatch")

    p13=rt.read_json(p613)
    s13=rt.read_json(s613)
    if s13.get("milestone_complete") is not True:
        raise SystemExit("v6.13 not complete")
    if s13.get("milestone_status")!="SEMANTIC_FAMILY_RELATIVE_SIGNAL_EXISTS_BUT_ABSOLUTE_TOKEN_ACCESS_REMAINS_WEAK":
        raise SystemExit("v6.13 classification mismatch")
    if int(s13.get("family_plan_positive_vs_negative_win_count",-1))!=20:
        raise SystemExit("Expected v6.13 wins=20/20")
    if int(s13.get("family_plan_usable_rank64_and_win_count",-1))!=11:
        raise SystemExit("Expected v6.13 usable rank64+win=11/20")
    if s13.get("training_authorized") is not False:
        raise SystemExit("v6.13 should not authorize training")
    if s13.get("next_milestone")!="v6.14-semantic-family-output-projection-redesign-milestone":
        raise SystemExit("v6.13 route mismatch")

    train_rows=rt.read_jsonl(trainf)
    anchors=[r for r in train_rows if r.get("v5_9_2_role")=="residual_anchor"]
    if len(anchors)!=20:
        raise SystemExit("Expected 20 anchors")
    fam_target={str(r.get("source_case_id")):r for r in rt.read_jsonl(f69p)}
    detail={str(r.get("id")):r for r in rt.read_jsonl(d69p)}
    by_family=defaultdict(list)
    for r in anchors:
        by_family[rt.family(r)].append(r)
    if len(by_family)!=10 or any(len(v)!=2 for v in by_family.values()):
        raise SystemExit("Expected 10 semantic families with 2 anchors each")

    print("========== ZANT-LLM v6.14 SEMANTIC-FAMILY OUTPUT-PROJECTION REDESIGN ==========")
    print("NO_TRAINING=True")
    print("NO_NEW_RULES=True")
    print("SOURCE_V6_13_COMPLETE=True")
    print("SOURCE_V6_13_FAMILY_WINS=20/20")
    print("SOURCE_V6_13_USABLE_RANK64_AND_WIN=11/20")
    print("SOURCE_V6_13_TRAINING_AUTHORIZED=False")
    print("DIAGNOSTIC=LEAVE_ONE_OUT_FAMILY_OUTPUT_DIRECTION")
    print("DIRECTION_SOURCE=SIBLING_POSITIVE_TOKEN_MINUS_SIBLING_NEGATIVE_TOKEN_LM_HEAD_VECTOR")
    print("INTERVENTION_POINT=POST_FINAL_NORM_PRE_LM_HEAD")
    print("STRENGTHS="+json.dumps(STRENGTHS))
    print("RANK_CAP="+str(RANK_CAP))
    print("RETAINED_HOLDOUT_EVALUATED=False")
    print("NO_GITHUB_PUSH=True")

    import torch
    torch.backends.cuda.enable_flash_sdp(False)
    torch.backends.cuda.enable_mem_efficient_sdp(False)
    torch.backends.cuda.enable_math_sdp(True)

    tok,model,info=rt.load_base_with_v67_residual(
        Path(a.base_model),Path(a.source_adapter),Path(a.v67_patch)
    )
    final_norm=info["_final_norm"]
    lm_head=model.get_output_embeddings()
    if lm_head is None or not hasattr(lm_head,"weight"):
        raise SystemExit("LM head weight is not directly accessible")

    captured={}
    def capture_norm(module,args,out):
        h=rt.extract_hidden(out)
        captured["z"]=h[:,-1,:].detach()
    handle=final_norm.register_forward_hook(capture_norm)

    # Pre-tokenize family sibling directions.
    pair_info={}
    for family_name,rows in by_family.items():
        for r in rows:
            rid=rt.cid(r)
            sibling=rows[1] if rt.cid(rows[0])==rid else rows[0]
            sid=rt.cid(sibling)

            this_fr=fam_target.get(rid)
            this_dr=detail.get(rid)
            sib_fr=fam_target.get(sid)
            sib_dr=detail.get(sid)
            if None in (this_fr,this_dr,sib_fr,sib_dr):
                raise SystemExit("Missing v6.9 pair evidence for family "+family_name)

            pos=str(this_fr.get("target_family_candidate") or "").strip()
            neg=str(this_dr.get("generated_text") or "").strip()
            spos=str(sib_fr.get("target_family_candidate") or "").strip()
            sneg=str(sib_dr.get("generated_text") or "").strip()
            if not pos or not neg or not spos or not sneg:
                raise SystemExit("Empty family projection evidence for "+family_name)

            pair_info[rid]={
                "family":family_name,
                "sibling_id":sid,
                "pos_id":first_id(tok,pos),
                "neg_id":first_id(tok,neg),
                "sibling_pos_id":first_id(tok,spos),
                "sibling_neg_id":first_id(tok,sneg),
            }

    detail_rows=[]
    family_strength_rows=defaultdict(lambda: defaultdict(list))
    baseline_rows=[]

    weight=lm_head.weight
    for i,r in enumerate(anchors,1):
        rid=rt.cid(r)
        info_r=pair_info[rid]
        prompt,_=rt.prompt_target(r)
        pids=prompt_ids(tok,prompt)
        ii=torch.tensor([pids],dtype=torch.long,device="cuda:0")
        mm=torch.ones_like(ii)
        captured.clear()

        with torch.no_grad():
            oo=model(input_ids=ii,attention_mask=mm,use_cache=False,return_dict=True)
        if "z" not in captured:
            raise RuntimeError("Final norm capture missing for "+rid)
        z=captured["z"].float()

        # Baseline score at actual final representation.
        with torch.no_grad():
            base_logits=lm_head(z.to(weight.dtype))[0].float()
        br,bm=score(base_logits,info_r["pos_id"],info_r["neg_id"])
        baseline_rows.append({
            "id":rid,
            "family":info_r["family"],
            "positive_first_token_rank":br,
            "positive_minus_negative_first_token_logit":bm,
            "positive_beats_negative_first_token":bool(bm>0),
        })

        # Leave-one-out family direction from the bilingual sibling.
        wpos=weight[info_r["sibling_pos_id"]].detach().float()
        wneg=weight[info_r["sibling_neg_id"]].detach().float()
        direction=wpos-wneg
        direction=direction/(direction.pow(2).sum().sqrt().clamp_min(1e-6))
        znorm=norm1(z[0])

        mixed_batch=[]
        for strength in STRENGTHS:
            mixed=z[0]+(float(strength)*znorm*direction)
            mixed_batch.append(mixed)
        batch=torch.stack(mixed_batch,dim=0).to(weight.dtype)

        with torch.no_grad():
            logits_batch=lm_head(batch).float()

        for j,strength in enumerate(STRENGTHS):
            rank,margin=score(
                logits_batch[j],info_r["pos_id"],info_r["neg_id"]
            )
            rec={
                "id":rid,
                "language":rt.lang(r),
                "family":info_r["family"],
                "sibling_direction_source_id":info_r["sibling_id"],
                "strength":float(strength),
                "baseline_rank":br,
                "baseline_margin":bm,
                "positive_first_token_rank":rank,
                "positive_minus_negative_first_token_logit":margin,
                "positive_beats_negative_first_token":bool(margin>0),
                "coverage_success":bool(margin>0 and rank<=RANK_CAP),
            }
            detail_rows.append(rec)
            family_strength_rows[info_r["family"]][float(strength)].append(rec)

        print(
            f"CASE_{i}_OF_20={rid} FAMILY={info_r['family']} "
            f"BASE_RANK={br} BASE_MARGIN={bm} "
            f"SIBLING={info_r['sibling_id']}"
        )

        del ii,mm,oo,z,base_logits,wpos,wneg,direction,batch,logits_batch
        torch.cuda.empty_cache()

    handle.remove()

    # Select one output-projection strength per family using both bilingual rows.
    family_plan={}
    for family_name,strength_map in sorted(family_strength_rows.items()):
        stats=[]
        for strength,xs in sorted(strength_map.items()):
            st=stat_rows(xs)
            st["strength"]=float(strength)
            stats.append(st)
        family_plan[family_name]=choose_strength(stats)

    selected=[]
    for r in anchors:
        rid=rt.cid(r)
        family_name=rt.family(r)
        strength=float(family_plan[family_name]["strength"])
        xs=[
            x for x in detail_rows
            if x["id"]==rid and abs(float(x["strength"])-strength)<1e-12
        ]
        if len(xs)!=1:
            raise RuntimeError("Family strength lookup mismatch for "+rid)
        selected.append(xs[0])

    selected_stats=stat_rows(selected)
    base_stats=stat_rows(baseline_rows)
    distinct_strengths=sorted(set(float(x["strength"]) for x in family_plan.values()))

    if (
        selected_stats["coverage_success_count"]>=16
        and selected_stats["positive_vs_negative_win_count"]>=16
    ):
        cls="FAMILY_OUTPUT_PROJECTION_ORACLE_RECOVERS_USABLE_ABSOLUTE_TOKEN_ACCESS"
        nxt="v6.15-family-output-projection-router-training-milestone"
        auth=True
    elif (
        selected_stats["positive_vs_negative_win_count"]>=16
        and selected_stats["top32_count"]>=8
    ):
        cls="FAMILY_OUTPUT_PROJECTION_RECOVERS_RELATIVE_CONTROL_WITH_PARTIAL_ABSOLUTE_ACCESS"
        nxt="v6.15-family-output-low-rank-projection-training-milestone"
        auth=True
    elif selected_stats["positive_vs_negative_win_count"]>=16:
        cls="FAMILY_OUTPUT_DIRECTION_SEPARATES_BUT_TOKEN_RANK_REMAINS_TOO_WEAK"
        nxt="v6.15-token-access-output-head-redesign-milestone"
        auth=False
    else:
        cls="FAMILY_OUTPUT_PROJECTION_DIRECTIONS_DO_NOT_RECOVER_CAUSAL_TOKEN_ACCESS"
        nxt="v6.15-semantic-state-reconstruction-milestone"
        auth=False

    work=root/"diagnostics/v6_14_semantic_family_output_projection_redesign_milestone"
    work.mkdir(parents=True,exist_ok=True)
    detailp=work/"v6_14_output_projection_intervention_detail.jsonl"
    planp=work/"v6_14_family_output_projection_plan.json"
    summaryp=work/"v6_14_milestone_summary.json"

    write_jsonl(detailp,detail_rows)
    write_json(planp,{
        "schema":"ZANT_LLM_V6_14_FAMILY_OUTPUT_PROJECTION_PLAN_V1",
        "method":"LEAVE_ONE_OUT_BILINGUAL_FAMILY_OUTPUT_DIRECTION",
        "direction_definition":"sibling_lm_head_positive_minus_sibling_lm_head_negative",
        "intervention_point":"POST_FINAL_NORM_PRE_LM_HEAD",
        "strengths":list(STRENGTHS),
        "rank_cap":RANK_CAP,
        "family_plan":family_plan,
        "distinct_strengths":distinct_strengths,
        "baseline":base_stats,
        "selected_family_plan":selected_stats,
        "classification":cls,
        "training_authorized":auth,
        "retained_holdout_evaluated":False,
        "next_milestone":nxt,
    })
    write_json(summaryp,{
        "schema":"ZANT_LLM_V6_14_SEMANTIC_FAMILY_OUTPUT_PROJECTION_REDESIGN_MILESTONE_V1",
        "milestone_complete":True,
        "no_training":True,
        "source_v6_13_complete":True,
        "source_v6_13_family_plan_wins":20,
        "source_v6_13_usable_rank64_and_win_count":11,
        "baseline_coverage_success_count":base_stats["coverage_success_count"],
        "baseline_positive_vs_negative_win_count":base_stats["positive_vs_negative_win_count"],
        "baseline_top32_count":base_stats["top32_count"],
        "baseline_mean_rank":base_stats["mean_rank"],
        "family_projection_coverage_success_count":selected_stats["coverage_success_count"],
        "family_projection_positive_vs_negative_win_count":selected_stats["positive_vs_negative_win_count"],
        "family_projection_top10_count":selected_stats["top10_count"],
        "family_projection_top32_count":selected_stats["top32_count"],
        "family_projection_top64_count":selected_stats["top64_count"],
        "family_projection_mean_rank":selected_stats["mean_rank"],
        "family_projection_mean_margin":selected_stats["mean_margin"],
        "distinct_family_strengths":distinct_strengths,
        "milestone_status":cls,
        "training_authorized":auth,
        "retained_holdout_opened":False,
        "next_milestone":nxt,
        "github_push_performed":False,
    })

    print("========== V6.14 MILESTONE FINAL ==========")
    print("V6_14_MILESTONE_COMPLETE=True")
    print("NO_TRAINING=True")
    print("BASELINE_COVERAGE_SUCCESS_COUNT="+str(base_stats["coverage_success_count"])+"/20")
    print("BASELINE_POSITIVE_VS_NEGATIVE_WIN_COUNT="+str(base_stats["positive_vs_negative_win_count"])+"/20")
    print("BASELINE_TOP32_COUNT="+str(base_stats["top32_count"])+"/20")
    print("BASELINE_MEAN_RANK="+str(base_stats["mean_rank"]))
    print("FAMILY_PROJECTION_COVERAGE_SUCCESS_COUNT="+str(selected_stats["coverage_success_count"])+"/20")
    print("FAMILY_PROJECTION_POSITIVE_VS_NEGATIVE_WIN_COUNT="+str(selected_stats["positive_vs_negative_win_count"])+"/20")
    print("FAMILY_PROJECTION_TOP10_COUNT="+str(selected_stats["top10_count"])+"/20")
    print("FAMILY_PROJECTION_TOP32_COUNT="+str(selected_stats["top32_count"])+"/20")
    print("FAMILY_PROJECTION_TOP64_COUNT="+str(selected_stats["top64_count"])+"/20")
    print("FAMILY_PROJECTION_MEAN_RANK="+str(selected_stats["mean_rank"]))
    print("FAMILY_PROJECTION_MEAN_MARGIN="+str(selected_stats["mean_margin"]))
    print("DISTINCT_FAMILY_STRENGTHS="+json.dumps(distinct_strengths))
    print("TRAINING_AUTHORIZED="+str(auth))
    print("RETAINED_HOLDOUT_OPENED=False")
    print("MILESTONE_STATUS="+cls)
    print("DETAIL_SHA256="+rt.sha256_file(detailp))
    print("PLAN_SHA256="+rt.sha256_file(planp))
    print("FINAL_SUMMARY_SHA256="+rt.sha256_file(summaryp))
    print("NEXT_MILESTONE="+nxt)
    print("GITHUB_PUSH_PERFORMED=False")

    del model
    gc.collect()
    torch.cuda.empty_cache()

if __name__=="__main__":
    main()
