from pathlib import Path
import json,hashlib

EXPECTED_V5925_ADAPTER_SHA="d7774235993fb996af101424f511237e9a7f1711792e03ff569bc2616b151984"
EXPECTED_V67_PATCH_MANIFEST_SHA="584eaf6d7f2a1d19aad56589d295cffaaf5b11a9937ca81a8c2f7d657f368699"
EXPECTED_V67_PATCH_FILE_SHA="2d3cc438ec3ae08d641ddead86de1fec4f830d20ea34a2cec32bd5652c79e18b"
EXPECTED_V68_PATCH_MANIFEST_SHA="5095bd899a60752b982746aa9c0821e5df0b0c51d026d0d6318140447e4e2e98"
EXPECTED_V68_BRIDGE_FILE_SHA="c115cb57a6767a1dd85e2da5e3814a788249784fcc2aba4e45f884dd1301d440"
SELECTED_BLOCKS=(27,29,33)

def sha256_file(path):
    h=hashlib.sha256()
    with Path(path).open("rb") as f:
        for b in iter(lambda:f.read(1048576),b""):
            h.update(b)
    return h.hexdigest()

def folder_manifest_sha(path):
    excluded={
        "v5_9_training_complete.json","v5_9_3_training_complete.json",
        "v5_9_7_training_complete.json","v5_9_12_training_complete.json",
        "v5_9_18_training_complete.json","v5_9_20_training_complete.json",
        "v5_9_22_training_complete.json","v5_9_25_training_complete.json",
        "v5_9_27_training_complete.json","v5_9_30_training_complete.json",
        "v6_2_training_complete.json","v6_3_block33_training_complete.json",
        "v6_3_block27_training_complete.json","v6_4_training_complete.json",
        "v6_5_training_complete.json","v6_7_training_complete.json",
        "v6_8_training_complete.json",
        "v6_10_training_complete.json",
        "v6_11_training_complete.json",
        "v6_12_training_complete.json",
        "v6_13_training_complete.json",
        "v6_14_training_complete.json",
    }
    rows=[]
    for p in sorted(Path(path).rglob("*")):
        if p.is_file() and p.name not in excluded:
            rows.append(p.relative_to(path).as_posix()+"\t"+sha256_file(p))
    return hashlib.sha256(("\n".join(rows)+"\n").encode("utf-8")).hexdigest()

def read_json(path):
    return json.loads(Path(path).read_text(encoding="utf-8-sig"))

def read_jsonl(path):
    out=[]
    with Path(path).open("r",encoding="utf-8-sig") as f:
        for i,line in enumerate(f,1):
            line=line.strip()
            if not line:
                continue
            try:
                out.append(json.loads(line))
            except Exception as e:
                raise RuntimeError(f"Invalid JSONL {path}:{i}: {e}")
    return out

def write_json(path,obj):
    Path(path).parent.mkdir(parents=True,exist_ok=True)
    Path(path).write_text(
        json.dumps(obj,ensure_ascii=False,indent=2)+"\n",
        encoding="utf-8",newline="\n"
    )

def write_jsonl(path,rows):
    Path(path).parent.mkdir(parents=True,exist_ok=True)
    with Path(path).open("w",encoding="utf-8",newline="\n") as f:
        for r in rows:
            f.write(json.dumps(r,ensure_ascii=False,separators=(",",":"))+"\n")

def cid(r):
    return str(r.get("source_case_id") or r.get("case_id") or r.get("id") or "")

def lang(r):
    v=str(r.get("language") or r.get("lang") or "").lower()
    if v in ("en","zh"):
        return v
    return "zh" if "_ZH_" in cid(r) else "en"

def family(r):
    return str(r.get("family") or r.get("category") or "unknown")

def prompt_target(r):
    p=r.get("prompt")
    t=r.get("response") or r.get("target") or r.get("answer") or r.get("completion")
    msgs=r.get("messages") or []
    if (p is None or t is None) and isinstance(msgs,list):
        users=[m.get("content","") for m in msgs if str(m.get("role","")).lower() in ("user","human")]
        assists=[m.get("content","") for m in msgs if str(m.get("role","")).lower() in ("assistant","model")]
        if p is None and users:
            p=users[-1]
        if t is None and assists:
            t=assists[-1]
    if p is None or t is None:
        raise ValueError("missing prompt/target for "+cid(r))
    return str(p).strip(),str(t).strip()

def get_attr_parent(root,dotted):
    parts=dotted.split(".")
    cur=root
    for x in parts[:-1]:
        if not hasattr(cur,x):
            return None,None
        cur=getattr(cur,x)
    return cur,parts[-1]

def strip_non_text(model):
    removed=[]
    for name in (
        "model.vision_tower","model.audio_tower","model.embed_vision","model.embed_audio",
        "vision_tower","audio_tower","embed_vision","embed_audio"
    ):
        parent,leaf=get_attr_parent(model,name)
        if parent is not None and hasattr(parent,leaf) and getattr(parent,leaf) is not None:
            try:
                setattr(parent,leaf,None)
                removed.append(name)
            except Exception:
                pass
    return removed

def remaining_non_text(model):
    bad=[]
    for name,_ in model.named_modules():
        low=name.lower()
        if any(k in low for k in ("vision_tower","audio_tower","embed_vision","embed_audio")):
            bad.append(name)
    return sorted(set(bad))

def find_text_layers(model):
    import torch
    cands=[]
    for name,m in model.named_modules():
        if isinstance(m,torch.nn.ModuleList) and len(m)>=35 and "layers" in name.lower():
            if "vision" in name.lower() or "audio" in name.lower():
                continue
            cands.append((name,m))
    if not cands:
        return None,None
    cands.sort(key=lambda x:(len(x[1]),len(x[0])))
    return cands[0]

def find_final_norm(model,layers_name):
    parent_name=layers_name.rsplit(".layers",1)[0]
    parent=model.get_submodule(parent_name) if parent_name else model
    if hasattr(parent,"norm"):
        return parent.norm,parent_name+".norm"
    cands=[]
    for name,m in model.named_modules():
        if ".layers." in name:
            continue
        if name.lower().endswith("norm") and hasattr(m,"weight"):
            cands.append((name,m))
    if not cands:
        return None,None
    cands.sort(key=lambda x:len(x[0]))
    return cands[-1][1],cands[-1][0]

def extract_hidden(out):
    import torch
    if torch.is_tensor(out):
        return out
    if isinstance(out,(tuple,list)) and out and torch.is_tensor(out[0]):
        return out[0]
    if hasattr(out,"last_hidden_state"):
        return out.last_hidden_state
    raise RuntimeError("Could not extract hidden")

def replace_hidden(out,h):
    import torch
    if torch.is_tensor(out):
        return h
    if isinstance(out,tuple):
        return (h,)+tuple(out[1:])
    if isinstance(out,list):
        return [h]+list(out[1:])
    if hasattr(out,"last_hidden_state"):
        out.last_hidden_state=h
        return out
    raise RuntimeError("Could not replace hidden")

class RuntimeResidual:
    def __init__(self,hidden_size,rank,alpha,state,device,dtype):
        import torch
        self.torch=torch
        self.nn=torch.nn
        self.scaling=float(alpha)/int(rank)
        self.blocks={}
        for idx in SELECTED_BLOCKS:
            down=self.nn.Linear(hidden_size,rank,bias=False).to(device=device,dtype=dtype)
            up=self.nn.Linear(rank,hidden_size,bias=False).to(device=device,dtype=dtype)
            down.weight.data.copy_(state[f"{idx}.down.weight"].to(device=device,dtype=dtype))
            up.weight.data.copy_(state[f"{idx}.up.weight"].to(device=device,dtype=dtype))
            down.eval()
            up.eval()
            for p in list(down.parameters())+list(up.parameters()):
                p.requires_grad_(False)
            self.blocks[idx]=(down,up)

    def apply(self,idx,h):
        down,up=self.blocks[idx]
        return h + up(self.torch.tanh(down(h)))*self.scaling

class PromptSemanticBridge:
    def __init__(self,hidden_size=1536,rank=128,alpha=64.0,device="cuda:0",dtype=None,zero_init=True):
        import torch
        if dtype is None:
            dtype=torch.float16
        self.torch=torch
        self.nn=torch.nn
        self.hidden_size=int(hidden_size)
        self.rank=int(rank)
        self.alpha=float(alpha)
        self.scaling=self.alpha/self.rank
        self.module=self.nn.ModuleDict({
            "down":self.nn.Linear(self.hidden_size,self.rank,bias=False),
            "up":self.nn.Linear(self.rank,self.hidden_size,bias=False),
            "gate":self.nn.Linear(self.hidden_size,1,bias=True),
        }).to(device=device,dtype=dtype)
        self.nn.init.normal_(self.module["down"].weight,mean=0.0,std=0.02)
        if zero_init:
            self.nn.init.zeros_(self.module["up"].weight)
            self.nn.init.zeros_(self.module["gate"].weight)
            self.nn.init.zeros_(self.module["gate"].bias)

    def parameters(self):
        return self.module.parameters()

    def named_parameters(self):
        return self.module.named_parameters()

    def state_dict(self):
        return self.module.state_dict()

    def load_state_dict(self,state,strict=True):
        return self.module.load_state_dict(state,strict=strict)

    def train(self):
        self.module.train()

    def eval(self):
        self.module.eval()

    def zero_grad(self,set_to_none=True):
        self.module.zero_grad(set_to_none=set_to_none)

    def apply(self,h):
        # h is already prompt/context conditioned by the full transformer.
        z=self.torch.tanh(self.module["down"](h))
        delta=self.module["up"](z)*self.scaling
        gate=self.torch.sigmoid(self.module["gate"](h))
        return h + (gate*delta)

def normalize_state_keys(raw,prefixes):
    out={}
    for k,v in raw.items():
        nk=k
        for p in prefixes:
            if nk.startswith(p):
                nk=nk[len(p):]
        out[nk]=v
    return out

def load_base_with_v67_residual(base_model,adapter_dir,v67_patch_dir):
    import torch
    from transformers import AutoTokenizer,AutoModelForCausalLM,BitsAndBytesConfig
    from peft import PeftModel
    from safetensors.torch import load_file

    base_model=Path(base_model)
    adapter_dir=Path(adapter_dir)
    v67_patch_dir=Path(v67_patch_dir)

    if folder_manifest_sha(adapter_dir)!=EXPECTED_V5925_ADAPTER_SHA:
        raise SystemExit("v5.9.25 adapter manifest SHA mismatch")
    if folder_manifest_sha(v67_patch_dir)!=EXPECTED_V67_PATCH_MANIFEST_SHA:
        raise SystemExit("v6.7 patch manifest SHA mismatch")
    patch_file=v67_patch_dir/"distributed_residual_adapters.safetensors"
    if sha256_file(patch_file)!=EXPECTED_V67_PATCH_FILE_SHA:
        raise SystemExit("v6.7 patch file SHA mismatch")

    manifest=read_json(v67_patch_dir/"distributed_residual_manifest.json")
    if manifest.get("selected_blocks")!=[27,29,33]:
        raise SystemExit("Unexpected v6.7 distributed block set")
    if int(manifest.get("rank",-1))!=64 or float(manifest.get("alpha",-1))!=128.0:
        raise SystemExit("Unexpected v6.7 distributed residual config")

    tok=AutoTokenizer.from_pretrained(
        str(base_model),trust_remote_code=True,local_files_only=True
    )
    if tok.pad_token is None:
        tok.pad_token=tok.eos_token

    q=BitsAndBytesConfig(
        load_in_4bit=True,
        bnb_4bit_use_double_quant=True,
        bnb_4bit_quant_type="nf4",
        bnb_4bit_compute_dtype=torch.float16
    )
    kw=dict(
        trust_remote_code=True,
        local_files_only=True,
        quantization_config=q,
        device_map={"":0},
        low_cpu_mem_usage=True,
        attn_implementation="eager"
    )
    try:
        base=AutoModelForCausalLM.from_pretrained(
            str(base_model),dtype=torch.float16,**kw
        )
    except TypeError:
        base=AutoModelForCausalLM.from_pretrained(
            str(base_model),torch_dtype=torch.float16,**kw
        )

    removed=strip_non_text(base)
    remaining=remaining_non_text(base)
    if remaining:
        raise SystemExit("STRICT_TEXT_ONLY failed: "+json.dumps(remaining,ensure_ascii=False))

    model=PeftModel.from_pretrained(
        base,str(adapter_dir),is_trainable=False,local_files_only=True
    )
    model.eval()
    for p in model.parameters():
        p.requires_grad_(False)

    layers_name,layers=find_text_layers(model)
    if layers is None or len(layers)<35:
        raise SystemExit("Could not resolve 35 text layers")

    raw=load_file(str(patch_file),device="cpu")
    state=normalize_state_keys(raw,("modules.",))
    runtime=RuntimeResidual(
        hidden_size=int(manifest["hidden_size"]),
        rank=int(manifest["rank"]),
        alpha=float(manifest["alpha"]),
        state=state,
        device="cuda:0",
        dtype=torch.float16
    )
    residual_handles=[]
    for idx in SELECTED_BLOCKS:
        def make_hook(i):
            def hook(module,args,out):
                h=extract_hidden(out)
                return replace_hidden(out,runtime.apply(i,h))
            return hook
        residual_handles.append(layers[idx].register_forward_hook(make_hook(idx)))

    final_norm,final_norm_name=find_final_norm(model,layers_name)
    if final_norm is None:
        raise SystemExit("Could not resolve final text norm")

    info={
        "layers_path":layers_name,
        "text_layer_count":len(layers),
        "hidden_size":int(manifest["hidden_size"]),
        "selected_blocks":[27,29,33],
        "residual_rank":int(manifest["rank"]),
        "residual_alpha":float(manifest["alpha"]),
        "residual_hook_count":len(residual_handles),
        "final_norm_name":final_norm_name,
        "removed_non_text":removed,
        "_residual_runtime":runtime,
        "_residual_handles":residual_handles,
        "_final_norm":final_norm,
    }
    return tok,model,info

def install_bridge_hook(final_norm,bridge):
    def hook(module,args,out):
        h=extract_hidden(out)
        return replace_hidden(out,bridge.apply(h))
    return final_norm.register_forward_hook(hook)

def load_full_v68_runtime(base_model,adapter_dir,v67_patch_dir,v68_bridge_dir):
    import torch
    from safetensors.torch import load_file

    tok,model,info=load_base_with_v67_residual(base_model,adapter_dir,v67_patch_dir)
    bdir=Path(v68_bridge_dir)
    manifest=read_json(bdir/"semantic_bridge_manifest.json")
    raw=load_file(str(bdir/"semantic_bridge.safetensors"),device="cpu")
    state=normalize_state_keys(raw,("module.",))
    bridge=PromptSemanticBridge(
        hidden_size=int(manifest["hidden_size"]),
        rank=int(manifest["rank"]),
        alpha=float(manifest["alpha"]),
        device="cuda:0",
        dtype=torch.float16,
        zero_init=False
    )
    bridge.load_state_dict(state,strict=True)
    bridge.eval()
    for p in bridge.parameters():
        p.requires_grad_(False)

    handle=install_bridge_hook(info["_final_norm"],bridge)
    info.update({
        "bridge_rank":int(manifest["rank"]),
        "bridge_alpha":float(manifest["alpha"]),
        "bridge_scaling":float(manifest["scaling"]),
        "bridge_trainable_params":int(manifest["trainable_params"]),
        "bridge_hook_count":1,
        "_bridge":bridge,
        "_bridge_handle":handle,
    })
    return tok,model,info


def load_v68_runtime_with_trainable_bridge(base_model,adapter_dir,v67_patch_dir,v68_bridge_dir):
    import torch
    from safetensors.torch import load_file

    tok,model,info=load_base_with_v67_residual(base_model,adapter_dir,v67_patch_dir)
    bdir=Path(v68_bridge_dir)

    if folder_manifest_sha(bdir)!=EXPECTED_V68_PATCH_MANIFEST_SHA:
        raise SystemExit("v6.8 bridge manifest SHA mismatch")
    bridge_file=bdir/"semantic_bridge.safetensors"
    if sha256_file(bridge_file)!=EXPECTED_V68_BRIDGE_FILE_SHA:
        raise SystemExit("v6.8 bridge file SHA mismatch")

    manifest=read_json(bdir/"semantic_bridge_manifest.json")
    raw=load_file(str(bridge_file),device="cpu")
    state=normalize_state_keys(raw,("module.",))

    bridge=PromptSemanticBridge(
        hidden_size=int(manifest["hidden_size"]),
        rank=int(manifest["rank"]),
        alpha=float(manifest["alpha"]),
        device="cuda:0",
        dtype=torch.float16,
        zero_init=False
    )
    bridge.load_state_dict(state,strict=True)
    bridge.train()
    for p in bridge.parameters():
        p.requires_grad_(True)

    handle=install_bridge_hook(info["_final_norm"],bridge)
    info.update({
        "bridge_rank":int(manifest["rank"]),
        "bridge_alpha":float(manifest["alpha"]),
        "bridge_scaling":float(manifest["scaling"]),
        "bridge_trainable_params":sum(p.numel() for p in bridge.parameters()),
        "bridge_hook_count":1,
        "_bridge":bridge,
        "_bridge_handle":handle,
    })
    return tok,model,info


class DualSourceSemanticBridge:
    def __init__(self,hidden_size=1536,rank=64,alpha=64.0,device="cuda:0",dtype=None,zero_init=True):
        import torch
        if dtype is None:
            dtype=torch.float16
        self.torch=torch
        self.nn=torch.nn
        self.hidden_size=int(hidden_size)
        self.rank=int(rank)
        self.alpha=float(alpha)
        self.scaling=self.alpha/self.rank
        self.module=self.nn.ModuleDict({
            "src7_down":self.nn.Linear(self.hidden_size,self.rank,bias=False),
            "src7_up":self.nn.Linear(self.rank,self.hidden_size,bias=False),
            "src32_down":self.nn.Linear(self.hidden_size,self.rank,bias=False),
            "src32_up":self.nn.Linear(self.rank,self.hidden_size,bias=False),
            "gate":self.nn.Linear(self.hidden_size,2,bias=True),
        }).to(device=device,dtype=dtype)
        self.nn.init.normal_(self.module["src7_down"].weight,mean=0.0,std=0.02)
        self.nn.init.normal_(self.module["src32_down"].weight,mean=0.0,std=0.02)
        if zero_init:
            self.nn.init.zeros_(self.module["src7_up"].weight)
            self.nn.init.zeros_(self.module["src32_up"].weight)
            self.nn.init.zeros_(self.module["gate"].weight)
            self.nn.init.zeros_(self.module["gate"].bias)
        self.last_token_gate=None
    def parameters(self): return self.module.parameters()
    def named_parameters(self): return self.module.named_parameters()
    def state_dict(self): return self.module.state_dict()
    def load_state_dict(self,state,strict=True): return self.module.load_state_dict(state,strict=strict)
    def train(self): self.module.train()
    def eval(self): self.module.eval()
    def zero_grad(self,set_to_none=True): self.module.zero_grad(set_to_none=set_to_none)
    def apply(self,final_hidden,source7,source32):
        if source7.shape!=final_hidden.shape or source32.shape!=final_hidden.shape:
            raise RuntimeError("dual-source hidden-shape mismatch: final="+str(tuple(final_hidden.shape))+" src7="+str(tuple(source7.shape))+" src32="+str(tuple(source32.shape)))
        z7=self.torch.tanh(self.module["src7_down"](source7))
        z32=self.torch.tanh(self.module["src32_down"](source32))
        d7=self.module["src7_up"](z7)*self.scaling
        d32=self.module["src32_up"](z32)*self.scaling
        gate=self.torch.softmax(self.module["gate"](final_hidden).float(),dim=-1).to(final_hidden.dtype)
        self.last_token_gate=gate[:,-1,:].detach().float().mean(dim=0).cpu()
        return final_hidden+(gate[...,0:1]*d7)+(gate[...,1:2]*d32)

def install_dual_source_bridge(model,bridge,source_layers=(7,32)):
    layers_name,layers=find_text_layers(model)
    if layers is None or len(layers)<33:
        raise SystemExit("Could not resolve source layers for dual bridge")
    final_norm,final_norm_name=find_final_norm(model,layers_name)
    if final_norm is None:
        raise SystemExit("Could not resolve final norm for dual bridge")
    captures={}
    handles=[]
    for idx in source_layers:
        def make_capture(i):
            def hook(module,args,out):
                captures[i]=extract_hidden(out).detach()
            return hook
        handles.append(layers[idx].register_forward_hook(make_capture(idx)))
    def final_hook(module,args,out):
        h=extract_hidden(out)
        if source_layers[0] not in captures or source_layers[1] not in captures:
            raise RuntimeError("dual-source capture missing before final norm")
        return replace_hidden(out,bridge.apply(h,captures[source_layers[0]],captures[source_layers[1]]))
    handles.append(final_norm.register_forward_hook(final_hook))
    return handles,captures,final_norm_name
