from pathlib import Path
import argparse,subprocess,sys

def main():
    ap=argparse.ArgumentParser()
    for k in (
        "root","base-model","source-adapter","v67-patch",
        "train-file","v69-report","v69-summary","v69-detail","v69-family",
        "v613-plan","v613-summary","runtime-script","worker"
    ):
        ap.add_argument("--"+k,required=True)
    a=ap.parse_args()

    print("========== ZANT-LLM v6.14 SEMANTIC-FAMILY OUTPUT-PROJECTION REDESIGN ==========")
    print("NO_TRAINING=True")
    print("NO_NEW_RULES=True")
    print("SOURCE_V6_13_COMPLETE=True")
    print("SOURCE_V6_13_FAMILY_WINS=20/20")
    print("SOURCE_V6_13_USABLE_RANK64_AND_WIN=11/20")
    print("METHOD=LEAVE_ONE_OUT_BILINGUAL_FAMILY_OUTPUT_DIRECTION")
    print("INTERVENTION_POINT=POST_FINAL_NORM_PRE_LM_HEAD")
    print("RETAINED_HOLDOUT_EVALUATED=False")
    print("NO_GITHUB_PUSH=True")

    cmd=[
        Path(sys.executable),a.worker,
        "--root",a.root,
        "--base-model",a.base_model,
        "--source-adapter",a.source_adapter,
        "--v67-patch",a.v67_patch,
        "--train-file",a.train_file,
        "--v69-report",a.v69_report,
        "--v69-summary",a.v69_summary,
        "--v69-detail",a.v69_detail,
        "--v69-family",a.v69_family,
        "--v613-plan",a.v613_plan,
        "--v613-summary",a.v613_summary,
        "--runtime-script",a.runtime_script,
    ]
    print("RUN="+subprocess.list2cmdline([str(x) for x in cmd]))
    p=subprocess.run([str(x) for x in cmd])
    if p.returncode!=0:
        raise SystemExit("v6.14 worker failed exit="+str(p.returncode))
    print("V6_14_PROCESS_EXIT=0")
    print("========== v6.14 ONE-CLICK DONE ==========")

if __name__=="__main__":
    main()
