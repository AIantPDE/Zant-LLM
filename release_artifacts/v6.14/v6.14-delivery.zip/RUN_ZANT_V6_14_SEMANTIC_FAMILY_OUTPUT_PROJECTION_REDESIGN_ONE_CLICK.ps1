$ErrorActionPreference = "Stop"

$ROOT = "C:\Users\Administrator\Desktop\Zant-LLM"
$PYTHON = "C:\Users\Administrator\AppData\Local\Programs\Python\Python311\python.exe"
$BASE_MODEL = "E:\gemma-4-E2B-it"

$SOURCE_ADAPTER = Join-Path $ROOT "artifacts\Zant-LLM-v5_9_25-first-token-logit-margin-rank16-adapter"
$V67_PATCH = Join-Path $ROOT "artifacts\Zant-LLM-v6_7-reconstructed-canonical-target-alignment-pilot"
$TRAIN_FILE = Join-Path $ROOT "full_training\v5_9_2_residual_training_dataset\train_v5_9_2_round2_100.jsonl"

$V69_REPORT = Join-Path $ROOT "diagnostics\v6_9_semantic_criterion_and_target_family_redesign_milestone\v6_9_semantic_criterion_report.json"
$V69_SUMMARY = Join-Path $ROOT "diagnostics\v6_9_semantic_criterion_and_target_family_redesign_milestone\v6_9_milestone_summary.json"
$V69_DETAIL = Join-Path $ROOT "diagnostics\v6_9_semantic_criterion_and_target_family_redesign_milestone\v6_9_semantic_criterion_audit_detail.jsonl"
$V69_FAMILY = Join-Path $ROOT "full_training\v6_9_semantic_criterion_and_target_family_redesign\v6_9_target_family_candidates_20.jsonl"

$V613_PLAN = Join-Path $ROOT "diagnostics\v6_13_semantic_family_mixture_reconstruction_milestone\v6_13_semantic_family_layer_plan.json"
$V613_SUMMARY = Join-Path $ROOT "diagnostics\v6_13_semantic_family_mixture_reconstruction_milestone\v6_13_milestone_summary.json"

$ORCH = Join-Path $ROOT "full_training\run_v6_14_semantic_family_output_projection_redesign_milestone.py"
$RUNTIME = Join-Path $ROOT "full_training\v6_14_internal\runtime_v6_14.py"
$WORKER = Join-Path $ROOT "full_training\v6_14_internal\run_v6_14_semantic_family_output_projection_redesign.py"

Write-Host "========== ZANT-LLM v6.14 SEMANTIC-FAMILY OUTPUT-PROJECTION REDESIGN =========="
Write-Host "NO_TRAINING=True"
Write-Host "NO_NEW_RULES=True"
Write-Host "SOURCE_V6_13_COMPLETE=True"
Write-Host "SOURCE_V6_13_FAMILY_WINS=20/20"
Write-Host "SOURCE_V6_13_USABLE_RANK64_AND_WIN=11/20"
Write-Host "METHOD=LEAVE_ONE_OUT_BILINGUAL_FAMILY_OUTPUT_DIRECTION"
Write-Host "INTERVENTION_POINT=POST_FINAL_NORM_PRE_LM_HEAD"
Write-Host "STRENGTHS=0.01,0.02,0.05,0.10,0.20,0.35"
Write-Host "RANK_CAP=64"
Write-Host "RETAINED_HOLDOUT_EVALUATED=False"
Write-Host "NO_GITHUB_PUSH=True"

foreach ($p in @($PYTHON,$BASE_MODEL,$SOURCE_ADAPTER,$V67_PATCH,$TRAIN_FILE,$V69_REPORT,$V69_SUMMARY,$V69_DETAIL,$V69_FAMILY,$V613_PLAN,$V613_SUMMARY,$ORCH,$RUNTIME,$WORKER)) {
    if (!(Test-Path $p)) { throw "Required path not found: $p" }
}

& $PYTHON $ORCH `
    --root $ROOT `
    --base-model $BASE_MODEL `
    --source-adapter $SOURCE_ADAPTER `
    --v67-patch $V67_PATCH `
    --train-file $TRAIN_FILE `
    --v69-report $V69_REPORT `
    --v69-summary $V69_SUMMARY `
    --v69-detail $V69_DETAIL `
    --v69-family $V69_FAMILY `
    --v613-plan $V613_PLAN `
    --v613-summary $V613_SUMMARY `
    --runtime-script $RUNTIME `
    --worker $WORKER

$exit=$LASTEXITCODE
Write-Host "V6_14_PROCESS_EXIT=$exit"
if ($exit -ne 0) { throw "v6.14 milestone failed (exit=$exit)" }
Write-Host "========== v6.14 ONE-CLICK DONE =========="
