v6.50 HOTFIX1 NOTICE
=====================
This package restores the missing write_jsonl() result-serialization helper.

No runtime math, gate threshold, evaluation metric, routing rule, or model
artifact is changed.

The previous run had already passed runtime parity and safety fallback checks
before failing during final JSONL serialization.

See README_HOTFIX1.txt.

Zant-LLM v6.50
Persistent Bridge Controlled Generation Integration Milestone
==============================================================

SOURCE v6.49
------------
v6.49 completed successfully.

Runtime gate:

  beta                             = 0.75
  threshold                        = 0.50

Teacher calibration:

  baseline live Top1               = 53/160
  gated live Top1                  = 129/160
  change                           = +76

Live generation:

  BASELINE token matches           = 2/160
  ALWAYS-ON token matches          = 71/160
  GATED token matches              = 69/160

  BASELINE first-token             = 0/20
  GATED first-token                = 10/20

  BASELINE hard52                  = 0/52
  GATED hard52                     = 32/52

Final v6.49 status:

  CALIBRATED_RUNTIME_GATE_TRANSLATES_PERSISTENT_BRIDGE_SIGNAL_INTO_LIVE_GENERATION


PURPOSE OF v6.50
----------------
v6.50 is not another training milestone.

Its job is to convert the successful v6.48 + v6.49 experiment into a reusable
controlled-generation runtime package.

The package combines:

  frozen Gemma base + v6.7 residual
  frozen v6.31 controller
  v6.48 persistent paired-context bridge
  v6.49 calibrated runtime gate
  prompt->plan KNN state
  safety fallback rules


NO MODEL TRAINING
-----------------
NO_MODEL_TRAINING=True

No base weights are changed.

No v6.31 weights are changed.

No v6.48 bridge weights are changed.

Retained holdout remains closed.

No GitHub push.


RUNTIME BUNDLE
--------------
v6.50 creates:

  artifacts\
  Zant-LLM-v6_50-controlled-generation-runtime\
  v6_50_controlled_generation_runtime_bundle.pt

The bundle contains:

  v6.48 bridge
  v6.49 gate beta/threshold
  80 train prompt states for plan prediction
  80 plan labels
  source lineage hashes
  calibrated bridge step range
  fallback policy


RUNTIME SAFETY FALLBACK
-----------------------
The baseline controller is always available.

The bridge automatically falls back to baseline when:

  bridge query is non-finite

  bridge logits are non-finite

  bridge/fusion raises an exception

  generation step >= 8

The final rule is deliberate:

  v6.48 was trained/calibrated on steps 0..7.

After step 7, v6.50 uses the baseline controller rather than extrapolating the
bridge outside its validated range.


INTEGRATION PARITY TEST
-----------------------
The reusable v6.50 runtime MUST reproduce the closed v6.49 live metrics:

BASELINE:

  token matches = 2/160
  first token   = 0/20
  hard52        = 0/52

ALWAYS-ON:

  token matches = 71/160
  first token   = 10/20
  hard52        = 32/52

GATED:

  token matches = 69/160
  first token   = 10/20
  hard52        = 32/52

If parity fails, v6.50 stops.


REUSABLE INFERENCE CLI
----------------------
After v6.50 completes successfully, you can run a real prompt with:

  python full_training\run_v6_50_controlled_generation_inference.py --prompt "your prompt"

Default mode:

  gated

Other modes:

  --mode baseline

  --mode always_on

  --mode gated

Example:

  python full_training\run_v6_50_controlled_generation_inference.py --prompt "Explain the evidence carefully." --mode gated --max-new-tokens 8


LONGER GENERATION
-----------------
The CLI may request more than 8 tokens.

For steps 0..7:

  calibrated bridge + gate may act.

For step 8 and later:

  automatic baseline fallback.

This avoids unvalidated step extrapolation.


OUTPUT ARTIFACTS
----------------
artifacts\
Zant-LLM-v6_50-controlled-generation-runtime\

  v6_50_controlled_generation_runtime_bundle.pt

  v6_50_runtime_manifest.json

  v6_50_integration_detail.jsonl

  v6_50_integration_report.json

  v6_50_milestone_analysis.json

  v6_50_milestone_summary.json


SUCCESS ROUTE
-------------
If:

  v6.49 runtime parity passes

  safety fallback contract passes

  gated token gain >= +60

  gated hard52 gain >= +25

  gated first-token gain >= +8

then:

  v6.51-controlled-generation-generalization-and-runtime-robustness-milestone

Objective:

  UNSEEN_DEV_GENERALIZATION
  + LATENCY_MEMORY
  + FALLBACK_STRESS
  + INFERENCE_PACKAGE_VALIDATION


WHY v6.51 IS NOT RETAINED HOLDOUT YET
-------------------------------------
The current 20 anchors have now been used repeatedly for development and gate
calibration.

Even though live free-run itself was not used to choose the v6.49 threshold,
the next responsible step is broader generalization/runtime validation before
opening any final retained holdout.

Retained holdout remains CLOSED in v6.50.


RUN
---
Extract into:

  C:\Users\Administrator\Desktop\Zant-LLM

Then run:

  powershell.exe -ExecutionPolicy Bypass -File "C:\Users\Administrator\Desktop\Zant-LLM\RUN_ZANT_V6_50_PERSISTENT_BRIDGE_CONTROLLED_GENERATION_INTEGRATION_ONE_CLICK.ps1"
