$ErrorActionPreference = "Stop"

$ROOT = "C:\Users\Administrator\Desktop\Zant-LLM"
$PY = "C:\Users\Administrator\AppData\Local\Programs\Python\Python311\python.exe"
$BASE_MODEL = "E:\gemma-4-E2B-it"

$SOURCE_ADAPTER = Join-Path $ROOT "artifacts\Zant-LLM-v5_9_25-first-token-logit-margin-rank16-adapter"
$V67_PATCH = Join-Path $ROOT "artifacts\Zant-LLM-v6_7-reconstructed-canonical-target-alignment-pilot"
$RUNNER = Join-Path $ROOT "full_training\run_v6_50_persistent_bridge_controlled_generation_integration_milestone.py"

$env:CUDA_LAUNCH_BLOCKING = "1"

Write-Host "========== ZANT-LLM v6.50 HOTFIX1 CONTROLLED GENERATION INTEGRATION =========="
Write-Host "HOTFIX1_RESULT_SERIALIZATION_HELPER_RESTORED=True"
Write-Host "SEMANTIC_OBJECTIVE_UNCHANGED=True"
Write-Host "RUNTIME_THRESHOLDS_UNCHANGED=True"
Write-Host "NO_MODEL_TRAINING=True"
Write-Host "SOURCE_V6_49_COMPLETE=True"
Write-Host "SOURCE_GATED_LIVE_TOKEN_MATCH=69/160"
Write-Host "SOURCE_GATED_LIVE_FIRST_TOKEN=10/20"
Write-Host "SOURCE_GATED_LIVE_HARD52_MATCH=32/52"
Write-Host "OBJECTIVE=LIVE_GATED_BRIDGE_CONTROLLER_COEXECUTION+SEQUENCE_METRICS+RUNTIME_SAFETY_FALLBACK+INFERENCE_PACKAGE"
Write-Host "CUDA_LAUNCH_BLOCKING=1"
Write-Host "RETAINED_HOLDOUT_EVALUATED=False"
Write-Host "NO_GITHUB_PUSH=True"

if (!(Test-Path $PY)) { throw "Python not found: $PY" }
if (!(Test-Path $RUNNER)) { throw "v6.50 runner not found: $RUNNER" }
if (!(Test-Path $BASE_MODEL)) { throw "Base model not found: $BASE_MODEL" }
if (!(Test-Path $SOURCE_ADAPTER)) { throw "Source adapter not found: $SOURCE_ADAPTER" }
if (!(Test-Path $V67_PATCH)) { throw "v6.7 patch not found: $V67_PATCH" }

& $PY $RUNNER `
  --root $ROOT `
  --base-model $BASE_MODEL `
  --source-adapter $SOURCE_ADAPTER `
  --v67-patch $V67_PATCH

$exit = $LASTEXITCODE

Write-Host ("V6_50_PROCESS_EXIT=" + $exit)

if ($exit -ne 0) {
    throw "v6.50 HOTFIX1 failed (exit=$exit)"
}

Write-Host "========== v6.50 HOTFIX1 ONE-CLICK DONE =========="
