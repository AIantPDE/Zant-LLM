from pathlib import Path
import argparse
import importlib.util
import json
import gc


def load_module(path, name):
    spec = importlib.util.spec_from_file_location(
        name,
        str(path),
    )
    mod = importlib.util.module_from_spec(
        spec
    )
    spec.loader.exec_module(
        mod
    )
    return mod


def main():
    ap = argparse.ArgumentParser()

    ap.add_argument(
        "--root",
        default=r"C:\Users\Administrator\Desktop\Zant-LLM",
    )

    ap.add_argument(
        "--base-model",
        default=r"E:\gemma-4-E2B-it",
    )

    ap.add_argument(
        "--source-adapter",
        default="",
    )

    ap.add_argument(
        "--v67-patch",
        default="",
    )

    ap.add_argument(
        "--prompt",
        required=True,
    )

    ap.add_argument(
        "--mode",
        choices=(
            "baseline",
            "always_on",
            "gated",
        ),
        default="gated",
    )

    ap.add_argument(
        "--max-new-tokens",
        type=int,
        default=8,
    )

    args = ap.parse_args()

    root = Path(
        args.root
    )

    if not args.source_adapter:
        args.source_adapter = str(
            root
            / "artifacts"
            / "Zant-LLM-v5_9_25-first-token-logit-margin-rank16-adapter"
        )

    if not args.v67_patch:
        args.v67_patch = str(
            root
            / "artifacts"
            / "Zant-LLM-v6_7-reconstructed-canonical-target-alignment-pilot"
        )

    runtime_script = (
        root
        / "full_training"
        / "v6_36_internal"
        / "runtime_v6_36.py"
    )

    v624_script = (
        root
        / "full_training"
        / "v6_36_internal"
        / "controller_v6_24_frozen.py"
    )

    joint_script = (
        root
        / "full_training"
        / "v6_36_internal"
        / "controller_v6_29_joint.py"
    )

    internal = (
        root
        / "full_training"
        / "v6_50_internal"
    )

    reference_script = (
        internal
        / "reference_v6_49_runtime.py"
    )

    v650_runtime_script = (
        internal
        / "runtime_v6_50_controlled_generation.py"
    )

    bundle_path = (
        root
        / "artifacts"
        / "Zant-LLM-v6_50-controlled-generation-runtime"
        / "v6_50_controlled_generation_runtime_bundle.pt"
    )

    if not bundle_path.exists():
        raise SystemExit(
            "v6.50 runtime bundle not found. "
            "Run the v6.50 milestone first."
        )

    rt = load_module(
        runtime_script,
        "v650_infer_rt",
    )
    ref = load_module(
        reference_script,
        "v650_infer_ref",
    )
    v650rt = load_module(
        v650_runtime_script,
        "v650_infer_runtime",
    )
    v624mod = load_module(
        v624_script,
        "v650_infer_v624",
    )
    jointmod = load_module(
        joint_script,
        "v650_infer_joint",
    )

    import torch

    torch.backends.cuda.enable_flash_sdp(
        False
    )
    torch.backends.cuda.enable_mem_efficient_sdp(
        False
    )
    torch.backends.cuda.enable_math_sdp(
        True
    )

    tok, model, info = rt.load_base_with_v67_residual(
        Path(
            args.base_model
        ),
        Path(
            args.source_adapter
        ),
        Path(
            args.v67_patch
        ),
    )

    model.eval()

    for p in model.parameters():
        p.requires_grad_(
            False
        )

    bundle = torch.load(
        bundle_path,
        map_location="cpu",
        weights_only=False,
    )

    if bundle.get(
        "schema"
    ) != "ZANT_LLM_V6_50_CONTROLLED_GENERATION_RUNTIME_BUNDLE_V1":
        raise SystemExit(
            "Unexpected v6.50 runtime bundle schema"
        )

    bridge = bundle[
        "bridge"
    ]

    projection = bridge[
        "projection_matrix"
    ].float()

    bridge_weight = bridge[
        "state_dict"
    ][
        "weight"
    ].float()

    feature_weights = dict(
        bridge[
            "feature_weights"
        ]
    )

    residual_clip = float(
        bridge[
            "residual_clip"
        ]
    )

    beta = float(
        bundle[
            "gate"
        ][
            "beta"
        ]
    )

    threshold = float(
        bundle[
            "gate"
        ][
            "threshold"
        ]
    )

    train_states_tensor = bundle[
        "plan_train_prompt_states"
    ].float()

    train_states = [
        train_states_tensor[
            i
        ]
        for i in range(
            int(
                train_states_tensor.shape[
                    0
                ]
            )
        )
    ]

    train_labels = [
        int(x)
        for x in bundle[
            "plan_train_labels"
        ].tolist()
    ]

    pids = ref.prompt_ids(
        tok,
        args.prompt,
    )

    raw_state = ref.capture_raw_states(
        torch,
        model,
        rt,
        [
            (
                (
                    "PROMPT",
                    "user",
                ),
                pids,
            )
        ],
    )[
        (
            "PROMPT",
            "user",
        )
    ]

    plan, plan_conf = ref.plan_knn(
        torch,
        train_states,
        train_labels,
        raw_state,
    )

    Wcpu = (
        model.get_output_embeddings()
        .weight
        .detach()
        .float()
        .cpu()
    )

    joint = ref.load_joint_controller(
        torch,
        rt,
        v624mod,
        jointmod,
        root,
    )

    case = {
        "pids": pids,
    }

    generated, steps, fallback_count = v650rt.safe_live_generate(
        torch,
        model,
        rt,
        jointmod,
        joint,
        ref,
        case,
        raw_state,
        plan,
        plan_conf,
        Wcpu,
        projection,
        feature_weights,
        bridge_weight,
        residual_clip,
        beta,
        threshold,
        mode=args.mode,
        max_new_tokens=max(
            1,
            int(
                args.max_new_tokens
            ),
        ),
    )

    text = tok.decode(
        generated,
        skip_special_tokens=True,
    )

    result = {
        "ok": True,
        "mode": args.mode,
        "prompt": args.prompt,
        "predicted_plan": int(
            plan
        ),
        "plan_confidence": float(
            plan_conf
        ),
        "gate_beta": beta,
        "gate_threshold": threshold,
        "generated_token_ids": [
            int(x)
            for x in generated
        ],
        "text": text,
        "fallback_count": int(
            fallback_count
        ),
        "steps": steps,
    }

    print(
        json.dumps(
            result,
            ensure_ascii=False,
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
