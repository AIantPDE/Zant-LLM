from pathlib import Path
import argparse
import subprocess
import sys


def run(cmd):
    print(
        "RUN="
        + " ".join(
            str(x)
            for x in cmd
        ),
        flush=True,
    )

    p = subprocess.run(
        cmd
    )

    if p.returncode != 0:
        raise SystemExit(
            p.returncode
        )


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument(
        "--root",
        required=True,
    )
    ap.add_argument(
        "--base-model",
        required=True,
    )
    ap.add_argument(
        "--source-adapter",
        required=True,
    )
    ap.add_argument(
        "--v67-patch",
        required=True,
    )
    args = ap.parse_args()

    root = Path(
        args.root
    )
    py = sys.executable

    internal = (
        root
        / "full_training"
        / "v6_50_internal"
    )

    runtime = (
        root
        / "full_training"
        / "v6_36_internal"
        / "runtime_v6_36.py"
    )

    v624_script = (
        root
        / "full_training"
        / "v6_36_internal"
        / "controller_v6_24_frozen.py"
    )

    joint_script = (
        root
        / "full_training"
        / "v6_36_internal"
        / "controller_v6_29_joint.py"
    )

    reference_script = (
        internal
        / "reference_v6_49_runtime.py"
    )

    v650_runtime = (
        internal
        / "runtime_v6_50_controlled_generation.py"
    )

    artifact_dir = (
        root
        / "artifacts"
        / "Zant-LLM-v6_50-controlled-generation-runtime"
    )

    report = (
        artifact_dir
        / "v6_50_integration_report.json"
    )

    print(
        "========== ZANT-LLM v6.50 CONTROLLED GENERATION INTEGRATION =========="
    )
    print(
        "NO_MODEL_TRAINING=True"
    )
    print(
        "SOURCE_V6_49_COMPLETE=True"
    )
    print(
        "SOURCE_GATED_LIVE_TOKEN_MATCH=69/160"
    )
    print(
        "SOURCE_GATED_LIVE_FIRST_TOKEN=10/20"
    )
    print(
        "SOURCE_GATED_LIVE_HARD52_MATCH=32/52"
    )
    print(
        "OBJECTIVE=LIVE_GATED_BRIDGE_CONTROLLER_COEXECUTION+SEQUENCE_METRICS+RUNTIME_SAFETY_FALLBACK+INFERENCE_PACKAGE"
    )
    print(
        "RETAINED_HOLDOUT_EVALUATED=False"
    )
    print(
        "NO_GITHUB_PUSH=True"
    )

    run(
        [
            py,
            str(
                internal
                / "build_and_validate_v6_50_runtime.py"
            ),
            "--root",
            str(
                root
            ),
            "--base-model",
            args.base_model,
            "--source-adapter",
            args.source_adapter,
            "--v67-patch",
            args.v67_patch,
            "--runtime-script",
            str(
                runtime
            ),
            "--v624-controller-script",
            str(
                v624_script
            ),
            "--joint-controller-script",
            str(
                joint_script
            ),
            "--reference-runtime-script",
            str(
                reference_script
            ),
            "--v650-runtime-script",
            str(
                v650_runtime
            ),
            "--artifact-dir",
            str(
                artifact_dir
            ),
        ]
    )

    run(
        [
            py,
            str(
                internal
                / "route_v6_50.py"
            ),
            "--report",
            str(
                report
            ),
            "--runtime-script",
            str(
                runtime
            ),
            "--artifact-dir",
            str(
                artifact_dir
            ),
        ]
    )

    print(
        "V6_50_PROCESS_EXIT=0"
    )
    print(
        "========== v6.50 ONE-CLICK DONE =========="
    )


if __name__ == "__main__":
    main()
