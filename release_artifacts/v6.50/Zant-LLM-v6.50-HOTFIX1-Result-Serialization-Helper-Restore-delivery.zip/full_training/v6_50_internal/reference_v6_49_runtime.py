from pathlib import Path
import argparse
import importlib.util
import json
import math
import gc
from collections import defaultdict

EXPECTED_V648_ARTIFACT_SHA = "0446fece29c00eacb74bd3cc037ac08911fb8df503c85f574e92bc07c55f0204"
EXPECTED_V648_REPORT_SHA = "2064e99edd28ec2e1605a12d5e4ff3e979af2aff2234ee496d0626320da0c008"
EXPECTED_V648_MANIFEST_SHA = "ef751c695bedf290700322c25225271df21d52ee083899abbed89bf0e4b48120"
EXPECTED_V648_ANALYSIS_SHA = "3482820abe5376c9ebe159fe67fc463dc40c40bcd68d919a0979a4a195f9ecc1"
EXPECTED_V648_SUMMARY_SHA = "8180a8849c864191c7c9a52f4ace2d444686229fd9f48522c7a81db95cd0d9af"

EXPECTED_V630_DETAIL_SHA = "09892653c8b5218400aa6b60dea28754aadd93c3d3d3693e7248ef21d34e547e"
EXPECTED_V616_ROUTER_SHA = "cbe5ea6d5f4fba5f3f84c0b9ac84626204d17b2473e5d3e92b34faca1823a735"
EXPECTED_V616_FOLDER_SHA = "ccbc1e2eb1473eb33d1b31ec10c7a3c0832f6aeb2a1c7ec5b9d8c8df69397ebb"
EXPECTED_V621_BANK_SHA = "d5c660905175a13e15d4c376065de9e0ba873951c2584c290422afc5c5b25b1f"
EXPECTED_V624_CONTROLLER_SHA = "4bb2c20ff2b78c849f2ea6e1b7e890623683ea2c47a73b9a74be8f551df95c2c"
EXPECTED_V624_FOLDER_SHA = "8730612769ae2e34ebd82e5eeb71c244fed6a979589dc2ad697f417b0db4f090"
EXPECTED_V631_CONTROLLER_SHA = "45b5b5f8855cdbcdfa48f867da692994db1a244d0a6d5c06c9ede9020ba01cb2"
EXPECTED_V631_FOLDER_SHA = "8704684b56c0b79ebdfcb0be8f66952672f3594230d5adb75b41f3cb5ba1a144"

MAX_NEW_TOKENS = 8
TOPK_CANDIDATES = 64
PLAN_K = 4

BETA_GRID = (0.25, 0.50, 0.75, 1.00, 1.25)
THRESHOLD_GRID = (0.00, 0.10, 0.20, 0.35, 0.50, 0.75, 1.00, 1.50, 2.00)

HARD_CATEGORIES = {
    "JOINT_OUTPUT_ALREADY_TOP10_BUT_NOT_TOP1",
    "STATE_HEAD_RECOVERS_CONTROL_REGION_BUT_FINAL_POLICY_MISSES",
    "CURRENT_PREFIX_STATE_IS_CONTROLLABLE_BUT_JOINT_POLICY_MISSES",
}


def load_module(path, name):
    spec = importlib.util.spec_from_file_location(name, str(path))
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def read_jsonl(path):
    rows = []
    with Path(path).open("r", encoding="utf-8") as f:
        for line in f:
            if line.strip():
                rows.append(json.loads(line))
    return rows


def write_json(path, obj):
    Path(path).write_text(
        json.dumps(obj, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
        newline="\n",
    )


def write_jsonl(path, rows):
    with Path(path).open("w", encoding="utf-8", newline="\n") as f:
        for row in rows:
            f.write(
                json.dumps(
                    row,
                    ensure_ascii=False,
                    separators=(",", ":"),
                )
                + "\n"
            )


def unit(torch, x):
    x = x.float()
    return x / x.norm().clamp_min(1e-8)


def prompt_ids(tok, prompt):
    try:
        text = tok.apply_chat_template(
            [{"role": "user", "content": prompt}],
            tokenize=False,
            add_generation_prompt=True,
        )
        return tok(text, add_special_tokens=False).input_ids
    except Exception:
        return tok(
            "User: " + prompt + "\nAssistant: ",
            add_special_tokens=False,
        ).input_ids


def proj(torch, x, P):
    if x is None:
        return torch.zeros(
            int(P.shape[1]),
            dtype=torch.float32,
        )

    return unit(
        torch,
        unit(torch, x) @ P,
    )


def feature(
    torch,
    current,
    prompt,
    prev1,
    prev2,
    plan,
    step,
    P,
    feature_weights,
):
    p = torch.zeros(
        PLAN_K,
        dtype=torch.float32,
    )
    p[
        max(
            0,
            min(
                PLAN_K - 1,
                int(plan),
            ),
        )
    ] = 1.0

    s = torch.zeros(
        8,
        dtype=torch.float32,
    )
    s[
        max(
            0,
            min(
                7,
                int(step),
            ),
        )
    ] = 1.0

    core = torch.cat(
        [
            math.sqrt(float(feature_weights["current"])) * proj(torch, current, P),
            math.sqrt(float(feature_weights["prompt"])) * proj(torch, prompt, P),
            math.sqrt(float(feature_weights["prev1"])) * proj(torch, prev1, P),
            math.sqrt(float(feature_weights["prev2"])) * proj(torch, prev2, P),
            math.sqrt(float(feature_weights["plan"])) * p,
            math.sqrt(float(feature_weights["step"])) * s,
        ]
    )

    core = unit(
        torch,
        core,
    )

    return torch.cat(
        [
            core,
            torch.ones(
                1,
                dtype=torch.float32,
            ),
        ]
    )


def bridge_query(
    torch,
    x,
    base_hidden,
    bridge_weight,
    residual_clip,
):
    residual = x @ bridge_weight.T
    n = float(
        residual.norm()
    )

    if n > float(residual_clip):
        residual = residual * (
            float(residual_clip)
            / n
        )

    return unit(
        torch,
        unit(torch, base_hidden)
        + residual,
    )


def direct_logits(torch, model, hidden):
    head = model.get_output_embeddings()

    return head(
        hidden.to(
            device=head.weight.device,
            dtype=head.weight.dtype,
        )
    ).float()


def zscore(torch, x):
    x = x.float()
    return (
        x - x.mean()
    ) / x.std(
        unbiased=False
    ).clamp_min(
        1e-5
    )


def fused_candidate(
    torch,
    baseline_logits,
    bridge_logits,
    beta,
):
    bvals, bids = torch.topk(
        baseline_logits,
        k=min(
            TOPK_CANDIDATES,
            int(
                baseline_logits.numel()
            ),
        ),
    )

    qvals, qids = torch.topk(
        bridge_logits,
        k=min(
            TOPK_CANDIDATES,
            int(
                bridge_logits.numel()
            ),
        ),
    )

    union = []
    seen = set()

    for tid in (
        bids.tolist()
        + qids.tolist()
    ):
        tid = int(tid)

        if tid not in seen:
            seen.add(tid)
            union.append(tid)

    ids = torch.tensor(
        union,
        dtype=torch.long,
        device=baseline_logits.device,
    )

    b = baseline_logits.index_select(
        0,
        ids,
    ).float()

    q = bridge_logits.index_select(
        0,
        ids,
    ).float()

    bz = zscore(
        torch,
        b,
    )
    qz = zscore(
        torch,
        q,
    )

    score = bz + float(beta) * qz

    order = torch.argsort(
        score,
        descending=True,
    )

    candidate_idx = int(
        order[0].item()
    )

    candidate = int(
        ids[
            candidate_idx
        ].item()
    )

    baseline = int(
        bids[0].item()
    )

    baseline_pos = int(
        (
            ids == baseline
        ).nonzero(
            as_tuple=False
        )[0, 0].item()
    )

    advantage = float(
        score[
            candidate_idx
        ].item()
        - score[
            baseline_pos
        ].item()
    )

    bridge_top1 = int(
        qids[0].item()
    )

    bridge_margin = float(
        qvals[0].item()
        - qvals[
            min(
                1,
                len(qvals) - 1,
            )
        ].item()
    )

    return {
        "baseline_token_id": baseline,
        "bridge_top1_token_id": bridge_top1,
        "candidate_token_id": candidate,
        "candidate_advantage": advantage,
        "bridge_margin": bridge_margin,
        "candidate_differs_from_baseline": bool(
            candidate != baseline
        ),
    }


def plan_knn(
    torch,
    train_states,
    train_labels,
    test_state,
):
    X = torch.stack(
        [
            unit(
                torch,
                x,
            )
            for x in train_states
        ]
    )

    q = unit(
        torch,
        test_state,
    )

    sims = X @ q

    k = min(
        9,
        len(
            train_labels
        ),
    )

    vals, idx = torch.topk(
        sims,
        k=k,
    )

    weights = torch.softmax(
        vals / 0.10,
        dim=0,
    )

    scores = torch.zeros(
        PLAN_K,
        dtype=torch.float32,
    )

    for pos, j in enumerate(
        idx.tolist()
    ):
        scores[
            int(
                train_labels[
                    j
                ]
            )
        ] += float(
            weights[
                pos
            ]
        )

    top = torch.topk(
        scores,
        k=min(
            2,
            PLAN_K,
        ),
    )

    confidence = float(
        top.values[0].item()
        - top.values[
            min(
                1,
                len(
                    top.values
                ) - 1,
            )
        ].item()
    )

    return (
        int(
            top.indices[
                0
            ].item()
        ),
        confidence,
    )


def capture_raw_states(
    torch,
    model,
    rt,
    requests,
):
    final_norm, _ = rt.find_final_norm(
        model
    )

    cap = {
        "h": None,
    }

    def hook(
        module,
        args,
        out,
    ):
        cap[
            "h"
        ] = rt.extract_hidden(
            out
        )

    handle = final_norm.register_forward_hook(
        hook
    )

    result = {}

    try:
        with torch.no_grad():
            for idx, (
                key,
                ids,
            ) in enumerate(
                requests,
                1,
            ):
                xin = None
                mask = None
                model_out = None

                try:
                    xin = torch.tensor(
                        [
                            ids
                        ],
                        dtype=torch.long,
                        device="cuda:0",
                    )

                    mask = torch.ones_like(
                        xin
                    )

                    cap[
                        "h"
                    ] = None

                    model_out = model(
                        input_ids=xin,
                        attention_mask=mask,
                        use_cache=False,
                    )

                    torch.cuda.synchronize()

                    if cap["h"] is None:
                        raise RuntimeError(
                            "raw capture hook returned no hidden state"
                        )

                    result[
                        key
                    ] = cap[
                        "h"
                    ][
                        0,
                        -1,
                        :,
                    ].detach().float().cpu()

                finally:
                    cap[
                        "h"
                    ] = None

                    if model_out is not None:
                        del model_out
                    if xin is not None:
                        del xin
                    if mask is not None:
                        del mask

                if idx % 25 == 0:
                    torch.cuda.synchronize()
                    gc.collect()
                    torch.cuda.empty_cache()

                    free_b, total_b = torch.cuda.mem_get_info()

                    print(
                        "RAW_STATE_CAPTURE_PROGRESS=%d/%d CUDA_FREE_GB=%.3f CUDA_TOTAL_GB=%.3f"
                        % (
                            idx,
                            len(
                                requests
                            ),
                            free_b
                            / (
                                1024
                                ** 3
                            ),
                            total_b
                            / (
                                1024
                                ** 3
                            ),
                        ),
                        flush=True,
                    )
    finally:
        handle.remove()
        cap["h"] = None
        gc.collect()
        torch.cuda.empty_cache()
        torch.cuda.synchronize()

    return result


def load_joint_controller(
    torch,
    rt,
    v624mod,
    jointmod,
    root,
):
    from safetensors.torch import load_file

    v616 = (
        root
        / "artifacts"
        / "Zant-LLM-v6_16-routed-output-semantic-continuation-router"
    )
    v621 = (
        root
        / "artifacts"
        / "Zant-LLM-v6_21-output-prototype-bank-reconstruction"
    )
    v624 = (
        root
        / "artifacts"
        / "Zant-LLM-v6_24-supervised-oracle-mixture-selector-controller"
    )
    v631 = (
        root
        / "artifacts"
        / "Zant-LLM-v6_31-joint-controller-hard-error-execution-refinement"
    )

    router_file = (
        v616
        / "family_output_projection_router.safetensors"
    )
    bank_file = (
        v621
        / "reconstructed_output_prototype_bank.safetensors"
    )
    c624 = (
        v624
        / "oracle_mixture_selector_controller.pt"
    )
    c631 = (
        v631
        / "joint_controller_execution_refinement.pt"
    )

    files = (
        (
            router_file,
            EXPECTED_V616_ROUTER_SHA,
        ),
        (
            bank_file,
            EXPECTED_V621_BANK_SHA,
        ),
        (
            c624,
            EXPECTED_V624_CONTROLLER_SHA,
        ),
        (
            c631,
            EXPECTED_V631_CONTROLLER_SHA,
        ),
    )

    for p, expected in files:
        if not p.exists():
            raise SystemExit(
                "Missing controller prerequisite: "
                + str(
                    p
                )
            )

        if rt.sha256_file(
            p
        ) != expected:
            raise SystemExit(
                "Controller prerequisite SHA mismatch: "
                + str(
                    p
                )
            )

    if rt.folder_manifest_sha(
        v616
    ) != EXPECTED_V616_FOLDER_SHA:
        raise SystemExit(
            "v6.16 folder SHA mismatch"
        )

    if rt.folder_manifest_sha(
        v624
    ) != EXPECTED_V624_FOLDER_SHA:
        raise SystemExit(
            "v6.24 folder SHA mismatch"
        )

    if rt.folder_manifest_sha(
        v631
    ) != EXPECTED_V631_FOLDER_SHA:
        raise SystemExit(
            "v6.31 folder SHA mismatch"
        )

    source_manifest = rt.read_json(
        v616
        / "family_output_projection_router_manifest.json"
    )

    raw = load_file(
        str(
            router_file
        ),
        device="cpu",
    )

    source_router = rt.FamilyOutputProjectionRouter(
        hidden_size=int(
            source_manifest[
                "hidden_size"
            ]
        ),
        router_hidden=int(
            source_manifest[
                "router_hidden"
            ]
        ),
        prototype_directions=raw[
            "prototype_directions"
        ],
        prototype_strengths=raw[
            "prototype_strengths"
        ],
        device="cuda:0",
        dtype=torch.float32,
    )

    source_router.load_state_dict(
        {
            "fc1.weight": raw[
                "router.fc1.weight"
            ],
            "fc1.bias": raw[
                "router.fc1.bias"
            ],
            "fc2.weight": raw[
                "router.fc2.weight"
            ],
            "fc2.bias": raw[
                "router.fc2.bias"
            ],
        },
        strict=True,
    )

    source_router.eval()

    bankraw = load_file(
        str(
            bank_file
        ),
        device="cpu",
    )

    bank = (
        bankraw[
            "prototype_directions"
        ].float()
        * bankraw[
            "prototype_strengths"
        ].float().unsqueeze(
            1
        )
    ).contiguous()

    ctl624 = v624mod.OracleMixtureSelectorController(
        hidden_size=int(
            source_manifest[
                "hidden_size"
            ]
        ),
        source_router=source_router,
        new_bank=bank,
        selector_hidden=128,
        gate_hidden=64,
        gate_bias_init=-5.0,
        device="cuda:0",
    )

    p624 = torch.load(
        c624,
        map_location="cpu",
        weights_only=False,
    )

    ctl624.load_state_dict(
        p624[
            "controller_state"
        ],
        strict=True,
    )

    ctl624.eval()

    p631 = torch.load(
        c631,
        map_location="cpu",
        weights_only=False,
    )

    joint = jointmod.JointSequenceStateAdaptivePrototypeController(
        hidden_size=int(
            p631[
                "hidden_size"
            ]
        ),
        frozen_v624_controller=ctl624,
        residual_basis=p631[
            "residual_basis"
        ].float(),
        max_state_residual_norm=float(
            p631[
                "max_state_residual_norm"
            ]
        ),
        adaptive_residual_scale=float(
            p631[
                "adaptive_residual_scale"
            ]
        ),
        feature_hidden=int(
            p631[
                "feature_hidden"
            ]
        ),
        device="cuda:0",
    )

    joint.load_state_dict(
        p631[
            "controller_state"
        ],
        strict=True,
    )

    joint.eval()

    return joint


def teacher_calibration_records(
    torch,
    model,
    rt,
    jointmod,
    joint,
    tok,
    vg,
    prompt_states,
    pred_plan,
    Wcpu,
    projection,
    feature_weights,
    bridge_weight,
    residual_clip,
):
    final_norm, _ = rt.find_final_norm(
        model
    )

    cap = {
        "h": None,
    }

    def raw_hook(
        module,
        args,
        out,
    ):
        cap[
            "h"
        ] = rt.extract_hidden(
            out
        )

    raw_handle = final_norm.register_forward_hook(
        raw_hook
    )

    controller_handle, _ = jointmod.install_joint_controller(
        model,
        joint,
        rt,
    )

    records = []

    try:
        with torch.no_grad():
            for sid, x in vg.items():
                joint.reset_history()

                canonical = x[
                    "target_ids"
                ]

                for step in range(
                    len(
                        canonical
                    )
                ):
                    ids = (
                        x[
                            "pids"
                        ]
                        + canonical[
                            :step
                        ]
                    )

                    xin = torch.tensor(
                        [
                            ids
                        ],
                        dtype=torch.long,
                        device="cuda:0",
                    )

                    mask = torch.ones_like(
                        xin
                    )

                    cap[
                        "h"
                    ] = None

                    out = model(
                        input_ids=xin,
                        attention_mask=mask,
                        use_cache=False,
                    )

                    torch.cuda.synchronize()

                    if cap["h"] is None:
                        raise RuntimeError(
                            "teacher live raw hidden capture failed"
                        )

                    raw_hidden = cap[
                        "h"
                    ][
                        0,
                        -1,
                        :,
                    ].detach().float().cpu()

                    baseline_logits = out.logits[
                        0,
                        -1,
                        :,
                    ].detach().float()

                    prev1 = (
                        Wcpu[
                            canonical[
                                step
                                - 1
                            ]
                        ]
                        if step > 0
                        else None
                    )

                    prev2 = (
                        Wcpu[
                            canonical[
                                step
                                - 2
                            ]
                        ]
                        if step > 1
                        else None
                    )

                    fx = feature(
                        torch,
                        raw_hidden,
                        prompt_states[
                            sid
                        ],
                        prev1,
                        prev2,
                        pred_plan[
                            sid
                        ],
                        step,
                        projection,
                        feature_weights,
                    )

                    query = bridge_query(
                        torch,
                        fx,
                        raw_hidden,
                        bridge_weight,
                        residual_clip,
                    )

                    bridge_logits = direct_logits(
                        torch,
                        model,
                        query,
                    )

                    target = int(
                        canonical[
                            step
                        ]
                    )

                    baseline_id = int(
                        torch.argmax(
                            baseline_logits
                        ).item()
                    )

                    records.append(
                        {
                            "id": sid,
                            "step": int(
                                step
                            ),
                            "target": target,
                            "baseline_id": baseline_id,
                            "baseline_correct": bool(
                                baseline_id
                                == target
                            ),
                            "baseline_logits": baseline_logits.cpu(),
                            "bridge_logits": bridge_logits.cpu(),
                        }
                    )

                    del (
                        xin,
                        mask,
                        out,
                        raw_hidden,
                        baseline_logits,
                        bridge_logits,
                    )

    finally:
        controller_handle.remove()
        raw_handle.remove()
        cap["h"] = None
        gc.collect()
        torch.cuda.empty_cache()
        torch.cuda.synchronize()

    return records


def calibrate_gate(
    torch,
    records,
):
    baseline_hits = sum(
        int(
            r[
                "baseline_correct"
            ]
        )
        for r in records
    )

    grid = []

    for beta in BETA_GRID:
        proposed = []

        for r in records:
            p = fused_candidate(
                torch,
                r[
                    "baseline_logits"
                ],
                r[
                    "bridge_logits"
                ],
                beta,
            )

            proposed.append(
                (
                    r,
                    p,
                )
            )

        for threshold in THRESHOLD_GRID:
            hits = 0
            activations = 0
            overrides_correct = 0

            for r, p in proposed:
                use_bridge = (
                    p[
                        "candidate_differs_from_baseline"
                    ]
                    and float(
                        p[
                            "candidate_advantage"
                        ]
                    )
                    >= float(
                        threshold
                    )
                )

                if use_bridge:
                    chosen = int(
                        p[
                            "candidate_token_id"
                        ]
                    )
                    activations += 1
                    overrides_correct += int(
                        chosen
                        == int(
                            r[
                                "target"
                            ]
                        )
                    )
                else:
                    chosen = int(
                        r[
                            "baseline_id"
                        ]
                    )

                hits += int(
                    chosen
                    == int(
                        r[
                            "target"
                        ]
                    )
                )

            precision = (
                overrides_correct
                / float(
                    activations
                )
                if activations
                else 1.0
            )

            grid.append(
                {
                    "beta": float(
                        beta
                    ),
                    "threshold": float(
                        threshold
                    ),
                    "teacher_top1": int(
                        hits
                    ),
                    "baseline_teacher_top1": int(
                        baseline_hits
                    ),
                    "teacher_top1_change": int(
                        hits
                        - baseline_hits
                    ),
                    "activations": int(
                        activations
                    ),
                    "override_precision": float(
                        precision
                    ),
                }
            )

    # Teacher safety floor:
    # no more than one top-1 decision below the baseline.
    safe = [
        r
        for r in grid
        if r[
            "teacher_top1"
        ]
        >= baseline_hits - 1
        and r[
            "override_precision"
        ]
        >= 0.50
    ]

    if not safe:
        safe = [
            r
            for r in grid
            if r[
                "teacher_top1"
            ]
            >= baseline_hits - 1
        ]

    if not safe:
        safe = grid

    # Among teacher-safe configurations prefer:
    # 1) more teacher correctness,
    # 2) more validated override opportunities,
    # 3) lower beta for conservatism,
    # 4) higher threshold as final tie-break.
    safe = sorted(
        safe,
        key=lambda r: (
            r[
                "teacher_top1"
            ],
            r[
                "activations"
            ],
            -r[
                "beta"
            ],
            r[
                "threshold"
            ],
        ),
        reverse=True,
    )

    return (
        baseline_hits,
        safe[
            0
        ],
        grid,
    )


def live_generate(
    torch,
    model,
    rt,
    jointmod,
    joint,
    tok,
    case,
    raw_prompt_state,
    predicted_plan,
    Wcpu,
    projection,
    feature_weights,
    bridge_weight,
    residual_clip,
    beta,
    threshold,
    mode,
):
    final_norm, _ = rt.find_final_norm(
        model
    )

    cap = {
        "h": None,
    }

    def raw_hook(
        module,
        args,
        out,
    ):
        cap[
            "h"
        ] = rt.extract_hidden(
            out
        )

    raw_handle = final_norm.register_forward_hook(
        raw_hook
    )

    controller_handle, _ = jointmod.install_joint_controller(
        model,
        joint,
        rt,
    )

    generated = []
    steps = []

    try:
        joint.reset_history()

        with torch.no_grad():
            for step in range(
                MAX_NEW_TOKENS
            ):
                ids = (
                    case[
                        "pids"
                    ]
                    + generated
                )

                xin = torch.tensor(
                    [
                        ids
                    ],
                    dtype=torch.long,
                    device="cuda:0",
                )

                mask = torch.ones_like(
                    xin
                )

                cap[
                    "h"
                ] = None

                out = model(
                    input_ids=xin,
                    attention_mask=mask,
                    use_cache=False,
                )

                torch.cuda.synchronize()

                if cap["h"] is None:
                    raise RuntimeError(
                        "live raw hidden capture failed"
                    )

                raw_hidden = cap[
                    "h"
                ][
                    0,
                    -1,
                    :,
                ].detach().float().cpu()

                baseline_logits = out.logits[
                    0,
                    -1,
                    :,
                ].detach().float()

                baseline_id = int(
                    torch.argmax(
                        baseline_logits
                    ).item()
                )

                prev1 = (
                    Wcpu[
                        generated[
                            step
                            - 1
                        ]
                    ]
                    if step > 0
                    else None
                )

                prev2 = (
                    Wcpu[
                        generated[
                            step
                            - 2
                        ]
                    ]
                    if step > 1
                    else None
                )

                fx = feature(
                    torch,
                    raw_hidden,
                    raw_prompt_state,
                    prev1,
                    prev2,
                    predicted_plan,
                    step,
                    projection,
                    feature_weights,
                )

                query = bridge_query(
                    torch,
                    fx,
                    raw_hidden,
                    bridge_weight,
                    residual_clip,
                )

                bridge_logits = direct_logits(
                    torch,
                    model,
                    query,
                )

                prop = fused_candidate(
                    torch,
                    baseline_logits,
                    bridge_logits,
                    beta,
                )

                if mode == "baseline":
                    chosen = baseline_id
                    activated = False

                elif mode == "always_on":
                    chosen = int(
                        prop[
                            "candidate_token_id"
                        ]
                    )
                    activated = bool(
                        chosen
                        != baseline_id
                    )

                elif mode == "gated":
                    activated = bool(
                        prop[
                            "candidate_differs_from_baseline"
                        ]
                        and float(
                            prop[
                                "candidate_advantage"
                            ]
                        )
                        >= float(
                            threshold
                        )
                    )

                    chosen = (
                        int(
                            prop[
                                "candidate_token_id"
                            ]
                        )
                        if activated
                        else baseline_id
                    )

                else:
                    raise ValueError(
                        "Unknown live generation mode: "
                        + str(
                            mode
                        )
                    )

                generated.append(
                    int(
                        chosen
                    )
                )

                steps.append(
                    {
                        "step": int(
                            step
                        ),
                        "baseline_token_id": int(
                            baseline_id
                        ),
                        "bridge_top1_token_id": int(
                            prop[
                                "bridge_top1_token_id"
                            ]
                        ),
                        "fused_candidate_token_id": int(
                            prop[
                                "candidate_token_id"
                            ]
                        ),
                        "chosen_token_id": int(
                            chosen
                        ),
                        "gate_activated": bool(
                            activated
                        ),
                        "candidate_advantage": float(
                            prop[
                                "candidate_advantage"
                            ]
                        ),
                        "bridge_margin": float(
                            prop[
                                "bridge_margin"
                            ]
                        ),
                    }
                )

                del (
                    xin,
                    mask,
                    out,
                    raw_hidden,
                    baseline_logits,
                    bridge_logits,
                )

    finally:
        controller_handle.remove()
        raw_handle.remove()
        cap[
            "h"
        ] = None
        gc.collect()
        torch.cuda.empty_cache()
        torch.cuda.synchronize()

    return generated, steps


def sequence_metrics(
    cases,
    outputs,
    hard_keys,
):
    total = 0
    matches = 0
    first = 0
    exact = 0
    hard_matches = 0
    hitmax = 0

    hard_set = set(
        hard_keys
    )

    for sid, case in cases.items():
        target = case[
            "target_ids"
        ][
            :MAX_NEW_TOKENS
        ]

        pred = outputs[
            sid
        ]

        if len(pred) >= MAX_NEW_TOKENS:
            hitmax += 1

        first += int(
            bool(
                target
            )
            and bool(
                pred
            )
            and int(
                target[
                    0
                ]
            )
            == int(
                pred[
                    0
                ]
            )
        )

        exact += int(
            pred[
                :len(
                    target
                )
            ]
            == target
        )

        for step, tid in enumerate(
            target
        ):
            total += 1

            if (
                step
                < len(
                    pred
                )
                and int(
                    pred[
                        step
                    ]
                )
                == int(
                    tid
                )
            ):
                matches += 1

                if (
                    sid,
                    step,
                ) in hard_set:
                    hard_matches += 1

    return {
        "total_decisions": int(
            total
        ),
        "token_matches": int(
            matches
        ),
        "first_token_top1": int(
            first
        ),
        "exact_sequences": int(
            exact
        ),
        "hard52_matches": int(
            hard_matches
        ),
        "hit_max_new_tokens": int(
            hitmax
        ),
    }


def main():
    ap = argparse.ArgumentParser()

    for name in (
        "root",
        "base-model",
        "source-adapter",
        "v67-patch",
        "runtime-script",
        "v624-controller-script",
        "joint-controller-script",
        "diagnostics-dir",
    ):
        ap.add_argument(
            "--"
            + name,
            required=True,
        )

    a = ap.parse_args()

    root = Path(
        a.root
    )
    outdir = Path(
        a.diagnostics_dir
    )
    outdir.mkdir(
        parents=True,
        exist_ok=True,
    )

    rt = load_module(
        a.runtime_script,
        "v649_runtime",
    )
    v624mod = load_module(
        a.v624_controller_script,
        "v649_v624",
    )
    jointmod = load_module(
        a.joint_controller_script,
        "v649_joint",
    )

    d48 = (
        root
        / "artifacts"
        / "Zant-LLM-v6_48-paired-context-token-identity-bridge"
    )

    bridge_path = (
        d48
        / "paired_context_token_identity_bridge.pt"
    )
    report48 = (
        d48
        / "v6_48_training_report.json"
    )
    manifest48 = (
        d48
        / "v6_48_bridge_manifest.json"
    )
    analysis48 = (
        d48
        / "v6_48_milestone_analysis.json"
    )
    summary48 = (
        d48
        / "v6_48_milestone_summary.json"
    )

    d44 = (
        root
        / "full_training"
        / "v6_44_dedicated_transition_supervision_dataset"
    )

    train_path = (
        d44
        / "v6_44_dedicated_train_transitions.jsonl"
    )
    val_path = (
        d44
        / "v6_44_anchor_validation_transitions_DO_NOT_TRAIN.jsonl"
    )

    d30 = (
        root
        / "diagnostics"
        / "v6_30_post_joint_training_error_transition_analysis_milestone"
        / "v6_30_post_joint_error_transition_detail.jsonl"
    )

    required = (
        bridge_path,
        report48,
        manifest48,
        analysis48,
        summary48,
        train_path,
        val_path,
        d30,
    )

    for p in required:
        if not p.exists():
            raise SystemExit(
                "Missing prerequisite: "
                + str(
                    p
                )
            )

    lineage = (
        (
            bridge_path,
            EXPECTED_V648_ARTIFACT_SHA,
            "v6.48 bridge",
        ),
        (
            report48,
            EXPECTED_V648_REPORT_SHA,
            "v6.48 report",
        ),
        (
            manifest48,
            EXPECTED_V648_MANIFEST_SHA,
            "v6.48 manifest",
        ),
        (
            analysis48,
            EXPECTED_V648_ANALYSIS_SHA,
            "v6.48 analysis",
        ),
        (
            summary48,
            EXPECTED_V648_SUMMARY_SHA,
            "v6.48 summary",
        ),
        (
            d30,
            EXPECTED_V630_DETAIL_SHA,
            "v6.30 detail",
        ),
    )

    for p, expected, label in lineage:
        got = rt.sha256_file(
            p
        )

        if got != expected:
            raise SystemExit(
                label
                + " SHA mismatch: "
                + got
            )

    s48 = rt.read_json(
        summary48
    )

    expected48 = {
        "milestone_complete": True,
        "persistent_training": True,
        "optimizer_steps_executed": 80,
        "best_round": 3,
        "best_teacher_top128": 150,
        "best_free_pool4096": 43,
        "best_free_top128": 41,
        "gradient_refinement_improved_free_top128": True,
        "retained_holdout_opened": False,
        "milestone_status": "PERSISTENT_BRIDGE_IS_USABLE_BUT_REQUIRES_RUNTIME_GATE_CALIBRATION",
        "selected_v6_49_objective": "BRIDGE_GATE_CALIBRATION+TEACHER_FREE_RUN_SAFETY_FLOOR+LIVE_GENERATION_AB",
        "next_milestone": "v6.49-persistent-bridge-runtime-gate-calibration-milestone",
    }

    for key, expected in expected48.items():
        if s48.get(
            key
        ) != expected:
            raise SystemExit(
                "v6.48 summary mismatch: "
                + key
                + "="
                + repr(
                    s48.get(
                        key
                    )
                )
            )

    print(
        "========== ZANT-LLM v6.49 PERSISTENT BRIDGE RUNTIME GATE CALIBRATION =========="
    )
    print(
        "NO_MODEL_TRAINING=True"
    )
    print(
        "SOURCE_V6_48_COMPLETE=True"
    )
    print(
        "SOURCE_BEST_TEACHER_TOP128=150/160"
    )
    print(
        "SOURCE_BEST_FREE_TOP128=41/52"
    )
    print(
        "SOURCE_BEST_FREE_POOL4096=43/52"
    )
    print(
        "OBJECTIVE=BRIDGE_GATE_CALIBRATION+TEACHER_FREE_RUN_SAFETY_FLOOR+LIVE_GENERATION_AB"
    )
    print(
        "GATE_CALIBRATION_USES_TEACHER_CONTEXT_ONLY=True"
    )
    print(
        "LIVE_FREE_RUN_NOT_USED_FOR_THRESHOLD_SELECTION=True"
    )
    print(
        "RETAINED_HOLDOUT_EVALUATED=False"
    )
    print(
        "NO_GITHUB_PUSH=True"
    )

    import torch

    torch.backends.cuda.enable_flash_sdp(
        False
    )
    torch.backends.cuda.enable_mem_efficient_sdp(
        False
    )
    torch.backends.cuda.enable_math_sdp(
        True
    )

    tok, model, info = rt.load_base_with_v67_residual(
        Path(
            a.base_model
        ),
        Path(
            a.source_adapter
        ),
        Path(
            a.v67_patch
        ),
    )

    model.eval()

    for p in model.parameters():
        p.requires_grad_(
            False
        )

    Wcpu = (
        model.get_output_embeddings()
        .weight
        .detach()
        .float()
        .cpu()
    )

    bridge = torch.load(
        bridge_path,
        map_location="cpu",
        weights_only=False,
    )

    if bridge.get(
        "schema"
    ) != "ZANT_LLM_V6_48_PERSISTENT_PAIRED_CONTEXT_TOKEN_IDENTITY_BRIDGE_V1":
        raise SystemExit(
            "Unexpected v6.48 bridge schema"
        )

    projection = bridge[
        "projection_matrix"
    ].float()

    bridge_weight = bridge[
        "state_dict"
    ][
        "weight"
    ].float()

    residual_clip = float(
        bridge[
            "residual_clip"
        ]
    )

    feature_weights = dict(
        bridge[
            "feature_weights"
        ]
    )

    if int(
        bridge[
            "best_round"
        ]
    ) != 3:
        raise SystemExit(
            "Unexpected v6.48 best round"
        )

    train = read_jsonl(
        train_path
    )
    val = read_jsonl(
        val_path
    )

    def group(
        rows,
    ):
        g = {}

        for r in rows:
            sid = str(
                r[
                    "source_row_id"
                ]
            )

            g.setdefault(
                sid,
                {
                    "prompt": str(
                        r[
                            "prompt"
                        ]
                    ),
                    "target_ids": [
                        int(
                            x
                        )
                        for x in r[
                            "target_token_ids"
                        ]
                    ],
                    "plan": int(
                        r[
                            "plan_id"
                        ]
                    ),
                },
            )

        return g

    tg = group(
        train
    )
    vg = group(
        val
    )

    if len(
        tg
    ) != 80 or len(
        vg
    ) != 20:
        raise SystemExit(
            "Expected 80 train and 20 anchor source groups"
        )

    prompt_requests = []

    for sid, x in tg.items():
        x[
            "pids"
        ] = prompt_ids(
            tok,
            x[
                "prompt"
            ],
        )

        prompt_requests.append(
            (
                (
                    "TP",
                    sid,
                ),
                x[
                    "pids"
                ],
            )
        )

    for sid, x in vg.items():
        x[
            "pids"
        ] = prompt_ids(
            tok,
            x[
                "prompt"
            ],
        )

        prompt_requests.append(
            (
                (
                    "VP",
                    sid,
                ),
                x[
                    "pids"
                ],
            )
        )

    raw_prompt_states = capture_raw_states(
        torch,
        model,
        rt,
        prompt_requests,
    )

    train_prompt_states = [
        raw_prompt_states[
            (
                "TP",
                sid,
            )
        ]
        for sid in tg
    ]

    train_plan_labels = [
        tg[
            sid
        ][
            "plan"
        ]
        for sid in tg
    ]

    pred_plan = {}
    plan_confidence = {}
    plan_correct = 0

    for sid, x in vg.items():
        pp, pc = plan_knn(
            torch,
            train_prompt_states,
            train_plan_labels,
            raw_prompt_states[
                (
                    "VP",
                    sid,
                )
            ],
        )

        pred_plan[
            sid
        ] = pp

        plan_confidence[
            sid
        ] = pc

        plan_correct += int(
            pp
            == x[
                "plan"
            ]
        )

    print(
        "ANCHOR_PROMPT_PLAN_TOP1="
        + str(
            plan_correct
        )
        + "/20"
    )

    if plan_correct != 17:
        raise SystemExit(
            "v6.48 plan-predictor lineage drift"
        )

    joint = load_joint_controller(
        torch,
        rt,
        v624mod,
        jointmod,
        root,
    )

    teacher_records = teacher_calibration_records(
        torch,
        model,
        rt,
        jointmod,
        joint,
        tok,
        vg,
        {
            sid: raw_prompt_states[
                (
                    "VP",
                    sid,
                )
            ]
            for sid in vg
        },
        pred_plan,
        Wcpu,
        projection,
        feature_weights,
        bridge_weight,
        residual_clip,
    )

    if len(
        teacher_records
    ) != 160:
        raise SystemExit(
            "Expected 160 teacher calibration decisions"
        )

    (
        teacher_baseline_hits,
        gate_config,
        grid,
    ) = calibrate_gate(
        torch,
        teacher_records,
    )

    print(
        "TEACHER_BASELINE_LIVE_TOP1="
        + str(
            teacher_baseline_hits
        )
        + "/160"
    )
    print(
        "CALIBRATED_GATE_BETA="
        + str(
            gate_config[
                "beta"
            ]
        )
    )
    print(
        "CALIBRATED_GATE_THRESHOLD="
        + str(
            gate_config[
                "threshold"
            ]
        )
    )
    print(
        "CALIBRATED_GATE_TEACHER_TOP1="
        + str(
            gate_config[
                "teacher_top1"
            ]
        )
        + "/160"
    )
    print(
        "CALIBRATED_GATE_TEACHER_CHANGE="
        + str(
            gate_config[
                "teacher_top1_change"
            ]
        )
    )
    print(
        "CALIBRATED_GATE_TEACHER_ACTIVATIONS="
        + str(
            gate_config[
                "activations"
            ]
        )
        + "/160"
    )
    print(
        "CALIBRATED_GATE_OVERRIDE_PRECISION=%.6f"
        % float(
            gate_config[
                "override_precision"
            ]
        )
    )

    gate_path = (
        outdir
        / "v6_49_runtime_gate_config.json"
    )

    write_json(
        gate_path,
        {
            "schema": "ZANT_LLM_V6_49_RUNTIME_GATE_CONFIG_V1",
            "source_bridge_sha256": EXPECTED_V648_ARTIFACT_SHA,
            "calibration_domain": "teacher_forced_anchor_development_only",
            "live_free_run_used_for_calibration": False,
            "beta": float(
                gate_config[
                    "beta"
                ]
            ),
            "threshold": float(
                gate_config[
                    "threshold"
                ]
            ),
            "teacher_baseline_top1": int(
                teacher_baseline_hits
            ),
            "teacher_gated_top1": int(
                gate_config[
                    "teacher_top1"
                ]
            ),
            "teacher_top1_change": int(
                gate_config[
                    "teacher_top1_change"
                ]
            ),
            "teacher_gate_activations": int(
                gate_config[
                    "activations"
                ]
            ),
            "teacher_override_precision": float(
                gate_config[
                    "override_precision"
                ]
            ),
            "teacher_safety_floor_rule": "gated_top1_must_be_at_least_baseline_minus_1",
            "retained_holdout_evaluated": False,
        },
    )

    grid_path = (
        outdir
        / "v6_49_gate_calibration_grid.json"
    )

    write_json(
        grid_path,
        {
            "schema": "ZANT_LLM_V6_49_GATE_CALIBRATION_GRID_V1",
            "teacher_baseline_top1": int(
                teacher_baseline_hits
            ),
            "selected": gate_config,
            "grid": grid,
        },
    )

    hard_keys = sorted(
        set(
            (
                str(
                    r[
                        "id"
                    ]
                ),
                int(
                    r[
                        "step"
                    ]
                ),
            )
            for r in read_jsonl(
                d30
            )
            if r.get(
                "new_error_category"
            )
            in HARD_CATEGORIES
        )
    )

    if len(
        hard_keys
    ) != 52:
        raise SystemExit(
            "Expected 52 authoritative hard-error decisions"
        )

    outputs = {
        "baseline": {},
        "always_on": {},
        "gated": {},
    }

    step_detail = []

    beta = float(
        gate_config[
            "beta"
        ]
    )
    threshold = float(
        gate_config[
            "threshold"
        ]
    )

    for mode in (
        "baseline",
        "always_on",
        "gated",
    ):
        print(
            "LIVE_GENERATION_MODE_BEGIN="
            + mode
        )

        for idx, (
            sid,
            case,
        ) in enumerate(
            vg.items(),
            1,
        ):
            joint = load_joint_controller(
                torch,
                rt,
                v624mod,
                jointmod,
                root,
            )

            pred, steps = live_generate(
                torch,
                model,
                rt,
                jointmod,
                joint,
                tok,
                case,
                raw_prompt_states[
                    (
                        "VP",
                        sid,
                    )
                ],
                pred_plan[
                    sid
                ],
                Wcpu,
                projection,
                feature_weights,
                bridge_weight,
                residual_clip,
                beta,
                threshold,
                mode,
            )

            outputs[
                mode
            ][
                sid
            ] = pred

            canonical = case[
                "target_ids"
            ][
                :MAX_NEW_TOKENS
            ]

            for s in steps:
                step = int(
                    s[
                        "step"
                    ]
                )

                s.update(
                    {
                        "mode": mode,
                        "id": sid,
                        "predicted_plan": int(
                            pred_plan[
                                sid
                            ]
                        ),
                        "plan_confidence": float(
                            plan_confidence[
                                sid
                            ]
                        ),
                        "canonical_token_id": (
                            int(
                                canonical[
                                    step
                                ]
                            )
                            if step
                            < len(
                                canonical
                            )
                            else None
                        ),
                        "chosen_matches_canonical": bool(
                            step
                            < len(
                                canonical
                            )
                            and int(
                                s[
                                    "chosen_token_id"
                                ]
                            )
                            == int(
                                canonical[
                                    step
                                ]
                            )
                        ),
                        "authoritative_hard_error": bool(
                            (
                                sid,
                                step,
                            )
                            in set(
                                hard_keys
                            )
                        ),
                    }
                )

                step_detail.append(
                    s
                )

            if idx % 5 == 0:
                print(
                    "LIVE_GENERATION_PROGRESS="
                    + mode
                    + ":"
                    + str(
                        idx
                    )
                    + "/20",
                    flush=True,
                )

        print(
            "LIVE_GENERATION_MODE_DONE="
            + mode
        )

    baseline_metrics = sequence_metrics(
        vg,
        outputs[
            "baseline"
        ],
        hard_keys,
    )

    always_metrics = sequence_metrics(
        vg,
        outputs[
            "always_on"
        ],
        hard_keys,
    )

    gated_metrics = sequence_metrics(
        vg,
        outputs[
            "gated"
        ],
        hard_keys,
    )

    gated_activations = sum(
        int(
            r[
                "gate_activated"
            ]
        )
        for r in step_detail
        if r[
            "mode"
        ]
        == "gated"
    )

    gated_correct_overrides = sum(
        int(
            r[
                "gate_activated"
            ]
            and r[
                "chosen_matches_canonical"
            ]
        )
        for r in step_detail
        if r[
            "mode"
        ]
        == "gated"
    )

    gated_override_precision = (
        gated_correct_overrides
        / float(
            gated_activations
        )
        if gated_activations
        else 1.0
    )

    detail_path = (
        outdir
        / "v6_49_live_generation_detail.jsonl"
    )

    report_path = (
        outdir
        / "v6_49_runtime_gate_report.json"
    )

    write_jsonl(
        detail_path,
        step_detail,
    )

    report = {
        "schema": "ZANT_LLM_V6_49_RUNTIME_GATE_CALIBRATION_REPORT_V1",
        "milestone_diagnostic_complete": True,
        "no_model_training": True,
        "source_v6_48_bridge_sha256": EXPECTED_V648_ARTIFACT_SHA,
        "anchor_prompt_plan_top1": int(
            plan_correct
        ),
        "teacher_baseline_live_top1": int(
            teacher_baseline_hits
        ),
        "gate_beta": float(
            beta
        ),
        "gate_threshold": float(
            threshold
        ),
        "gate_teacher_top1": int(
            gate_config[
                "teacher_top1"
            ]
        ),
        "gate_teacher_top1_change": int(
            gate_config[
                "teacher_top1_change"
            ]
        ),
        "gate_teacher_activations": int(
            gate_config[
                "activations"
            ]
        ),
        "gate_teacher_override_precision": float(
            gate_config[
                "override_precision"
            ]
        ),
        "baseline_live": baseline_metrics,
        "always_on_live": always_metrics,
        "gated_live": gated_metrics,
        "gated_live_activations": int(
            gated_activations
        ),
        "gated_live_override_precision": float(
            gated_override_precision
        ),
        "gated_token_match_gain_over_baseline": int(
            gated_metrics[
                "token_matches"
            ]
            - baseline_metrics[
                "token_matches"
            ]
        ),
        "gated_hard52_gain_over_baseline": int(
            gated_metrics[
                "hard52_matches"
            ]
            - baseline_metrics[
                "hard52_matches"
            ]
        ),
        "gated_first_token_change": int(
            gated_metrics[
                "first_token_top1"
            ]
            - baseline_metrics[
                "first_token_top1"
            ]
        ),
        "always_on_token_match_gain_over_baseline": int(
            always_metrics[
                "token_matches"
            ]
            - baseline_metrics[
                "token_matches"
            ]
        ),
        "always_on_hard52_gain_over_baseline": int(
            always_metrics[
                "hard52_matches"
            ]
            - baseline_metrics[
                "hard52_matches"
            ]
        ),
        "retained_holdout_evaluated": False,
        "github_push_performed": False,
        "gate_config_sha256": rt.sha256_file(
            gate_path
        ),
        "detail_sha256": rt.sha256_file(
            detail_path
        ),
    }

    write_json(
        report_path,
        report,
    )

    print(
        "========== V6.49 RUNTIME GATE SUMMARY =========="
    )
    print(
        "V6_49_DIAGNOSTIC_COMPLETE=True"
    )
    print(
        "NO_MODEL_TRAINING=True"
    )
    print(
        "GATE_BETA="
        + str(
            beta
        )
    )
    print(
        "GATE_THRESHOLD="
        + str(
            threshold
        )
    )
    print(
        "TEACHER_BASELINE_LIVE_TOP1="
        + str(
            teacher_baseline_hits
        )
        + "/160"
    )
    print(
        "TEACHER_GATED_LIVE_TOP1="
        + str(
            gate_config[
                "teacher_top1"
            ]
        )
        + "/160"
    )
    print(
        "TEACHER_GATED_TOP1_CHANGE="
        + str(
            gate_config[
                "teacher_top1_change"
            ]
        )
    )
    print(
        "BASELINE_LIVE_TOKEN_MATCH="
        + str(
            baseline_metrics[
                "token_matches"
            ]
        )
        + "/"
        + str(
            baseline_metrics[
                "total_decisions"
            ]
        )
    )
    print(
        "BASELINE_LIVE_FIRST_TOKEN="
        + str(
            baseline_metrics[
                "first_token_top1"
            ]
        )
        + "/20"
    )
    print(
        "BASELINE_LIVE_HARD52_MATCH="
        + str(
            baseline_metrics[
                "hard52_matches"
            ]
        )
        + "/52"
    )
    print(
        "ALWAYS_ON_LIVE_TOKEN_MATCH="
        + str(
            always_metrics[
                "token_matches"
            ]
        )
        + "/"
        + str(
            always_metrics[
                "total_decisions"
            ]
        )
    )
    print(
        "ALWAYS_ON_LIVE_FIRST_TOKEN="
        + str(
            always_metrics[
                "first_token_top1"
            ]
        )
        + "/20"
    )
    print(
        "ALWAYS_ON_LIVE_HARD52_MATCH="
        + str(
            always_metrics[
                "hard52_matches"
            ]
        )
        + "/52"
    )
    print(
        "GATED_LIVE_TOKEN_MATCH="
        + str(
            gated_metrics[
                "token_matches"
            ]
        )
        + "/"
        + str(
            gated_metrics[
                "total_decisions"
            ]
        )
    )
    print(
        "GATED_LIVE_FIRST_TOKEN="
        + str(
            gated_metrics[
                "first_token_top1"
            ]
        )
        + "/20"
    )
    print(
        "GATED_LIVE_HARD52_MATCH="
        + str(
            gated_metrics[
                "hard52_matches"
            ]
        )
        + "/52"
    )
    print(
        "GATED_LIVE_ACTIVATIONS="
        + str(
            gated_activations
        )
        + "/160"
    )
    print(
        "GATED_LIVE_OVERRIDE_PRECISION=%.6f"
        % float(
            gated_override_precision
        )
    )
    print(
        "GATED_TOKEN_MATCH_GAIN_OVER_BASELINE="
        + str(
            report[
                "gated_token_match_gain_over_baseline"
            ]
        )
    )
    print(
        "GATED_HARD52_GAIN_OVER_BASELINE="
        + str(
            report[
                "gated_hard52_gain_over_baseline"
            ]
        )
    )
    print(
        "GATED_FIRST_TOKEN_CHANGE="
        + str(
            report[
                "gated_first_token_change"
            ]
        )
    )
    print(
        "RUNTIME_GATE_CONFIG_SHA256="
        + rt.sha256_file(
            gate_path
        )
    )
    print(
        "DETAIL_SHA256="
        + rt.sha256_file(
            detail_path
        )
    )
    print(
        "REPORT_SHA256="
        + rt.sha256_file(
            report_path
        )
    )
    print(
        "RETAINED_HOLDOUT_EVALUATED=False"
    )
    print(
        "NO_GITHUB_PUSH=True"
    )


if __name__ == "__main__":
    main()
