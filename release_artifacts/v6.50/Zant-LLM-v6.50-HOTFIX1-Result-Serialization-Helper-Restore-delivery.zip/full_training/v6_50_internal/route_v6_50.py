from pathlib import Path
import argparse
import importlib.util


def load_module(path, name):
    spec = importlib.util.spec_from_file_location(
        name,
        str(path),
    )
    mod = importlib.util.module_from_spec(
        spec
    )
    spec.loader.exec_module(
        mod
    )
    return mod


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument(
        "--report",
        required=True,
    )
    ap.add_argument(
        "--runtime-script",
        required=True,
    )
    ap.add_argument(
        "--artifact-dir",
        required=True,
    )
    a = ap.parse_args()

    rt = load_module(
        a.runtime_script,
        "v650_route_rt",
    )

    r = rt.read_json(
        Path(
            a.report
        )
    )

    outdir = Path(
        a.artifact_dir
    )

    if r.get(
        "milestone_diagnostic_complete"
    ) is not True:
        raise SystemExit(
            "v6.50 integration incomplete"
        )

    parity = bool(
        r[
            "runtime_parity_pass"
        ]
    )

    safety = bool(
        r[
            "runtime_safety_fallback_contract_pass"
        ]
    )

    baseline = r[
        "baseline_live"
    ]
    gated = r[
        "gated_live"
    ]

    token_gain = int(
        gated[
            "token_matches"
        ]
        - baseline[
            "token_matches"
        ]
    )

    hard_gain = int(
        gated[
            "hard52_matches"
        ]
        - baseline[
            "hard52_matches"
        ]
    )

    first_gain = int(
        gated[
            "first_token_top1"
        ]
        - baseline[
            "first_token_top1"
        ]
    )

    if (
        parity
        and safety
        and token_gain >= 60
        and hard_gain >= 25
        and first_gain >= 8
    ):
        status = "CONTROLLED_GENERATION_RUNTIME_PACKAGE_REPRODUCES_V6_49_AND_IS_READY_FOR_GENERALIZATION_EVAL"
        nxt = "v6.51-controlled-generation-generalization-and-runtime-robustness-milestone"
        obj = "UNSEEN_DEV_GENERALIZATION+LATENCY_MEMORY+FALLBACK_STRESS+INFERENCE_PACKAGE_VALIDATION"

    elif (
        parity
        and token_gain > 0
    ):
        status = "CONTROLLED_GENERATION_RUNTIME_INTEGRATES_BUT_NEEDS_SAFETY_OR_ROBUSTNESS_HARDENING"
        nxt = "v6.51-controlled-generation-runtime-safety-hardening-milestone"
        obj = "FALLBACK_STRESS+NUMERICAL_GUARDS+RUNTIME_RECOVERY+INFERENCE_VALIDATION"

    else:
        status = "CONTROLLED_GENERATION_INTEGRATION_DOES_NOT_REPRODUCE_THE_V6_49_RUNTIME_SIGNAL"
        nxt = "v6.51-runtime-parity-and-integration-correction-milestone"
        obj = "V6_49_PARITY_REPAIR+RUNTIME_STATE_ALIGNMENT+GATE_INTEGRATION_AUDIT"

    analysis = {
        "schema": "ZANT_LLM_V6_50_MILESTONE_ANALYSIS_V1",
        "runtime_parity_pass": parity,
        "runtime_safety_fallback_contract_pass": safety,
        "baseline_live_token_matches": int(
            baseline[
                "token_matches"
            ]
        ),
        "gated_live_token_matches": int(
            gated[
                "token_matches"
            ]
        ),
        "gated_token_gain": token_gain,
        "gated_hard52_gain": hard_gain,
        "gated_first_token_gain": first_gain,
        "classification": status,
        "training_authorized": False,
        "retained_holdout_opened": False,
        "selected_v6_51_objective": obj,
        "next_milestone": nxt,
    }

    analysis_path = (
        outdir
        / "v6_50_milestone_analysis.json"
    )

    rt.write_json(
        analysis_path,
        analysis,
    )

    summary = {
        "schema": "ZANT_LLM_V6_50_CONTROLLED_GENERATION_INTEGRATION_MILESTONE_V1",
        "milestone_complete": True,
        "no_model_training": True,
        "runtime_bundle_created": True,
        "runtime_parity_pass": parity,
        "runtime_safety_fallback_contract_pass": safety,
        "baseline_live_token_matches": int(
            baseline[
                "token_matches"
            ]
        ),
        "gated_live_token_matches": int(
            gated[
                "token_matches"
            ]
        ),
        "baseline_live_first_token_top1": int(
            baseline[
                "first_token_top1"
            ]
        ),
        "gated_live_first_token_top1": int(
            gated[
                "first_token_top1"
            ]
        ),
        "baseline_live_hard52_matches": int(
            baseline[
                "hard52_matches"
            ]
        ),
        "gated_live_hard52_matches": int(
            gated[
                "hard52_matches"
            ]
        ),
        "training_authorized": False,
        "retained_holdout_opened": False,
        "milestone_status": status,
        "selected_v6_51_objective": obj,
        "next_milestone": nxt,
        "github_push_performed": False,
    }

    summary_path = (
        outdir
        / "v6_50_milestone_summary.json"
    )

    rt.write_json(
        summary_path,
        summary,
    )

    print(
        "========== V6.50 MILESTONE FINAL =========="
    )
    print(
        "V6_50_MILESTONE_COMPLETE=True"
    )
    print(
        "NO_MODEL_TRAINING=True"
    )
    print(
        "RUNTIME_BUNDLE_CREATED=True"
    )
    print(
        "RUNTIME_PARITY_PASS="
        + str(
            parity
        )
    )
    print(
        "RUNTIME_SAFETY_FALLBACK_CONTRACT_PASS="
        + str(
            safety
        )
    )
    print(
        "GATED_TOKEN_GAIN="
        + str(
            token_gain
        )
    )
    print(
        "GATED_HARD52_GAIN="
        + str(
            hard_gain
        )
    )
    print(
        "GATED_FIRST_TOKEN_GAIN="
        + str(
            first_gain
        )
    )
    print(
        "TRAINING_AUTHORIZED=False"
    )
    print(
        "RETAINED_HOLDOUT_OPENED=False"
    )
    print(
        "MILESTONE_STATUS="
        + status
    )
    print(
        "SELECTED_V6_51_OBJECTIVE="
        + obj
    )
    print(
        "ANALYSIS_SHA256="
        + rt.sha256_file(
            analysis_path
        )
    )
    print(
        "FINAL_SUMMARY_SHA256="
        + rt.sha256_file(
            summary_path
        )
    )
    print(
        "NEXT_MILESTONE="
        + nxt
    )
    print(
        "GITHUB_PUSH_PERFORMED=False"
    )


if __name__ == "__main__":
    main()
