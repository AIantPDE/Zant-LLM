from pathlib import Path
import importlib.util
import json
import gc


def load_module(path, name):
    spec = importlib.util.spec_from_file_location(name, str(path))
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def finite_tensor(torch, x):
    return bool(torch.isfinite(x).all().item())


def safe_live_generate(
    torch,
    model,
    rt,
    jointmod,
    joint,
    ref,
    case,
    raw_prompt_state,
    predicted_plan,
    plan_confidence,
    Wcpu,
    projection,
    feature_weights,
    bridge_weight,
    residual_clip,
    beta,
    threshold,
    mode="gated",
    max_new_tokens=8,
):
    """
    v6.50 reusable controlled-generation runtime.

    Safety behavior:
    - baseline is always available;
    - any bridge/fusion numerical error falls back to baseline;
    - bridge is disabled after step 7 because the trained feature uses an
      8-position step one-hot;
    - baseline controller stays active for every step.
    """
    final_norm, _ = rt.find_final_norm(model)
    cap = {"h": None}

    def raw_hook(module, args, out):
        cap["h"] = rt.extract_hidden(out)

    raw_handle = final_norm.register_forward_hook(raw_hook)
    controller_handle, _ = jointmod.install_joint_controller(
        model,
        joint,
        rt,
    )

    generated = []
    steps = []
    fallback_count = 0

    try:
        joint.reset_history()

        with torch.no_grad():
            for step in range(int(max_new_tokens)):
                ids = case["pids"] + generated

                xin = torch.tensor(
                    [ids],
                    dtype=torch.long,
                    device="cuda:0",
                )
                mask = torch.ones_like(xin)

                cap["h"] = None

                out = model(
                    input_ids=xin,
                    attention_mask=mask,
                    use_cache=False,
                )
                torch.cuda.synchronize()

                if cap["h"] is None:
                    raise RuntimeError(
                        "v6.50 raw hidden capture failed"
                    )

                raw_hidden = (
                    cap["h"][0, -1, :]
                    .detach()
                    .float()
                    .cpu()
                )

                baseline_logits = (
                    out.logits[0, -1, :]
                    .detach()
                    .float()
                )

                baseline_id = int(
                    torch.argmax(
                        baseline_logits
                    ).item()
                )

                chosen = baseline_id
                activated = False
                fallback_reason = ""
                prop = {
                    "baseline_token_id": baseline_id,
                    "bridge_top1_token_id": baseline_id,
                    "candidate_token_id": baseline_id,
                    "candidate_advantage": 0.0,
                    "bridge_margin": 0.0,
                    "candidate_differs_from_baseline": False,
                }

                bridge_eligible = (
                    mode in ("always_on", "gated")
                    and step < 8
                )

                if mode == "baseline":
                    bridge_eligible = False
                    fallback_reason = "baseline_mode"
                elif step >= 8:
                    fallback_reason = "step_out_of_calibrated_range"

                if bridge_eligible:
                    try:
                        prev1 = (
                            Wcpu[generated[step - 1]]
                            if step > 0
                            else None
                        )
                        prev2 = (
                            Wcpu[generated[step - 2]]
                            if step > 1
                            else None
                        )

                        fx = ref.feature(
                            torch,
                            raw_hidden,
                            raw_prompt_state,
                            prev1,
                            prev2,
                            predicted_plan,
                            step,
                            projection,
                            feature_weights,
                        )

                        query = ref.bridge_query(
                            torch,
                            fx,
                            raw_hidden,
                            bridge_weight,
                            residual_clip,
                        )

                        if not finite_tensor(torch, query):
                            raise FloatingPointError(
                                "non-finite bridge query"
                            )

                        bridge_logits = ref.direct_logits(
                            torch,
                            model,
                            query,
                        )

                        if not finite_tensor(torch, bridge_logits):
                            raise FloatingPointError(
                                "non-finite bridge logits"
                            )

                        prop = ref.fused_candidate(
                            torch,
                            baseline_logits,
                            bridge_logits,
                            beta,
                        )

                        if mode == "always_on":
                            chosen = int(
                                prop["candidate_token_id"]
                            )
                            activated = bool(
                                chosen != baseline_id
                            )

                        elif mode == "gated":
                            activated = bool(
                                prop[
                                    "candidate_differs_from_baseline"
                                ]
                                and float(
                                    prop["candidate_advantage"]
                                ) >= float(threshold)
                            )

                            chosen = (
                                int(
                                    prop["candidate_token_id"]
                                )
                                if activated
                                else baseline_id
                            )

                    except Exception as e:
                        chosen = baseline_id
                        activated = False
                        fallback_count += 1
                        fallback_reason = (
                            "bridge_exception:"
                            + e.__class__.__name__
                        )

                generated.append(
                    int(chosen)
                )

                steps.append(
                    {
                        "step": int(step),
                        "baseline_token_id": int(
                            baseline_id
                        ),
                        "bridge_top1_token_id": int(
                            prop[
                                "bridge_top1_token_id"
                            ]
                        ),
                        "fused_candidate_token_id": int(
                            prop[
                                "candidate_token_id"
                            ]
                        ),
                        "chosen_token_id": int(chosen),
                        "gate_activated": bool(activated),
                        "candidate_advantage": float(
                            prop["candidate_advantage"]
                        ),
                        "bridge_margin": float(
                            prop["bridge_margin"]
                        ),
                        "predicted_plan": int(
                            predicted_plan
                        ),
                        "plan_confidence": float(
                            plan_confidence
                        ),
                        "fallback_reason": str(
                            fallback_reason
                        ),
                    }
                )

                del (
                    xin,
                    mask,
                    out,
                    raw_hidden,
                    baseline_logits,
                )

    finally:
        controller_handle.remove()
        raw_handle.remove()
        cap["h"] = None
        gc.collect()

        if torch.cuda.is_available():
            torch.cuda.empty_cache()
            torch.cuda.synchronize()

    return generated, steps, fallback_count


def sequence_metrics(cases, outputs, hard_keys):
    total = 0
    matches = 0
    first = 0
    exact = 0
    hard_matches = 0
    hitmax = 0
    hard_set = set(hard_keys)

    for sid, case in cases.items():
        target = case["target_ids"][:8]
        pred = outputs[sid]

        if len(pred) >= 8:
            hitmax += 1

        first += int(
            bool(target)
            and bool(pred)
            and int(target[0]) == int(pred[0])
        )

        exact += int(
            pred[:len(target)] == target
        )

        for step, tid in enumerate(target):
            total += 1

            if (
                step < len(pred)
                and int(pred[step]) == int(tid)
            ):
                matches += 1

                if (sid, step) in hard_set:
                    hard_matches += 1

    return {
        "total_decisions": int(total),
        "token_matches": int(matches),
        "first_token_top1": int(first),
        "exact_sequences": int(exact),
        "hard52_matches": int(hard_matches),
        "hit_max_new_tokens": int(hitmax),
    }
