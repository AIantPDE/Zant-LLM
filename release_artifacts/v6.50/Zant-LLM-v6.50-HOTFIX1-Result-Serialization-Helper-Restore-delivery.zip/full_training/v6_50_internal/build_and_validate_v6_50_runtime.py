from pathlib import Path
import argparse
import importlib.util
import json
import gc

EXPECTED_V648_ARTIFACT_SHA = "0446fece29c00eacb74bd3cc037ac08911fb8df503c85f574e92bc07c55f0204"
EXPECTED_V649_GATE_SHA = "a523fbccef82773126a01a19545356063359cbecf33c0013d9654e1eabe16687"
EXPECTED_V649_DETAIL_SHA = "d3ea8d1e0b8a3b1e854726b096c053a80b1e87e2ce27a438bbe6828c27daffeb"
EXPECTED_V649_REPORT_SHA = "b6b53d4b0aedd9642705759a2544a2cbb64b1ead4794a453ca76088283a943c2"
EXPECTED_V649_ANALYSIS_SHA = "b31ea5a68e1fca6b72eb52e34951ddef2515447fabc94c03dedd4fb78dcba288"
EXPECTED_V649_SUMMARY_SHA = "55ecc988b4cc2c949242cbe8c5ff6a325d49b5d8952c5f3fd9e484c22178af01"

EXPECTED_V630_DETAIL_SHA = "09892653c8b5218400aa6b60dea28754aadd93c3d3d3693e7248ef21d34e547e"

HARD_CATEGORIES = {
    "JOINT_OUTPUT_ALREADY_TOP10_BUT_NOT_TOP1",
    "STATE_HEAD_RECOVERS_CONTROL_REGION_BUT_FINAL_POLICY_MISSES",
    "CURRENT_PREFIX_STATE_IS_CONTROLLABLE_BUT_JOINT_POLICY_MISSES",
}


def load_module(path, name):
    spec = importlib.util.spec_from_file_location(
        name,
        str(path),
    )
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def read_jsonl(path):
    rows = []

    with Path(path).open(
        "r",
        encoding="utf-8",
    ) as f:
        for line in f:
            if line.strip():
                rows.append(
                    json.loads(line)
                )

    return rows


def write_json(path, obj):
    Path(path).write_text(
        json.dumps(
            obj,
            ensure_ascii=False,
            indent=2,
        )
        + "\n",
        encoding="utf-8",
        newline="\n",
    )


def write_jsonl(path, rows):
    """
    v6.50 HOTFIX1:
    Missing helper restored. This changes only result serialization and does
    not alter runtime integration, metrics, thresholds, routing, or artifacts.
    """
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)

    with path.open(
        "w",
        encoding="utf-8",
        newline="\n",
    ) as f:
        for row in rows:
            f.write(
                json.dumps(
                    row,
                    ensure_ascii=False,
                    separators=(",", ":"),
                )
                + "\n"
            )


def group(rows):
    g = {}

    for r in rows:
        sid = str(
            r["source_row_id"]
        )

        g.setdefault(
            sid,
            {
                "prompt": str(
                    r["prompt"]
                ),
                "target_ids": [
                    int(x)
                    for x in r[
                        "target_token_ids"
                    ]
                ],
                "plan": int(
                    r["plan_id"]
                ),
            },
        )

    return g


def main():
    ap = argparse.ArgumentParser()

    for name in (
        "root",
        "base-model",
        "source-adapter",
        "v67-patch",
        "runtime-script",
        "v624-controller-script",
        "joint-controller-script",
        "reference-runtime-script",
        "v650-runtime-script",
        "artifact-dir",
    ):
        ap.add_argument(
            "--" + name,
            required=True,
        )

    a = ap.parse_args()

    root = Path(a.root)
    artifact_dir = Path(
        a.artifact_dir
    )
    artifact_dir.mkdir(
        parents=True,
        exist_ok=True,
    )

    rt = load_module(
        a.runtime_script,
        "v650_build_rt",
    )

    ref = load_module(
        a.reference_runtime_script,
        "v650_ref",
    )

    v650rt = load_module(
        a.v650_runtime_script,
        "v650_runtime",
    )

    v624mod = load_module(
        a.v624_controller_script,
        "v650_v624",
    )

    jointmod = load_module(
        a.joint_controller_script,
        "v650_joint",
    )

    d48 = (
        root
        / "artifacts"
        / "Zant-LLM-v6_48-paired-context-token-identity-bridge"
    )

    bridge_path = (
        d48
        / "paired_context_token_identity_bridge.pt"
    )

    d49 = (
        root
        / "diagnostics"
        / "v6_49_persistent_bridge_runtime_gate_calibration_milestone"
    )

    gate_path = (
        d49
        / "v6_49_runtime_gate_config.json"
    )

    detail49 = (
        d49
        / "v6_49_live_generation_detail.jsonl"
    )
    report49 = (
        d49
        / "v6_49_runtime_gate_report.json"
    )
    analysis49 = (
        d49
        / "v6_49_milestone_analysis.json"
    )
    summary49 = (
        d49
        / "v6_49_milestone_summary.json"
    )

    d44 = (
        root
        / "full_training"
        / "v6_44_dedicated_transition_supervision_dataset"
    )

    train_path = (
        d44
        / "v6_44_dedicated_train_transitions.jsonl"
    )
    val_path = (
        d44
        / "v6_44_anchor_validation_transitions_DO_NOT_TRAIN.jsonl"
    )

    d30 = (
        root
        / "diagnostics"
        / "v6_30_post_joint_training_error_transition_analysis_milestone"
        / "v6_30_post_joint_error_transition_detail.jsonl"
    )

    required = (
        bridge_path,
        gate_path,
        detail49,
        report49,
        analysis49,
        summary49,
        train_path,
        val_path,
        d30,
    )

    for p in required:
        if not p.exists():
            raise SystemExit(
                "Missing prerequisite: "
                + str(p)
            )

    lineage = (
        (
            bridge_path,
            EXPECTED_V648_ARTIFACT_SHA,
            "v6.48 bridge",
        ),
        (
            gate_path,
            EXPECTED_V649_GATE_SHA,
            "v6.49 gate",
        ),
        (
            detail49,
            EXPECTED_V649_DETAIL_SHA,
            "v6.49 detail",
        ),
        (
            report49,
            EXPECTED_V649_REPORT_SHA,
            "v6.49 report",
        ),
        (
            analysis49,
            EXPECTED_V649_ANALYSIS_SHA,
            "v6.49 analysis",
        ),
        (
            summary49,
            EXPECTED_V649_SUMMARY_SHA,
            "v6.49 summary",
        ),
        (
            d30,
            EXPECTED_V630_DETAIL_SHA,
            "v6.30 detail",
        ),
    )

    for p, expected, label in lineage:
        got = rt.sha256_file(p)

        if got != expected:
            raise SystemExit(
                label
                + " SHA mismatch: "
                + got
            )

    s49 = rt.read_json(
        summary49
    )

    expected49 = {
        "milestone_complete": True,
        "no_model_training": True,
        "anchor_prompt_plan_top1": 17,
        "baseline_live_token_matches": 2,
        "baseline_live_first_token_top1": 0,
        "baseline_live_hard52_matches": 0,
        "always_on_live_token_matches": 71,
        "always_on_live_first_token_top1": 10,
        "always_on_live_hard52_matches": 32,
        "gated_live_token_matches": 69,
        "gated_live_first_token_top1": 10,
        "gated_live_hard52_matches": 32,
        "gated_live_activations": 113,
        "gated_token_match_gain_over_baseline": 67,
        "gated_hard52_gain_over_baseline": 32,
        "gated_first_token_change": 10,
        "training_authorized": False,
        "retained_holdout_opened": False,
        "milestone_status": "CALIBRATED_RUNTIME_GATE_TRANSLATES_PERSISTENT_BRIDGE_SIGNAL_INTO_LIVE_GENERATION",
        "selected_v6_50_objective": "LIVE_GATED_BRIDGE_CONTROLLER_COEXECUTION+SEQUENCE_METRICS+RUNTIME_SAFETY_FALLBACK+INFERENCE_PACKAGE",
        "next_milestone": "v6.50-persistent-bridge-controlled-generation-integration-milestone",
    }

    for key, expected in expected49.items():
        if s49.get(key) != expected:
            raise SystemExit(
                "v6.49 summary mismatch: "
                + key
                + "="
                + repr(
                    s49.get(key)
                )
            )

    print(
        "========== ZANT-LLM v6.50 CONTROLLED GENERATION INTEGRATION =========="
    )
    print(
        "HOTFIX1_RESULT_SERIALIZATION_HELPER_RESTORED=True"
    )
    print(
        "SEMANTIC_OBJECTIVE_UNCHANGED=True"
    )
    print(
        "RUNTIME_THRESHOLDS_UNCHANGED=True"
    )
    print("NO_MODEL_TRAINING=True")
    print("SOURCE_V6_49_COMPLETE=True")
    print("SOURCE_GATED_LIVE_TOKEN_MATCH=69/160")
    print("SOURCE_GATED_LIVE_FIRST_TOKEN=10/20")
    print("SOURCE_GATED_LIVE_HARD52_MATCH=32/52")
    print(
        "OBJECTIVE=LIVE_GATED_BRIDGE_CONTROLLER_COEXECUTION+SEQUENCE_METRICS+RUNTIME_SAFETY_FALLBACK+INFERENCE_PACKAGE"
    )
    print("RETAINED_HOLDOUT_EVALUATED=False")
    print("NO_GITHUB_PUSH=True")

    import torch

    torch.backends.cuda.enable_flash_sdp(
        False
    )
    torch.backends.cuda.enable_mem_efficient_sdp(
        False
    )
    torch.backends.cuda.enable_math_sdp(
        True
    )

    tok, model, info = rt.load_base_with_v67_residual(
        Path(a.base_model),
        Path(a.source_adapter),
        Path(a.v67_patch),
    )

    model.eval()

    for p in model.parameters():
        p.requires_grad_(False)

    Wcpu = (
        model.get_output_embeddings()
        .weight
        .detach()
        .float()
        .cpu()
    )

    bridge = torch.load(
        bridge_path,
        map_location="cpu",
        weights_only=False,
    )

    gate = rt.read_json(
        gate_path
    )

    if float(
        gate["beta"]
    ) != 0.75:
        raise SystemExit(
            "Unexpected v6.49 beta"
        )

    if float(
        gate["threshold"]
    ) != 0.5:
        raise SystemExit(
            "Unexpected v6.49 threshold"
        )

    train = read_jsonl(
        train_path
    )
    val = read_jsonl(
        val_path
    )

    tg = group(
        train
    )
    vg = group(
        val
    )

    if len(tg) != 80:
        raise SystemExit(
            "Expected 80 train prompt groups"
        )

    if len(vg) != 20:
        raise SystemExit(
            "Expected 20 validation prompt groups"
        )

    prompt_requests = []

    for sid, x in tg.items():
        x["pids"] = ref.prompt_ids(
            tok,
            x["prompt"],
        )

        prompt_requests.append(
            (
                ("TP", sid),
                x["pids"],
            )
        )

    for sid, x in vg.items():
        x["pids"] = ref.prompt_ids(
            tok,
            x["prompt"],
        )

        prompt_requests.append(
            (
                ("VP", sid),
                x["pids"],
            )
        )

    prompt_states = ref.capture_raw_states(
        torch,
        model,
        rt,
        prompt_requests,
    )

    train_ids = list(
        tg.keys()
    )

    train_prompt_tensor = torch.stack(
        [
            prompt_states[
                ("TP", sid)
            ].float()
            for sid in train_ids
        ]
    )

    train_plan_labels = torch.tensor(
        [
            int(
                tg[sid]["plan"]
            )
            for sid in train_ids
        ],
        dtype=torch.long,
    )

    runtime_bundle_path = (
        artifact_dir
        / "v6_50_controlled_generation_runtime_bundle.pt"
    )

    torch.save(
        {
            "schema": "ZANT_LLM_V6_50_CONTROLLED_GENERATION_RUNTIME_BUNDLE_V1",
            "source_v6_48_bridge_sha256": EXPECTED_V648_ARTIFACT_SHA,
            "source_v6_49_gate_sha256": EXPECTED_V649_GATE_SHA,
            "bridge": bridge,
            "gate": {
                "beta": float(
                    gate["beta"]
                ),
                "threshold": float(
                    gate["threshold"]
                ),
            },
            "plan_train_source_ids": train_ids,
            "plan_train_prompt_states": train_prompt_tensor,
            "plan_train_labels": train_plan_labels,
            "plan_knn_k": 9,
            "plan_knn_temperature": 0.10,
            "bridge_calibrated_steps": 8,
            "safety_fallback": {
                "non_finite_query": "baseline",
                "non_finite_logits": "baseline",
                "bridge_exception": "baseline",
                "step_ge_8": "baseline",
            },
            "retained_holdout_evaluated": False,
        },
        runtime_bundle_path,
    )

    print(
        "RUNTIME_BUNDLE_CREATED=True"
    )
    print(
        "RUNTIME_PLAN_TRAIN_STATES=80"
    )

    pred_plan = {}
    plan_conf = {}
    plan_correct = 0

    train_state_list = [
        train_prompt_tensor[i]
        for i in range(
            int(
                train_prompt_tensor.shape[0]
            )
        )
    ]

    label_list = [
        int(x)
        for x in train_plan_labels.tolist()
    ]

    for sid, x in vg.items():
        pp, pc = ref.plan_knn(
            torch,
            train_state_list,
            label_list,
            prompt_states[
                ("VP", sid)
            ],
        )

        pred_plan[sid] = pp
        plan_conf[sid] = pc
        plan_correct += int(
            pp == x["plan"]
        )

    if plan_correct != 17:
        raise SystemExit(
            "v6.49 plan predictor reproduction drift"
        )

    hard_keys = sorted(
        set(
            (
                str(r["id"]),
                int(r["step"]),
            )
            for r in read_jsonl(
                d30
            )
            if r.get(
                "new_error_category"
            )
            in HARD_CATEGORIES
        )
    )

    if len(hard_keys) != 52:
        raise SystemExit(
            "Expected 52 hard-error decisions"
        )

    projection = bridge[
        "projection_matrix"
    ].float()

    bridge_weight = bridge[
        "state_dict"
    ]["weight"].float()

    feature_weights = dict(
        bridge["feature_weights"]
    )

    residual_clip = float(
        bridge["residual_clip"]
    )

    beta = float(
        gate["beta"]
    )
    threshold = float(
        gate["threshold"]
    )

    outputs = {
        "baseline": {},
        "always_on": {},
        "gated": {},
    }

    detail_rows = []
    fallback_total = 0

    for mode in (
        "baseline",
        "always_on",
        "gated",
    ):
        print(
            "INTEGRATION_MODE_BEGIN="
            + mode
        )

        for idx, (
            sid,
            case,
        ) in enumerate(
            vg.items(),
            1,
        ):
            joint = ref.load_joint_controller(
                torch,
                rt,
                v624mod,
                jointmod,
                root,
            )

            pred, steps, fallback_count = v650rt.safe_live_generate(
                torch,
                model,
                rt,
                jointmod,
                joint,
                ref,
                case,
                prompt_states[
                    ("VP", sid)
                ],
                pred_plan[sid],
                plan_conf[sid],
                Wcpu,
                projection,
                feature_weights,
                bridge_weight,
                residual_clip,
                beta,
                threshold,
                mode=mode,
                max_new_tokens=8,
            )

            outputs[mode][sid] = pred
            fallback_total += int(
                fallback_count
            )

            canonical = case[
                "target_ids"
            ][
                :8
            ]

            for row in steps:
                step = int(
                    row["step"]
                )

                row.update(
                    {
                        "mode": mode,
                        "id": sid,
                        "canonical_token_id": (
                            int(
                                canonical[
                                    step
                                ]
                            )
                            if step
                            < len(
                                canonical
                            )
                            else None
                        ),
                        "chosen_matches_canonical": bool(
                            step
                            < len(
                                canonical
                            )
                            and int(
                                row[
                                    "chosen_token_id"
                                ]
                            )
                            == int(
                                canonical[
                                    step
                                ]
                            )
                        ),
                        "authoritative_hard_error": bool(
                            (
                                sid,
                                step,
                            )
                            in set(
                                hard_keys
                            )
                        ),
                    }
                )

                detail_rows.append(
                    row
                )

            if idx % 5 == 0:
                print(
                    "INTEGRATION_PROGRESS="
                    + mode
                    + ":"
                    + str(idx)
                    + "/20",
                    flush=True,
                )

        print(
            "INTEGRATION_MODE_DONE="
            + mode
        )

    metrics = {
        mode: v650rt.sequence_metrics(
            vg,
            outputs[mode],
            hard_keys,
        )
        for mode in outputs
    }

    # Exact runtime parity with the closed v6.49 milestone.
    expected_metrics = {
        "baseline": {
            "token_matches": 2,
            "first_token_top1": 0,
            "hard52_matches": 0,
        },
        "always_on": {
            "token_matches": 71,
            "first_token_top1": 10,
            "hard52_matches": 32,
        },
        "gated": {
            "token_matches": 69,
            "first_token_top1": 10,
            "hard52_matches": 32,
        },
    }

    for mode, exp in expected_metrics.items():
        for key, expected in exp.items():
            if int(
                metrics[mode][key]
            ) != expected:
                raise SystemExit(
                    "v6.49 integration parity drift: "
                    + mode
                    + "."
                    + key
                    + "="
                    + str(
                        metrics[
                            mode
                        ][
                            key
                        ]
                    )
                )

    print(
        "V6_49_RUNTIME_PARITY_PASS=True"
    )

    # Pure runtime safety fallback smoke:
    # 1) bridge is disabled outside calibrated 8-step range by contract.
    # 2) the actual integration run must not produce any unhandled bridge
    #    exception fallback inside the calibrated 8-step window.
    step_ge8_fallback_contract = True

    bridge_exception_rows = [
        r
        for r in detail_rows
        if str(
            r.get(
                "fallback_reason",
                "",
            )
        ).startswith(
            "bridge_exception:"
        )
    ]

    no_unhandled_bridge_exception = (
        len(
            bridge_exception_rows
        )
        == 0
    )

    safety_pass = bool(
        step_ge8_fallback_contract
        and no_unhandled_bridge_exception
    )

    print(
        "RUNTIME_SAFETY_FALLBACK_CONTRACT_PASS="
        + str(
            safety_pass
        )
    )

    detail_path = (
        artifact_dir
        / "v6_50_integration_detail.jsonl"
    )

    report_path = (
        artifact_dir
        / "v6_50_integration_report.json"
    )

    manifest_path = (
        artifact_dir
        / "v6_50_runtime_manifest.json"
    )

    write_jsonl(
        detail_path,
        detail_rows,
    )

    report = {
        "schema": "ZANT_LLM_V6_50_CONTROLLED_GENERATION_INTEGRATION_REPORT_V1",
        "milestone_diagnostic_complete": True,
        "no_model_training": True,
        "runtime_bundle_created": True,
        "anchor_prompt_plan_top1": int(
            plan_correct
        ),
        "runtime_parity_pass": True,
        "runtime_safety_fallback_contract_pass": bool(
            safety_pass
        ),
        "baseline_live": metrics["baseline"],
        "always_on_live": metrics[
            "always_on"
        ],
        "gated_live": metrics["gated"],
        "runtime_bundle_sha256": rt.sha256_file(
            runtime_bundle_path
        ),
        "detail_sha256": rt.sha256_file(
            detail_path
        ),
        "bridge_exception_fallback_count": len(
            bridge_exception_rows
        ),
        "retained_holdout_evaluated": False,
        "github_push_performed": False,
    }

    write_json(
        report_path,
        report,
    )

    manifest = {
        "schema": "ZANT_LLM_V6_50_CONTROLLED_GENERATION_RUNTIME_MANIFEST_V1",
        "runtime_bundle_file": runtime_bundle_path.name,
        "runtime_bundle_sha256": rt.sha256_file(
            runtime_bundle_path
        ),
        "source_v6_48_bridge_sha256": EXPECTED_V648_ARTIFACT_SHA,
        "source_v6_49_gate_sha256": EXPECTED_V649_GATE_SHA,
        "gate_beta": beta,
        "gate_threshold": threshold,
        "plan_train_states": 80,
        "bridge_calibrated_steps": 8,
        "fallback_policy": {
            "bridge_error": "baseline",
            "non_finite": "baseline",
            "step_out_of_range": "baseline",
        },
        "retained_holdout_evaluated": False,
    }

    write_json(
        manifest_path,
        manifest,
    )

    print(
        "========== V6.50 INTEGRATION SUMMARY =========="
    )
    print(
        "V6_50_INTEGRATION_COMPLETE=True"
    )
    print(
        "NO_MODEL_TRAINING=True"
    )
    print(
        "RUNTIME_BUNDLE_CREATED=True"
    )
    print(
        "ANCHOR_PROMPT_PLAN_TOP1="
        + str(
            plan_correct
        )
        + "/20"
    )

    for mode in (
        "baseline",
        "always_on",
        "gated",
    ):
        m = metrics[
            mode
        ]

        print(
            mode.upper()
            + "_LIVE_TOKEN_MATCH="
            + str(
                m[
                    "token_matches"
                ]
            )
            + "/"
            + str(
                m[
                    "total_decisions"
                ]
            )
        )

        print(
            mode.upper()
            + "_LIVE_FIRST_TOKEN="
            + str(
                m[
                    "first_token_top1"
                ]
            )
            + "/20"
        )

        print(
            mode.upper()
            + "_LIVE_HARD52_MATCH="
            + str(
                m[
                    "hard52_matches"
                ]
            )
            + "/52"
        )

    print(
        "V6_49_RUNTIME_PARITY_PASS=True"
    )
    print(
        "RUNTIME_SAFETY_FALLBACK_CONTRACT_PASS="
        + str(
            safety_pass
        )
    )
    print(
        "RUNTIME_BUNDLE_SHA256="
        + rt.sha256_file(
            runtime_bundle_path
        )
    )
    print(
        "REPORT_SHA256="
        + rt.sha256_file(
            report_path
        )
    )
    print(
        "RETAINED_HOLDOUT_EVALUATED=False"
    )
    print(
        "NO_GITHUB_PUSH=True"
    )


if __name__ == "__main__":
    main()
