Zant-LLM v6.49
Persistent Bridge Runtime Gate Calibration Milestone
====================================================

SOURCE v6.48
------------
v6.48 completed successfully:

  PERSISTENT TRAINING                     = True

  OPTIMIZER STEPS                         = 80
  BEST ROUND                              = 3

  BEST TEACHER TOP128                     = 150/160
  BEST FREE POOL4096                      = 43/52
  BEST FREE TOP128                        = 41/52

  GRADIENT REFINEMENT IMPROVED FREE TOP128 = True

Persistent bridge SHA256:

  0446fece29c00eacb74bd3cc037ac08911fb8df503c85f574e92bc07c55f0204

Final v6.48 status:

  PERSISTENT_BRIDGE_IS_USABLE_BUT_REQUIRES_RUNTIME_GATE_CALIBRATION

Selected v6.49 objective:

  BRIDGE_GATE_CALIBRATION
  + TEACHER_FREE_RUN_SAFETY_FLOOR
  + LIVE_GENERATION_AB


WHY v6.49 DOES NOT TRAIN AGAIN
------------------------------
v6.48 already created the persistent bridge.

The remaining question is now runtime translation:

  offline retrieval signal
          ->
  actual next-token control
          ->
  full live autoregressive generation

Therefore:

  NO_MODEL_TRAINING=True


THREE LIVE MODES
----------------
v6.49 runs three full 20-anchor generation conditions.

A. BASELINE

  frozen v6.31 controller only


B. ALWAYS-ON BRIDGE

  frozen v6.31 controller
  +
  persistent v6.48 bridge fusion at every step


C. GATED BRIDGE

  frozen v6.31 controller
  +
  persistent v6.48 bridge
  +
  calibrated runtime gate


RUNTIME FUSION
--------------
At every generation step the script computes:

  baseline controller logits

and:

  bridge query
    ->
  output-head bridge logits

Candidate set:

  baseline Top64
  union
  bridge Top64

Within the union both score families are z-normalized.

Fused score:

  baseline_z + beta * bridge_z

This avoids relying on incompatible raw logit scales.


GATE SIGNAL
-----------
For each step:

  baseline token
  fused candidate token
  fused candidate advantage

The bridge may override only when:

  fused candidate != baseline token

and:

  candidate advantage >= threshold


IMPORTANT CALIBRATION RULE
--------------------------
The gate threshold is NOT calibrated on the 52 free-run hard errors.

That would leak the live evaluation signal into threshold selection.

Instead the gate is calibrated only on the 160 teacher-forced anchor
development transitions.

Teacher safety floor:

  gated teacher Top1 >= baseline teacher Top1 - 1

The selected gate is then frozen before any live free-run A/B result is used.


GATE GRID
---------
beta:

  0.25
  0.50
  0.75
  1.00
  1.25

threshold:

  0.00
  0.10
  0.20
  0.35
  0.50
  0.75
  1.00
  1.50
  2.00


PROMPT PLAN
-----------
The existing 80-row train prompt states define the plan predictor.

Expected reproduction:

  ANCHOR_PROMPT_PLAN_TOP1 = 17/20


LIVE METRICS
------------
For BASELINE, ALWAYS-ON and GATED:

  token matches across all anchor generation positions

  first-token Top1

  exact sequence count

  authoritative 52-hard-error token matches

  hit max-new-token count


PRIMARY RUNTIME GAINS
---------------------
GATED_TOKEN_MATCH_GAIN_OVER_BASELINE

GATED_HARD52_GAIN_OVER_BASELINE

GATED_FIRST_TOKEN_CHANGE

GATED_LIVE_ACTIVATIONS

GATED_LIVE_OVERRIDE_PRECISION


AUTOMATIC v6.50 ROUTING
-----------------------
A. Strong gated live gain while preserving safety:

  token-match gain >= +8

  hard52 gain >= +5

  first-token change >= -1

  teacher calibration loss <= 1

Then:

  v6.50-persistent-bridge-controlled-generation-integration-milestone


B. Always-on is strong but gate loses most of the benefit:

  v6.50-runtime-gate-feature-and-threshold-redesign-milestone


C. Gated signal is positive but still below deployment threshold:

  v6.50-runtime-gate-and-logit-fusion-refinement-milestone


D. Weak live translation:

  v6.50-bridge-logit-fusion-and-runtime-confidence-redesign-milestone


E. Gate never activates:

  v6.50-free-run-gate-feature-redesign-milestone


F. Offline retrieval still does not translate to live control:

  v6.50-live-token-control-architecture-redesign-milestone


GOVERNANCE
----------
Retained holdout remains CLOSED.

No GitHub push.

v6.49 uses only the same 20-anchor development validation set.

No new persistent parameters are trained.


OUTPUT DIRECTORY
----------------
diagnostics\
v6_49_persistent_bridge_runtime_gate_calibration_milestone\

  v6_49_runtime_gate_config.json

  v6_49_gate_calibration_grid.json

  v6_49_live_generation_detail.jsonl

  v6_49_runtime_gate_report.json

  v6_49_milestone_analysis.json

  v6_49_milestone_summary.json


RUN
---
Extract into:

  C:\Users\Administrator\Desktop\Zant-LLM

Then run:

  powershell.exe -ExecutionPolicy Bypass -File "C:\Users\Administrator\Desktop\Zant-LLM\RUN_ZANT_V6_49_PERSISTENT_BRIDGE_RUNTIME_GATE_CALIBRATION_ONE_CLICK.ps1"
