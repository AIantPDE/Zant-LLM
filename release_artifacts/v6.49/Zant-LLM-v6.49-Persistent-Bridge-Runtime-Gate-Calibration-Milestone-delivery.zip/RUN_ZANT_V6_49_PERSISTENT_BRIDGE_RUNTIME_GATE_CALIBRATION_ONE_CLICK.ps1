$ErrorActionPreference = "Stop"

$ROOT = "C:\Users\Administrator\Desktop\Zant-LLM"
$PY = "C:\Users\Administrator\AppData\Local\Programs\Python\Python311\python.exe"
$BASE_MODEL = "E:\gemma-4-E2B-it"

$SOURCE_ADAPTER = Join-Path $ROOT "artifacts\Zant-LLM-v5_9_25-first-token-logit-margin-rank16-adapter"
$V67_PATCH = Join-Path $ROOT "artifacts\Zant-LLM-v6_7-reconstructed-canonical-target-alignment-pilot"
$RUNNER = Join-Path $ROOT "full_training\run_v6_49_persistent_bridge_runtime_gate_calibration_milestone.py"

$env:CUDA_LAUNCH_BLOCKING = "1"

Write-Host "========== ZANT-LLM v6.49 PERSISTENT BRIDGE RUNTIME GATE CALIBRATION =========="
Write-Host "NO_MODEL_TRAINING=True"
Write-Host "SOURCE_V6_48_COMPLETE=True"
Write-Host "SOURCE_BEST_TEACHER_TOP128=150/160"
Write-Host "SOURCE_BEST_FREE_TOP128=41/52"
Write-Host "SOURCE_BEST_FREE_POOL4096=43/52"
Write-Host "OBJECTIVE=BRIDGE_GATE_CALIBRATION+TEACHER_FREE_RUN_SAFETY_FLOOR+LIVE_GENERATION_AB"
Write-Host "GATE_CALIBRATION_USES_TEACHER_CONTEXT_ONLY=True"
Write-Host "LIVE_FREE_RUN_NOT_USED_FOR_THRESHOLD_SELECTION=True"
Write-Host "CUDA_LAUNCH_BLOCKING=1"
Write-Host "RETAINED_HOLDOUT_EVALUATED=False"
Write-Host "NO_GITHUB_PUSH=True"

if (!(Test-Path $PY)) { throw "Python not found: $PY" }
if (!(Test-Path $RUNNER)) { throw "v6.49 runner not found: $RUNNER" }
if (!(Test-Path $BASE_MODEL)) { throw "Base model not found: $BASE_MODEL" }
if (!(Test-Path $SOURCE_ADAPTER)) { throw "Source adapter not found: $SOURCE_ADAPTER" }
if (!(Test-Path $V67_PATCH)) { throw "v6.7 patch not found: $V67_PATCH" }

& $PY $RUNNER `
  --root $ROOT `
  --base-model $BASE_MODEL `
  --source-adapter $SOURCE_ADAPTER `
  --v67-patch $V67_PATCH

$exit = $LASTEXITCODE

Write-Host ("V6_49_PROCESS_EXIT=" + $exit)

if ($exit -ne 0) {
    throw "v6.49 milestone failed (exit=$exit)"
}

Write-Host "========== v6.49 ONE-CLICK DONE =========="
