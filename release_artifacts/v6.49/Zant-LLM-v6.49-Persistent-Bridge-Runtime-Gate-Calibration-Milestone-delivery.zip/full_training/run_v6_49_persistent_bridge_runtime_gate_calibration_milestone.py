from pathlib import Path
import argparse
import subprocess
import sys


def run(cmd):
    print(
        "RUN="
        + " ".join(
            str(
                x
            )
            for x in cmd
        ),
        flush=True,
    )

    p = subprocess.run(
        cmd
    )

    if p.returncode != 0:
        raise SystemExit(
            p.returncode
        )


def main():
    ap = argparse.ArgumentParser()

    ap.add_argument(
        "--root",
        required=True,
    )
    ap.add_argument(
        "--base-model",
        required=True,
    )
    ap.add_argument(
        "--source-adapter",
        required=True,
    )
    ap.add_argument(
        "--v67-patch",
        required=True,
    )

    args = ap.parse_args()

    root = Path(
        args.root
    )

    py = sys.executable

    internal = (
        root
        / "full_training"
        / "v6_49_internal"
    )

    runtime = (
        root
        / "full_training"
        / "v6_36_internal"
        / "runtime_v6_36.py"
    )

    v624_script = (
        root
        / "full_training"
        / "v6_36_internal"
        / "controller_v6_24_frozen.py"
    )

    joint_script = (
        root
        / "full_training"
        / "v6_36_internal"
        / "controller_v6_29_joint.py"
    )

    outdir = (
        root
        / "diagnostics"
        / "v6_49_persistent_bridge_runtime_gate_calibration_milestone"
    )

    report = (
        outdir
        / "v6_49_runtime_gate_report.json"
    )

    print(
        "========== ZANT-LLM v6.49 PERSISTENT BRIDGE RUNTIME GATE CALIBRATION =========="
    )
    print(
        "NO_MODEL_TRAINING=True"
    )
    print(
        "SOURCE_V6_48_COMPLETE=True"
    )
    print(
        "SOURCE_BEST_TEACHER_TOP128=150/160"
    )
    print(
        "SOURCE_BEST_FREE_TOP128=41/52"
    )
    print(
        "SOURCE_BEST_FREE_POOL4096=43/52"
    )
    print(
        "OBJECTIVE=BRIDGE_GATE_CALIBRATION+TEACHER_FREE_RUN_SAFETY_FLOOR+LIVE_GENERATION_AB"
    )
    print(
        "GATE_CALIBRATION_USES_TEACHER_CONTEXT_ONLY=True"
    )
    print(
        "LIVE_FREE_RUN_NOT_USED_FOR_THRESHOLD_SELECTION=True"
    )
    print(
        "RETAINED_HOLDOUT_EVALUATED=False"
    )
    print(
        "NO_GITHUB_PUSH=True"
    )

    for p in (
        runtime,
        v624_script,
        joint_script,
    ):
        if not p.exists():
            raise SystemExit(
                "Missing prerequisite: "
                + str(
                    p
                )
            )

    run(
        [
            py,
            str(
                internal
                / "calibrate_v6_49_runtime_gate.py"
            ),
            "--root",
            str(
                root
            ),
            "--base-model",
            args.base_model,
            "--source-adapter",
            args.source_adapter,
            "--v67-patch",
            args.v67_patch,
            "--runtime-script",
            str(
                runtime
            ),
            "--v624-controller-script",
            str(
                v624_script
            ),
            "--joint-controller-script",
            str(
                joint_script
            ),
            "--diagnostics-dir",
            str(
                outdir
            ),
        ]
    )

    run(
        [
            py,
            str(
                internal
                / "route_v6_49.py"
            ),
            "--report",
            str(
                report
            ),
            "--runtime-script",
            str(
                runtime
            ),
            "--diagnostics-dir",
            str(
                outdir
            ),
        ]
    )

    print(
        "V6_49_PROCESS_EXIT=0"
    )
    print(
        "========== v6.49 ONE-CLICK DONE =========="
    )


if __name__ == "__main__":
    main()
