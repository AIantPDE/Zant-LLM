from pathlib import Path
import argparse
import importlib.util


def load_module(path, name):
    spec = importlib.util.spec_from_file_location(
        name,
        str(path),
    )
    mod = importlib.util.module_from_spec(
        spec
    )
    spec.loader.exec_module(
        mod
    )
    return mod


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument(
        "--report",
        required=True,
    )
    ap.add_argument(
        "--runtime-script",
        required=True,
    )
    ap.add_argument(
        "--diagnostics-dir",
        required=True,
    )
    a = ap.parse_args()

    rt = load_module(
        a.runtime_script,
        "v649_route_runtime",
    )

    r = rt.read_json(
        Path(
            a.report
        )
    )

    outdir = Path(
        a.diagnostics_dir
    )

    if r.get(
        "milestone_diagnostic_complete"
    ) is not True:
        raise SystemExit(
            "v6.49 diagnostic incomplete"
        )

    if r.get(
        "no_model_training"
    ) is not True:
        raise SystemExit(
            "v6.49 unexpectedly trained a model"
        )

    plan = int(
        r[
            "anchor_prompt_plan_top1"
        ]
    )

    teacher_change = int(
        r[
            "gate_teacher_top1_change"
        ]
    )

    baseline = r[
        "baseline_live"
    ]

    always = r[
        "always_on_live"
    ]

    gated = r[
        "gated_live"
    ]

    token_gain = int(
        r[
            "gated_token_match_gain_over_baseline"
        ]
    )

    hard_gain = int(
        r[
            "gated_hard52_gain_over_baseline"
        ]
    )

    first_change = int(
        r[
            "gated_first_token_change"
        ]
    )

    always_gain = int(
        r[
            "always_on_token_match_gain_over_baseline"
        ]
    )

    always_hard_gain = int(
        r[
            "always_on_hard52_gain_over_baseline"
        ]
    )

    gated_activations = int(
        r[
            "gated_live_activations"
        ]
    )

    if plan < 16:
        status = "PROMPT_PLAN_SIGNAL_IS_TOO_WEAK_FOR_RUNTIME_BRIDGE_DEPLOYMENT"
        nxt = "v6.50-prompt-plan-runtime-reliability-redesign-milestone"
        obj = "PROMPT_PLAN_CONFIDENCE+RUNTIME_FALLBACK+BRIDGE_GATING"

    elif (
        teacher_change >= -1
        and token_gain >= 8
        and hard_gain >= 5
        and first_change >= -1
        and gated[
            "hit_max_new_tokens"
        ]
        <= baseline[
            "hit_max_new_tokens"
        ]
        + 2
    ):
        status = "CALIBRATED_RUNTIME_GATE_TRANSLATES_PERSISTENT_BRIDGE_SIGNAL_INTO_LIVE_GENERATION"
        nxt = "v6.50-persistent-bridge-controlled-generation-integration-milestone"
        obj = "LIVE_GATED_BRIDGE_CONTROLLER_COEXECUTION+SEQUENCE_METRICS+RUNTIME_SAFETY_FALLBACK+INFERENCE_PACKAGE"

    elif (
        always_gain >= 8
        and always_hard_gain >= 5
        and token_gain < always_gain - 4
    ):
        status = "PERSISTENT_BRIDGE_HAS_LIVE_SIGNAL_BUT_CURRENT_GATE_IS_TOO_CONSERVATIVE"
        nxt = "v6.50-runtime-gate-feature-and-threshold-redesign-milestone"
        obj = "FREE_RUN_GATE_FEATURES+BRIDGE_ADVANTAGE_CALIBRATION+PLAN_CONFIDENCE+LIVE_AB"

    elif (
        token_gain >= 4
        and hard_gain >= 2
        and first_change >= -1
    ):
        status = "RUNTIME_GATE_PROVIDES_POSITIVE_LIVE_SIGNAL_BUT_IS_BELOW_DEPLOYMENT_THRESHOLD"
        nxt = "v6.50-runtime-gate-and-logit-fusion-refinement-milestone"
        obj = "GATE_CALIBRATION+LOGIT_FUSION+PREFIX_ERROR_FEATURES+LIVE_GENERATION_AB"

    elif (
        always_gain > 0
        or always_hard_gain > 0
    ):
        status = "BRIDGE_SIGNAL_TRANSLATES_WEAKLY_TO_LIVE_GENERATION_AND_NEEDS_LOGIT_FUSION_REDESIGN"
        nxt = "v6.50-bridge-logit-fusion-and-runtime-confidence-redesign-milestone"
        obj = "BRIDGE_BASELINE_LOGIT_FUSION+CONFIDENCE_NORMALIZATION+DOMAIN_AWARE_GATE"

    elif gated_activations == 0:
        status = "TEACHER_CALIBRATED_GATE_NEVER_ACTIVATES_IN_LIVE_FREE_RUN"
        nxt = "v6.50-free-run-gate-feature-redesign-milestone"
        obj = "FREE_RUN_DOMAIN_GATE+PLAN_CONFIDENCE+PREFIX_DIVERGENCE_FEATURES+BRIDGE_ADVANTAGE"

    else:
        status = "OFFLINE_RETRIEVAL_SIGNAL_DOES_NOT_YET_TRANSLATE_TO_LIVE_TOKEN_CONTROL"
        nxt = "v6.50-live-token-control-architecture-redesign-milestone"
        obj = "PERSISTENT_BRIDGE_AS_CONTROL_FEATURE+BASELINE_LOGIT_COMPATIBILITY+RUNTIME_RERANKER"

    analysis = {
        "schema": "ZANT_LLM_V6_49_MILESTONE_ANALYSIS_V1",
        "anchor_prompt_plan_top1": plan,
        "teacher_gate_top1_change": teacher_change,
        "baseline_live": baseline,
        "always_on_live": always,
        "gated_live": gated,
        "gated_live_activations": gated_activations,
        "gated_token_match_gain_over_baseline": token_gain,
        "gated_hard52_gain_over_baseline": hard_gain,
        "gated_first_token_change": first_change,
        "always_on_token_match_gain_over_baseline": always_gain,
        "always_on_hard52_gain_over_baseline": always_hard_gain,
        "classification": status,
        "training_authorized": False,
        "retained_holdout_opened": False,
        "selected_v6_50_objective": obj,
        "next_milestone": nxt,
    }

    analysis_path = (
        outdir
        / "v6_49_milestone_analysis.json"
    )

    rt.write_json(
        analysis_path,
        analysis,
    )

    summary = {
        "schema": "ZANT_LLM_V6_49_PERSISTENT_BRIDGE_RUNTIME_GATE_CALIBRATION_MILESTONE_V1",
        "milestone_complete": True,
        "no_model_training": True,
        "anchor_prompt_plan_top1": plan,
        "teacher_gate_top1_change": teacher_change,
        "baseline_live_token_matches": int(
            baseline[
                "token_matches"
            ]
        ),
        "baseline_live_first_token_top1": int(
            baseline[
                "first_token_top1"
            ]
        ),
        "baseline_live_hard52_matches": int(
            baseline[
                "hard52_matches"
            ]
        ),
        "always_on_live_token_matches": int(
            always[
                "token_matches"
            ]
        ),
        "always_on_live_first_token_top1": int(
            always[
                "first_token_top1"
            ]
        ),
        "always_on_live_hard52_matches": int(
            always[
                "hard52_matches"
            ]
        ),
        "gated_live_token_matches": int(
            gated[
                "token_matches"
            ]
        ),
        "gated_live_first_token_top1": int(
            gated[
                "first_token_top1"
            ]
        ),
        "gated_live_hard52_matches": int(
            gated[
                "hard52_matches"
            ]
        ),
        "gated_live_activations": gated_activations,
        "gated_token_match_gain_over_baseline": token_gain,
        "gated_hard52_gain_over_baseline": hard_gain,
        "gated_first_token_change": first_change,
        "always_on_token_match_gain_over_baseline": always_gain,
        "always_on_hard52_gain_over_baseline": always_hard_gain,
        "training_authorized": False,
        "retained_holdout_opened": False,
        "milestone_status": status,
        "selected_v6_50_objective": obj,
        "next_milestone": nxt,
        "github_push_performed": False,
    }

    summary_path = (
        outdir
        / "v6_49_milestone_summary.json"
    )

    rt.write_json(
        summary_path,
        summary,
    )

    print(
        "========== V6.49 MILESTONE FINAL =========="
    )
    print(
        "V6_49_MILESTONE_COMPLETE=True"
    )
    print(
        "NO_MODEL_TRAINING=True"
    )
    print(
        "BASELINE_LIVE_TOKEN_MATCH="
        + str(
            baseline[
                "token_matches"
            ]
        )
        + "/"
        + str(
            baseline[
                "total_decisions"
            ]
        )
    )
    print(
        "ALWAYS_ON_LIVE_TOKEN_MATCH="
        + str(
            always[
                "token_matches"
            ]
        )
        + "/"
        + str(
            always[
                "total_decisions"
            ]
        )
    )
    print(
        "GATED_LIVE_TOKEN_MATCH="
        + str(
            gated[
                "token_matches"
            ]
        )
        + "/"
        + str(
            gated[
                "total_decisions"
            ]
        )
    )
    print(
        "BASELINE_LIVE_FIRST_TOKEN="
        + str(
            baseline[
                "first_token_top1"
            ]
        )
        + "/20"
    )
    print(
        "GATED_LIVE_FIRST_TOKEN="
        + str(
            gated[
                "first_token_top1"
            ]
        )
        + "/20"
    )
    print(
        "BASELINE_LIVE_HARD52_MATCH="
        + str(
            baseline[
                "hard52_matches"
            ]
        )
        + "/52"
    )
    print(
        "GATED_LIVE_HARD52_MATCH="
        + str(
            gated[
                "hard52_matches"
            ]
        )
        + "/52"
    )
    print(
        "GATED_LIVE_ACTIVATIONS="
        + str(
            gated_activations
        )
        + "/160"
    )
    print(
        "GATED_TOKEN_MATCH_GAIN_OVER_BASELINE="
        + str(
            token_gain
        )
    )
    print(
        "GATED_HARD52_GAIN_OVER_BASELINE="
        + str(
            hard_gain
        )
    )
    print(
        "GATED_FIRST_TOKEN_CHANGE="
        + str(
            first_change
        )
    )
    print(
        "TRAINING_AUTHORIZED=False"
    )
    print(
        "RETAINED_HOLDOUT_OPENED=False"
    )
    print(
        "MILESTONE_STATUS="
        + status
    )
    print(
        "SELECTED_V6_50_OBJECTIVE="
        + obj
    )
    print(
        "ANALYSIS_SHA256="
        + rt.sha256_file(
            analysis_path
        )
    )
    print(
        "FINAL_SUMMARY_SHA256="
        + rt.sha256_file(
            summary_path
        )
    )
    print(
        "NEXT_MILESTONE="
        + nxt
    )
    print(
        "GITHUB_PUSH_PERFORMED=False"
    )


if __name__ == "__main__":
    main()
