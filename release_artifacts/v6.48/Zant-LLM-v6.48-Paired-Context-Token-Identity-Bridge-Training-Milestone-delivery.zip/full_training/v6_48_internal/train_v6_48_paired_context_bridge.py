from pathlib import Path
import argparse
import importlib.util
import json
import math
import gc
import copy
import random
from collections import defaultdict

EXPECTED_V647_DETAIL_SHA = "527ec48dd45ce652921d57466623c4f6725e67cd39c13b6e0ba76d4d9794a1a6"
EXPECTED_V647_REPORT_SHA = "d91ca719cb23ab0a123a83da4992d18fa7a73095fbd815213c53eea13e811283"
EXPECTED_V647_ANALYSIS_SHA = "92e90398073263f174333982a98d4e64c6073b0849878b4ffe76de49a5792384"
EXPECTED_V647_SUMMARY_SHA = "8a6b7c22e94bd59de62a889205881a856c631ece75b3b40817f83f8455f44624"

EXPECTED_V646_TRANSITION_SHA = "82d59f867b4b7e13d1f5bd1f4c110ff1a2451481c8b2ec406a74dbd13ba0a98a"
EXPECTED_V646_NEGATIVE_SHA = "6843e8288fa2815f4cbf2fc4ca3c9ce09638a406da3edf88dcda9be81102c871"
EXPECTED_V646_HIDDEN_SHA = "9e0fa760f66ef9ff8d801340f61d3bfee443915005e0cf0c12fd90f4f674b36a"
EXPECTED_V646_SUMMARY_SHA = "6d8284df4111b0f43afd636c3afff58070052a9207a8c45c02e8f13987325136"

EXPECTED_V630_DETAIL_SHA = "09892653c8b5218400aa6b60dea28754aadd93c3d3d3693e7248ef21d34e547e"
EXPECTED_V616_ROUTER_SHA = "cbe5ea6d5f4fba5f3f84c0b9ac84626204d17b2473e5d3e92b34faca1823a735"
EXPECTED_V616_FOLDER_SHA = "ccbc1e2eb1473eb33d1b31ec10c7a3c0832f6aeb2a1c7ec5b9d8c8df69397ebb"
EXPECTED_V621_BANK_SHA = "d5c660905175a13e15d4c376065de9e0ba873951c2584c290422afc5c5b25b1f"
EXPECTED_V624_CONTROLLER_SHA = "4bb2c20ff2b78c849f2ea6e1b7e890623683ea2c47a73b9a74be8f551df95c2c"
EXPECTED_V624_FOLDER_SHA = "8730612769ae2e34ebd82e5eeb71c244fed6a979589dc2ad697f417b0db4f090"
EXPECTED_V631_CONTROLLER_SHA = "45b5b5f8855cdbcdfa48f867da692994db1a244d0a6d5c06c9ede9020ba01cb2"
EXPECTED_V631_FOLDER_SHA = "8704684b56c0b79ebdfcb0be8f66952672f3594230d5adb75b41f3cb5ba1a144"

MAX_NEW_TOKENS = 8
PLAN_K = 4
PROJ_DIM = 96
RIDGE = 0.12
IDENTITY_NEG_WEIGHT = 0.24
RESIDUAL_CLIP = 1.10
POOL_K = 4096
TOP128 = 128
VOCAB_CHUNK = 4096

EPOCHS = 4
BATCH_SIZE = 64
LEARNING_RATE = 2.0e-4
WEIGHT_DECAY = 1.0e-4
HARD_NEG_MARGIN = 0.06
MSE_WEIGHT = 0.45
POS_COS_WEIGHT = 0.40
HARD_NEG_WEIGHT = 0.15
GRAD_CLIP = 1.0

FEATURE_WEIGHTS = {
    "current": 0.40,
    "prompt": 0.18,
    "prev1": 0.18,
    "prev2": 0.08,
    "plan": 0.10,
    "step": 0.06,
}

HARD_CATEGORIES = {
    "JOINT_OUTPUT_ALREADY_TOP10_BUT_NOT_TOP1",
    "STATE_HEAD_RECOVERS_CONTROL_REGION_BUT_FINAL_POLICY_MISSES",
    "CURRENT_PREFIX_STATE_IS_CONTROLLABLE_BUT_JOINT_POLICY_MISSES",
}


def load_module(path, name):
    spec = importlib.util.spec_from_file_location(name, str(path))
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def read_jsonl(path):
    rows = []
    with Path(path).open("r", encoding="utf-8") as f:
        for line in f:
            if line.strip():
                rows.append(json.loads(line))
    return rows


def write_json(path, obj):
    Path(path).write_text(
        json.dumps(obj, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
        newline="\n",
    )


def write_jsonl(path, rows):
    with Path(path).open("w", encoding="utf-8", newline="\n") as f:
        for row in rows:
            f.write(json.dumps(row, ensure_ascii=False, separators=(",", ":")) + "\n")


def unit(torch, x):
    x = x.float()
    return x / x.norm().clamp_min(1e-8)


def prompt_ids(tok, prompt):
    try:
        text = tok.apply_chat_template(
            [{"role": "user", "content": prompt}],
            tokenize=False,
            add_generation_prompt=True,
        )
        return tok(text, add_special_tokens=False).input_ids
    except Exception:
        return tok(
            "User: " + prompt + "\nAssistant: ",
            add_special_tokens=False,
        ).input_ids


def capture_states(torch, model, rt, requests):
    final_norm, _ = rt.find_final_norm(model)
    cap = {"h": None}

    def hook(module, args, out):
        cap["h"] = rt.extract_hidden(out)

    handle = final_norm.register_forward_hook(hook)
    result = {}
    total = len(requests)

    try:
        with torch.no_grad():
            for idx, (key, ids) in enumerate(requests, 1):
                xin = None
                mask = None
                model_out = None
                hcpu = None

                try:
                    xin = torch.tensor([ids], dtype=torch.long, device="cuda:0")
                    mask = torch.ones_like(xin)
                    cap["h"] = None

                    model_out = model(
                        input_ids=xin,
                        attention_mask=mask,
                        use_cache=False,
                    )

                    torch.cuda.synchronize()

                    if cap["h"] is None:
                        raise RuntimeError("final-norm hook returned no hidden state")

                    hcpu = cap["h"][0, -1, :].detach().to(
                        device="cpu",
                        dtype=torch.float32,
                        copy=True,
                    )

                    result[key] = hcpu

                except Exception as e:
                    print(
                        "STATE_CAPTURE_FAILED_AT=%d/%d KEY=%r INPUT_LEN=%d ERROR=%s"
                        % (idx, total, key, len(ids), repr(e)),
                        flush=True,
                    )
                    raise

                finally:
                    cap["h"] = None

                    if model_out is not None:
                        del model_out
                    if xin is not None:
                        del xin
                    if mask is not None:
                        del mask
                    if hcpu is not None:
                        del hcpu

                if idx % 25 == 0:
                    torch.cuda.synchronize()
                    gc.collect()
                    torch.cuda.empty_cache()
                    free_b, total_b = torch.cuda.mem_get_info()

                    print(
                        "STATE_CAPTURE_PROGRESS=%d/%d CUDA_FREE_GB=%.3f CUDA_TOTAL_GB=%.3f"
                        % (
                            idx,
                            total,
                            free_b / (1024 ** 3),
                            total_b / (1024 ** 3),
                        ),
                        flush=True,
                    )
    finally:
        handle.remove()
        cap["h"] = None
        gc.collect()

        if torch.cuda.is_available():
            torch.cuda.empty_cache()
            torch.cuda.synchronize()

    return result


def make_projection(torch, hidden, dim):
    g = torch.Generator(device="cpu")
    g.manual_seed(645045)

    P = torch.randn(
        hidden,
        dim,
        generator=g,
        dtype=torch.float32,
    )

    return P / math.sqrt(float(hidden))


def proj(torch, x, P):
    if x is None:
        return torch.zeros(P.shape[1], dtype=torch.float32)

    return unit(
        torch,
        unit(torch, x) @ P,
    )


def feature(torch, current, prompt, prev1, prev2, plan, step, P):
    p = torch.zeros(PLAN_K, dtype=torch.float32)
    p[max(0, min(PLAN_K - 1, int(plan)))] = 1.0

    s = torch.zeros(8, dtype=torch.float32)
    s[max(0, min(7, int(step)))] = 1.0

    core = torch.cat(
        [
            math.sqrt(FEATURE_WEIGHTS["current"]) * proj(torch, current, P),
            math.sqrt(FEATURE_WEIGHTS["prompt"]) * proj(torch, prompt, P),
            math.sqrt(FEATURE_WEIGHTS["prev1"]) * proj(torch, prev1, P),
            math.sqrt(FEATURE_WEIGHTS["prev2"]) * proj(torch, prev2, P),
            math.sqrt(FEATURE_WEIGHTS["plan"]) * p,
            math.sqrt(FEATURE_WEIGHTS["step"]) * s,
        ]
    )

    core = unit(torch, core)

    return torch.cat(
        [
            core,
            torch.ones(1, dtype=torch.float32),
        ]
    )


def weighted_ridge(torch, X, Y, weights):
    w = torch.sqrt(
        weights.float().clamp_min(1e-4)
    ).unsqueeze(1)

    Xw = X * w
    Yw = Y * w

    I = torch.eye(
        X.shape[1],
        dtype=torch.float32,
    )
    I[-1, -1] = 0.0

    return torch.linalg.solve(
        Xw.T @ Xw + RIDGE * I,
        Xw.T @ Yw,
    )


def plan_knn(torch, train_states, train_labels, test_state):
    X = torch.stack(
        [
            unit(torch, x)
            for x in train_states
        ]
    )

    q = unit(torch, test_state)
    sims = X @ q

    k = min(9, len(train_labels))

    vals, idx = torch.topk(
        sims,
        k=k,
    )

    weights = torch.softmax(
        vals / 0.10,
        dim=0,
    )

    scores = torch.zeros(
        PLAN_K,
        dtype=torch.float32,
    )

    for pos, j in enumerate(idx.tolist()):
        scores[int(train_labels[j])] += float(weights[pos])

    return int(torch.argmax(scores).item())


def bridge_query(torch, x, base, weight):
    residual = x @ weight.T
    n = float(residual.norm())

    if n > RESIDUAL_CLIP:
        residual = residual * (
            RESIDUAL_CLIP / n
        )

    return unit(
        torch,
        unit(torch, base) + residual,
    )


def vocab_topk(torch, model, queries, k):
    head = model.get_output_embeddings()
    W = head.weight
    device = W.device

    out = []
    batch = 64

    for b0 in range(0, len(queries), batch):
        Q = torch.stack(
            [
                unit(torch, q)
                for q in queries[b0:b0 + batch]
            ]
        ).to(
            device=device,
            dtype=torch.float32,
        )

        best_s = torch.full(
            (Q.shape[0], k),
            -1e9,
            dtype=torch.float32,
            device=device,
        )

        best_i = torch.full(
            (Q.shape[0], k),
            -1,
            dtype=torch.long,
            device=device,
        )

        with torch.no_grad():
            for start in range(0, W.shape[0], VOCAB_CHUNK):
                stop = min(
                    W.shape[0],
                    start + VOCAB_CHUNK,
                )

                w = W[start:stop].float()
                wn = w / w.norm(
                    dim=1,
                    keepdim=True,
                ).clamp_min(1e-8)

                sc = Q @ wn.T

                ids = torch.arange(
                    start,
                    stop,
                    device=device,
                    dtype=torch.long,
                ).unsqueeze(0).expand(
                    Q.shape[0],
                    -1,
                )

                all_s = torch.cat(
                    [best_s, sc],
                    dim=1,
                )
                all_i = torch.cat(
                    [best_i, ids],
                    dim=1,
                )

                vals, ix = torch.topk(
                    all_s,
                    k=k,
                    dim=1,
                )

                best_s = vals
                best_i = torch.gather(
                    all_i,
                    1,
                    ix,
                )

        out.extend(
            [
                [int(x) for x in row]
                for row in best_i.cpu().tolist()
            ]
        )

    return out


def eval_weight(
    torch,
    model,
    weight,
    teacher_eval,
    free_eval,
):
    teacher_queries = [
        bridge_query(
            torch,
            e["x"],
            e["base"],
            weight,
        )
        for e in teacher_eval
    ]

    free_queries = [
        bridge_query(
            torch,
            e["x"],
            e["base"],
            weight,
        )
        for e in free_eval
    ]

    retrieved = vocab_topk(
        torch,
        model,
        teacher_queries + free_queries,
        POOL_K,
    )

    teacher_pool = 0
    teacher_top128 = 0
    free_pool = 0
    free_top128 = 0

    detail = []

    for i, e in enumerate(teacher_eval):
        ids = retrieved[i]
        target = int(e["target"])

        p = target in ids
        t = target in ids[:TOP128]

        teacher_pool += int(p)
        teacher_top128 += int(t)

        detail.append(
            {
                "id": e["id"],
                "step": int(e["step"]),
                "domain": "teacher",
                "canonical_token_id": target,
                "pool4096_hit": bool(p),
                "top128_hit": bool(t),
            }
        )

    off = len(teacher_eval)

    for i, e in enumerate(free_eval):
        ids = retrieved[off + i]
        target = int(e["target"])

        p = target in ids
        t = target in ids[:TOP128]

        free_pool += int(p)
        free_top128 += int(t)

        detail.append(
            {
                "id": e["id"],
                "step": int(e["step"]),
                "domain": "free_run",
                "canonical_token_id": target,
                "pool4096_hit": bool(p),
                "top128_hit": bool(t),
            }
        )

    return {
        "teacher_pool4096": int(teacher_pool),
        "teacher_top128": int(teacher_top128),
        "free_pool4096": int(free_pool),
        "free_top128": int(free_top128),
        "detail": detail,
    }


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", required=True)
    ap.add_argument("--base-model", required=True)
    ap.add_argument("--source-adapter", required=True)
    ap.add_argument("--v67-patch", required=True)
    ap.add_argument("--runtime-script", required=True)
    ap.add_argument("--v624-controller-script", required=True)
    ap.add_argument("--joint-controller-script", required=True)
    ap.add_argument("--artifact-dir", required=True)
    a = ap.parse_args()

    root = Path(a.root)
    artifact_dir = Path(a.artifact_dir)
    artifact_dir.mkdir(parents=True, exist_ok=True)

    rt = load_module(
        a.runtime_script,
        "v648_runtime",
    )
    v624mod = load_module(
        a.v624_controller_script,
        "v648_v624",
    )
    jointmod = load_module(
        a.joint_controller_script,
        "v648_joint",
    )

    d44 = (
        root
        / "full_training"
        / "v6_44_dedicated_transition_supervision_dataset"
    )
    ptrain = d44 / "v6_44_dedicated_train_transitions.jsonl"
    pval = d44 / "v6_44_anchor_validation_transitions_DO_NOT_TRAIN.jsonl"
    pneg = d44 / "v6_44_plan_step_hard_negative_pairs.jsonl"

    d46 = (
        root
        / "full_training"
        / "v6_46_free_run_transition_context_dataset"
    )
    p46trans = d46 / "v6_46_on_policy_free_run_transitions.jsonl"
    p46neg = d46 / "v6_46_on_policy_hard_negative_pairs.jsonl"
    p46hidden = d46 / "v6_46_on_policy_context_hidden_states.pt"
    p46summary = d46 / "v6_46_milestone_summary.json"

    d47 = (
        root
        / "diagnostics"
        / "v6_47_paired_teacher_free_run_retrieval_readiness_diagnostic_milestone"
    )
    p47detail = d47 / "v6_47_paired_retrieval_detail.jsonl"
    p47report = d47 / "v6_47_paired_retrieval_report.json"
    p47analysis = d47 / "v6_47_milestone_analysis.json"
    p47summary = d47 / "v6_47_milestone_summary.json"

    d30 = (
        root
        / "diagnostics"
        / "v6_30_post_joint_training_error_transition_analysis_milestone"
        / "v6_30_post_joint_error_transition_detail.jsonl"
    )

    required = (
        ptrain,
        pval,
        pneg,
        p46trans,
        p46neg,
        p46hidden,
        p46summary,
        p47detail,
        p47report,
        p47analysis,
        p47summary,
        d30,
    )

    for p in required:
        if not p.exists():
            raise SystemExit(
                "Missing prerequisite: "
                + str(p)
            )

    lineage = (
        (p47detail, EXPECTED_V647_DETAIL_SHA, "v6.47 detail"),
        (p47report, EXPECTED_V647_REPORT_SHA, "v6.47 report"),
        (p47analysis, EXPECTED_V647_ANALYSIS_SHA, "v6.47 analysis"),
        (p47summary, EXPECTED_V647_SUMMARY_SHA, "v6.47 summary"),
        (p46trans, EXPECTED_V646_TRANSITION_SHA, "v6.46 transitions"),
        (p46neg, EXPECTED_V646_NEGATIVE_SHA, "v6.46 negatives"),
        (p46hidden, EXPECTED_V646_HIDDEN_SHA, "v6.46 hidden"),
        (p46summary, EXPECTED_V646_SUMMARY_SHA, "v6.46 summary"),
        (d30, EXPECTED_V630_DETAIL_SHA, "v6.30 detail"),
    )

    for p, expected, label in lineage:
        got = rt.sha256_file(p)

        if got != expected:
            raise SystemExit(
                label
                + " SHA mismatch: "
                + got
            )

    s47 = rt.read_json(p47summary)

    expected47 = {
        "milestone_complete": True,
        "no_persistent_training": True,
        "anchor_prompt_plan_top1": 17,
        "teacher_only_teacher_top128": 151,
        "on_policy_only_teacher_top128": 122,
        "paired_teacher_top128": 149,
        "teacher_only_free_top128": 17,
        "on_policy_only_free_top128": 40,
        "paired_free_pool4096": 42,
        "paired_free_top128": 40,
        "paired_free_top128_gain_over_teacher_only": 23,
        "paired_teacher_top128_change_from_teacher_only": -2,
        "training_authorized": True,
        "retained_holdout_opened": False,
        "milestone_status": "PAIRED_TEACHER_FREE_RUN_CONTEXT_CLOSES_ENOUGH_DOMAIN_GAP_FOR_PERSISTENT_TRAINING",
        "selected_v6_48_objective": "PERSISTENT_PAIRED_CONTEXT_TOKEN_IDENTITY_BRIDGE+PLAN_STEP_BALANCING+HARD_NEGATIVE_LOSS+DOMAIN_MIXING",
        "next_milestone": "v6.48-paired-context-token-identity-bridge-training-milestone",
    }

    for key, expected in expected47.items():
        if s47.get(key) != expected:
            raise SystemExit(
                "v6.47 summary mismatch: "
                + key
                + "="
                + repr(
                    s47.get(key)
                )
            )

    print(
        "========== ZANT-LLM v6.48 PERSISTENT PAIRED-CONTEXT TOKEN-IDENTITY BRIDGE TRAINING =========="
    )
    print("PERSISTENT_TRAINING=True")
    print("SOURCE_V6_47_COMPLETE=True")
    print("SOURCE_PAIRED_TEACHER_TOP128=149/160")
    print("SOURCE_PAIRED_FREE_TOP128=40/52")
    print("SOURCE_PAIRED_FREE_POOL4096=42/52")
    print(
        "OBJECTIVE=PERSISTENT_PAIRED_CONTEXT_TOKEN_IDENTITY_BRIDGE+PLAN_STEP_BALANCING+HARD_NEGATIVE_LOSS+DOMAIN_MIXING"
    )
    print("ROUND0=AUTHORITATIVE_PAIRED_RIDGE_INITIALIZATION")
    print("TRAIN_DOMAINS=TEACHER+ON_POLICY_FREE_RUN_1_TO_1")
    print("ANCHOR_VALIDATION_DO_NOT_TRAIN=True")
    print("RETAINED_HOLDOUT_EVALUATED=False")
    print("NO_GITHUB_PUSH=True")

    import torch
    import torch.nn as nn
    import torch.nn.functional as F
    from safetensors.torch import load_file

    random.seed(648048)
    torch.manual_seed(648048)

    torch.backends.cuda.enable_flash_sdp(False)
    torch.backends.cuda.enable_mem_efficient_sdp(False)
    torch.backends.cuda.enable_math_sdp(True)

    tok, model, info = rt.load_base_with_v67_residual(
        Path(a.base_model),
        Path(a.source_adapter),
        Path(a.v67_patch),
    )

    model.eval()

    for p in model.parameters():
        p.requires_grad_(False)

    Wcpu = (
        model.get_output_embeddings()
        .weight
        .detach()
        .float()
        .cpu()
    )

    hidden = int(Wcpu.shape[1])
    P = make_projection(
        torch,
        hidden,
        PROJ_DIM,
    )

    train = read_jsonl(ptrain)
    val = read_jsonl(pval)
    negs = read_jsonl(pneg)
    onpol = read_jsonl(p46trans)

    if len(train) != 639 or len(val) != 160 or len(negs) != 2556 or len(onpol) != 639:
        raise SystemExit("Unexpected v6.44/v6.46 row counts")

    def group(rows):
        g = {}

        for r in rows:
            sid = str(r["source_row_id"])

            g.setdefault(
                sid,
                {
                    "prompt": r["prompt"],
                    "target_ids": [
                        int(x)
                        for x in r["target_token_ids"]
                    ],
                    "plan": int(r["plan_id"]),
                },
            )

        return g

    tg = group(train)
    vg = group(val)

    if len(tg) != 80 or len(vg) != 20:
        raise SystemExit("Expected 80 train / 20 validation source groups")

    teacher_lookup = {
        str(r["transition_id"]): r
        for r in train
    }

    onpol_lookup = {
        str(r["teacher_transition_id"]): r
        for r in onpol
    }

    if set(teacher_lookup) != set(onpol_lookup):
        raise SystemExit("Teacher/on-policy pairing mismatch")

    # Capture teacher train and anchor validation states.
    req = []

    for sid, x in tg.items():
        pids = prompt_ids(
            tok,
            x["prompt"],
        )
        x["pids"] = pids

        req.append(
            (
                ("TP", sid),
                pids,
            )
        )

        for step in range(
            len(
                x["target_ids"]
            )
        ):
            req.append(
                (
                    ("TT", sid, step),
                    pids
                    + x["target_ids"][:step],
                )
            )

    for sid, x in vg.items():
        pids = prompt_ids(
            tok,
            x["prompt"],
        )
        x["pids"] = pids

        req.append(
            (
                ("VP", sid),
                pids,
            )
        )

        for step in range(
            len(
                x["target_ids"]
            )
        ):
            req.append(
                (
                    ("VT", sid, step),
                    pids
                    + x["target_ids"][:step],
                )
            )

    print(
        "TEACHER_STATE_CAPTURE_REQUESTS="
        + str(
            len(req)
        )
    )

    states = capture_states(
        torch,
        model,
        rt,
        req,
    )

    print("TEACHER_STATE_CAPTURE_DONE=True")

    payload = torch.load(
        p46hidden,
        map_location="cpu",
        weights_only=False,
    )

    if payload.get("schema") != "ZANT_LLM_V6_46_ON_POLICY_CONTEXT_HIDDEN_STATES_V1":
        raise SystemExit("Unexpected v6.46 hidden state schema")

    on_prompt_states = payload["prompt_states"]
    on_transition_states = payload["transition_states"]

    if len(on_prompt_states) != 80 or len(on_transition_states) != 639:
        raise SystemExit("Unexpected v6.46 hidden state counts")

    # Prompt plan predictor.
    train_prompt_states = [
        states[
            ("TP", sid)
        ]
        for sid in tg
    ]

    train_plan_labels = [
        tg[sid]["plan"]
        for sid in tg
    ]

    pred_plan = {}
    plan_correct = 0

    for sid, x in vg.items():
        pp = plan_knn(
            torch,
            train_prompt_states,
            train_plan_labels,
            states[
                ("VP", sid)
            ],
        )

        pred_plan[sid] = pp
        plan_correct += int(
            pp == x["plan"]
        )

    if plan_correct != 17:
        raise SystemExit(
            "v6.47 plan predictor reproduction drift: "
            + str(plan_correct)
        )

    print(
        "ANCHOR_PROMPT_PLAN_TOP1=17/20"
    )

    negmap = defaultdict(list)

    for r in negs:
        negmap[
            str(r["positive_transition_id"])
        ].append(
            int(r["negative_token_id"])
        )

    teacher_X = []
    teacher_Y = []
    teacher_base = []
    teacher_pos = []
    teacher_negs = []
    teacher_weights = []

    on_X = []
    on_Y = []
    on_base = []
    on_pos = []
    on_negs = []
    on_weights = []

    for r in train:
        tid = str(r["transition_id"])
        sid = str(r["source_row_id"])
        step = int(r["generation_step"])
        tids = [
            int(x)
            for x in r["target_token_ids"]
        ]

        pos = unit(
            torch,
            Wcpu[
                int(
                    r[
                        "canonical_token_id"
                    ]
                )
            ],
        )

        nids = negmap.get(
            tid,
            [],
        )

        neg_embs = torch.stack(
            [
                unit(
                    torch,
                    Wcpu[n],
                )
                for n in nids
            ]
        )

        negcent = unit(
            torch,
            neg_embs.mean(
                dim=0
            ),
        )

        identity = unit(
            torch,
            pos
            - IDENTITY_NEG_WEIGHT
            * negcent,
        )

        cur_t = states[
            ("TT", sid, step)
        ]

        prev1_t = (
            Wcpu[
                tids[
                    step - 1
                ]
            ]
            if step > 0
            else None
        )

        prev2_t = (
            Wcpu[
                tids[
                    step - 2
                ]
            ]
            if step > 1
            else None
        )

        x_t = feature(
            torch,
            cur_t,
            states[
                ("TP", sid)
            ],
            prev1_t,
            prev2_t,
            int(
                r["plan_id"]
            ),
            step,
            P,
        )

        base_t = unit(
            torch,
            cur_t,
        )

        balance = min(
            4.0,
            max(
                0.25,
                float(
                    r.get(
                        "balance_weight",
                        1.0,
                    )
                ),
            ),
        )

        teacher_X.append(x_t)
        teacher_Y.append(
            identity - base_t
        )
        teacher_base.append(base_t)
        teacher_pos.append(pos)
        teacher_negs.append(neg_embs)
        teacher_weights.append(
            0.5 * balance
        )

        op = onpol_lookup[
            tid
        ]

        opid = str(
            op[
                "on_policy_transition_id"
            ]
        )

        cur_o = on_transition_states[
            opid
        ].float()

        free_prev1 = op.get(
            "free_prev1_token_id"
        )
        free_prev2 = op.get(
            "free_prev2_token_id"
        )

        prev1_o = (
            Wcpu[
                int(
                    free_prev1
                )
            ]
            if free_prev1 is not None
            else None
        )

        prev2_o = (
            Wcpu[
                int(
                    free_prev2
                )
            ]
            if free_prev2 is not None
            else None
        )

        x_o = feature(
            torch,
            cur_o,
            on_prompt_states[
                sid
            ].float(),
            prev1_o,
            prev2_o,
            int(
                op["plan_id"]
            ),
            step,
            P,
        )

        base_o = unit(
            torch,
            cur_o,
        )

        on_X.append(x_o)
        on_Y.append(
            identity - base_o
        )
        on_base.append(base_o)
        on_pos.append(pos)
        on_negs.append(neg_embs)
        on_weights.append(
            0.5 * balance
        )

    X_teacher = torch.stack(
        teacher_X
    )
    Y_teacher = torch.stack(
        teacher_Y
    )
    X_on = torch.stack(
        on_X
    )
    Y_on = torch.stack(
        on_Y
    )

    W_teacher = torch.tensor(
        teacher_weights,
        dtype=torch.float32,
    )
    W_on = torch.tensor(
        on_weights,
        dtype=torch.float32,
    )

    X_pair = torch.cat(
        [
            X_teacher,
            X_on,
        ],
        dim=0,
    )

    Y_pair = torch.cat(
        [
            Y_teacher,
            Y_on,
        ],
        dim=0,
    )

    W_pair = torch.cat(
        [
            W_teacher,
            W_on,
        ],
        dim=0,
    )

    B0 = weighted_ridge(
        torch,
        X_pair,
        Y_pair,
        W_pair,
    )

    # Persistent trainable bridge: same linear architecture as the successful
    # v6.47 paired diagnostic, initialized exactly from its closed-form ridge.
    input_dim = int(
        X_pair.shape[1]
    )

    bridge = nn.Linear(
        input_dim,
        hidden,
        bias=False,
        device="cpu",
        dtype=torch.float32,
    )

    with torch.no_grad():
        bridge.weight.copy_(
            B0.T
        )

    # Build 1278 paired-domain training rows for gradient refinement.
    train_X = X_pair
    train_Y = Y_pair
    train_base = torch.cat(
        [
            torch.stack(
                teacher_base
            ),
            torch.stack(
                on_base
            ),
        ],
        dim=0,
    )

    train_pos = torch.cat(
        [
            torch.stack(
                teacher_pos
            ),
            torch.stack(
                on_pos
            ),
        ],
        dim=0,
    )

    train_negs = torch.cat(
        [
            torch.stack(
                teacher_negs
            ),
            torch.stack(
                on_negs
            ),
        ],
        dim=0,
    )

    train_weights = W_pair

    # Prepare validation teacher queries.
    teacher_eval = []

    val_lookup = {}

    for r in val:
        sid = str(
            r[
                "source_row_id"
            ]
        )
        step = int(
            r[
                "generation_step"
            ]
        )
        tids = [
            int(x)
            for x in r[
                "target_token_ids"
            ]
        ]

        cur = states[
            ("VT", sid, step)
        ]

        prev1 = (
            Wcpu[
                tids[
                    step - 1
                ]
            ]
            if step > 0
            else None
        )

        prev2 = (
            Wcpu[
                tids[
                    step - 2
                ]
            ]
            if step > 1
            else None
        )

        x = feature(
            torch,
            cur,
            states[
                ("VP", sid)
            ],
            prev1,
            prev2,
            pred_plan[
                sid
            ],
            step,
            P,
        )

        teacher_eval.append(
            {
                "id": sid,
                "step": step,
                "x": x,
                "base": unit(
                    torch,
                    cur,
                ),
                "target": int(
                    r[
                        "canonical_token_id"
                    ]
                ),
            }
        )

        val_lookup[
            (
                sid,
                step,
            )
        ] = r

    # Rebuild v6.31 controller for free-run validation states.
    v616 = (
        root
        / "artifacts"
        / "Zant-LLM-v6_16-routed-output-semantic-continuation-router"
    )
    v621 = (
        root
        / "artifacts"
        / "Zant-LLM-v6_21-output-prototype-bank-reconstruction"
    )
    v624 = (
        root
        / "artifacts"
        / "Zant-LLM-v6_24-supervised-oracle-mixture-selector-controller"
    )
    v631 = (
        root
        / "artifacts"
        / "Zant-LLM-v6_31-joint-controller-hard-error-execution-refinement"
    )

    router_file = v616 / "family_output_projection_router.safetensors"
    bank_file = v621 / "reconstructed_output_prototype_bank.safetensors"
    c624 = v624 / "oracle_mixture_selector_controller.pt"
    c631 = v631 / "joint_controller_execution_refinement.pt"

    controller_files = (
        (router_file, EXPECTED_V616_ROUTER_SHA),
        (bank_file, EXPECTED_V621_BANK_SHA),
        (c624, EXPECTED_V624_CONTROLLER_SHA),
        (c631, EXPECTED_V631_CONTROLLER_SHA),
    )

    for p, expected in controller_files:
        if not p.exists():
            raise SystemExit(
                "Missing controller prerequisite: "
                + str(p)
            )

        if rt.sha256_file(p) != expected:
            raise SystemExit(
                "Controller SHA mismatch: "
                + str(p)
            )

    if rt.folder_manifest_sha(v616) != EXPECTED_V616_FOLDER_SHA:
        raise SystemExit("v6.16 folder SHA mismatch")
    if rt.folder_manifest_sha(v624) != EXPECTED_V624_FOLDER_SHA:
        raise SystemExit("v6.24 folder SHA mismatch")
    if rt.folder_manifest_sha(v631) != EXPECTED_V631_FOLDER_SHA:
        raise SystemExit("v6.31 folder SHA mismatch")

    source_manifest = rt.read_json(
        v616
        / "family_output_projection_router_manifest.json"
    )

    raw = load_file(
        str(router_file),
        device="cpu",
    )

    source_router = rt.FamilyOutputProjectionRouter(
        hidden_size=int(
            source_manifest[
                "hidden_size"
            ]
        ),
        router_hidden=int(
            source_manifest[
                "router_hidden"
            ]
        ),
        prototype_directions=raw[
            "prototype_directions"
        ],
        prototype_strengths=raw[
            "prototype_strengths"
        ],
        device="cuda:0",
        dtype=torch.float32,
    )

    source_router.load_state_dict(
        {
            "fc1.weight": raw[
                "router.fc1.weight"
            ],
            "fc1.bias": raw[
                "router.fc1.bias"
            ],
            "fc2.weight": raw[
                "router.fc2.weight"
            ],
            "fc2.bias": raw[
                "router.fc2.bias"
            ],
        },
        strict=True,
    )

    bankraw = load_file(
        str(bank_file),
        device="cpu",
    )

    bank = (
        bankraw[
            "prototype_directions"
        ].float()
        * bankraw[
            "prototype_strengths"
        ].float().unsqueeze(1)
    ).contiguous()

    ctl624 = v624mod.OracleMixtureSelectorController(
        hidden_size=int(
            source_manifest[
                "hidden_size"
            ]
        ),
        source_router=source_router,
        new_bank=bank,
        selector_hidden=128,
        gate_hidden=64,
        gate_bias_init=-5.0,
        device="cuda:0",
    )

    p624 = torch.load(
        c624,
        map_location="cpu",
        weights_only=False,
    )

    ctl624.load_state_dict(
        p624[
            "controller_state"
        ],
        strict=True,
    )

    p631 = torch.load(
        c631,
        map_location="cpu",
        weights_only=False,
    )

    joint = jointmod.JointSequenceStateAdaptivePrototypeController(
        hidden_size=int(
            p631[
                "hidden_size"
            ]
        ),
        frozen_v624_controller=ctl624,
        residual_basis=p631[
            "residual_basis"
        ].float(),
        max_state_residual_norm=float(
            p631[
                "max_state_residual_norm"
            ]
        ),
        adaptive_residual_scale=float(
            p631[
                "adaptive_residual_scale"
            ]
        ),
        feature_hidden=int(
            p631[
                "feature_hidden"
            ]
        ),
        device="cuda:0",
    )

    joint.load_state_dict(
        p631[
            "controller_state"
        ],
        strict=True,
    )

    rollouts = {}

    handle, _ = jointmod.install_joint_controller(
        model,
        joint,
        rt,
    )

    try:
        with torch.no_grad():
            for sid, x in vg.items():
                joint.reset_history()

                pin = torch.tensor(
                    [x["pids"]],
                    dtype=torch.long,
                    device="cuda:0",
                )

                mask = torch.ones_like(
                    pin
                )

                gen = model.generate(
                    input_ids=pin,
                    attention_mask=mask,
                    max_new_tokens=MAX_NEW_TOKENS,
                    do_sample=False,
                    use_cache=True,
                    pad_token_id=tok.eos_token_id,
                )

                rollouts[sid] = [
                    int(z)
                    for z in gen[
                        0,
                        len(
                            x[
                                "pids"
                            ]
                        ):,
                    ].tolist()
                ]

                del pin, mask, gen

    finally:
        handle.remove()
        gc.collect()
        torch.cuda.empty_cache()
        torch.cuda.synchronize()

    hard_keys = sorted(
        set(
            (
                str(r["id"]),
                int(r["step"]),
            )
            for r in read_jsonl(
                d30
            )
            if r.get(
                "new_error_category"
            )
            in HARD_CATEGORIES
        )
    )

    if len(hard_keys) != 52:
        raise SystemExit(
            "Expected 52 authoritative hard errors"
        )

    free_req = []

    for sid, step in hard_keys:
        free_req.append(
            (
                ("FR", sid, step),
                vg[sid]["pids"]
                + rollouts[sid][:step],
            )
        )

    free_states = capture_states(
        torch,
        model,
        rt,
        free_req,
    )

    free_eval = []

    for sid, step in hard_keys:
        r = val_lookup[
            (
                sid,
                step,
            )
        ]

        gids = rollouts[
            sid
        ]

        cur = free_states[
            ("FR", sid, step)
        ]

        prev1 = (
            Wcpu[
                gids[
                    step - 1
                ]
            ]
            if step > 0
            and step - 1 < len(
                gids
            )
            else None
        )

        prev2 = (
            Wcpu[
                gids[
                    step - 2
                ]
            ]
            if step > 1
            and step - 2 < len(
                gids
            )
            else None
        )

        x = feature(
            torch,
            cur,
            states[
                ("VP", sid)
            ],
            prev1,
            prev2,
            pred_plan[
                sid
            ],
            step,
            P,
        )

        free_eval.append(
            {
                "id": sid,
                "step": step,
                "x": x,
                "base": unit(
                    torch,
                    cur,
                ),
                "target": int(
                    r[
                        "canonical_token_id"
                    ]
                ),
            }
        )

    # Round 0 authoritative paired-ridge evaluation.
    round0_weight = bridge.weight.detach().clone()

    round0 = eval_weight(
        torch,
        model,
        round0_weight,
        teacher_eval,
        free_eval,
    )

    if (
        round0["teacher_top128"] != 149
        or round0["free_top128"] != 40
        or round0["free_pool4096"] != 42
    ):
        raise SystemExit(
            "v6.47 paired-ridge reproduction drift: "
            + repr(
                round0
            )
        )

    print(
        "ROUND0_V6_47_REPRODUCTION_PASS=True"
    )
    print(
        "ROUND0_TEACHER_TOP128=149/160"
    )
    print(
        "ROUND0_FREE_TOP128=40/52"
    )
    print(
        "ROUND0_FREE_POOL4096=42/52"
    )

    best_round = 0
    best_metrics = {
        k: v
        for k, v in round0.items()
        if k != "detail"
    }
    best_detail = round0["detail"]
    best_state = copy.deepcopy(
        bridge.state_dict()
    )

    def score(m):
        # Free-run retrieval is primary, but a teacher floor is mandatory.
        if m["teacher_top128"] < 140:
            return -100000 + m["teacher_top128"]

        return (
            1000
            * m[
                "free_top128"
            ]
            + 10
            * m[
                "free_pool4096"
            ]
            + m[
                "teacher_top128"
            ]
        )

    best_score = score(
        best_metrics
    )

    optimizer = torch.optim.AdamW(
        bridge.parameters(),
        lr=LEARNING_RATE,
        weight_decay=WEIGHT_DECAY,
    )

    n = int(
        train_X.shape[0]
    )

    optimizer_steps = 0
    training_history = []

    for epoch in range(
        1,
        EPOCHS + 1,
    ):
        g = torch.Generator(
            device="cpu"
        )
        g.manual_seed(
            648048 + epoch
        )

        perm = torch.randperm(
            n,
            generator=g,
        )

        bridge.train()

        epoch_loss = 0.0
        epoch_mse = 0.0
        epoch_pos = 0.0
        epoch_neg = 0.0
        batches = 0

        for start in range(
            0,
            n,
            BATCH_SIZE,
        ):
            idx = perm[
                start:
                min(
                    n,
                    start + BATCH_SIZE,
                )
            ]

            xb = train_X.index_select(
                0,
                idx,
            )
            yb = train_Y.index_select(
                0,
                idx,
            )
            bb = train_base.index_select(
                0,
                idx,
            )
            pb = train_pos.index_select(
                0,
                idx,
            )
            nb = train_negs.index_select(
                0,
                idx,
            )
            wb = train_weights.index_select(
                0,
                idx,
            )

            pred_res = bridge(
                xb
            )

            target_loss = F.smooth_l1_loss(
                pred_res,
                yb,
                reduction="none",
            ).mean(
                dim=1
            )

            q = F.normalize(
                bb + pred_res,
                dim=1,
            )

            pos_sim = (
                q * pb
            ).sum(
                dim=1
            )

            neg_sim = torch.einsum(
                "bd,bkd->bk",
                q,
                nb,
            )

            hardest_neg = neg_sim.max(
                dim=1
            ).values

            pos_loss = (
                1.0
                - pos_sim
            )

            hard_loss = F.relu(
                HARD_NEG_MARGIN
                + hardest_neg
                - pos_sim
            )

            per_row = (
                MSE_WEIGHT
                * target_loss
                + POS_COS_WEIGHT
                * pos_loss
                + HARD_NEG_WEIGHT
                * hard_loss
            )

            loss = (
                per_row
                * wb
            ).sum() / wb.sum().clamp_min(
                1e-6
            )

            optimizer.zero_grad(
                set_to_none=True
            )
            loss.backward()

            torch.nn.utils.clip_grad_norm_(
                bridge.parameters(),
                GRAD_CLIP,
            )

            optimizer.step()
            optimizer_steps += 1

            epoch_loss += float(
                loss.detach()
            )
            epoch_mse += float(
                target_loss.mean().detach()
            )
            epoch_pos += float(
                pos_loss.mean().detach()
            )
            epoch_neg += float(
                hard_loss.mean().detach()
            )
            batches += 1

        bridge.eval()

        metrics = eval_weight(
            torch,
            model,
            bridge.weight.detach(),
            teacher_eval,
            free_eval,
        )

        row = {
            "epoch": epoch,
            "optimizer_steps_total": optimizer_steps,
            "loss": epoch_loss / batches,
            "mse_component": epoch_mse / batches,
            "positive_cosine_component": epoch_pos / batches,
            "hard_negative_component": epoch_neg / batches,
            "teacher_pool4096": metrics["teacher_pool4096"],
            "teacher_top128": metrics["teacher_top128"],
            "free_pool4096": metrics["free_pool4096"],
            "free_top128": metrics["free_top128"],
        }

        training_history.append(
            row
        )

        print(
            "TRAIN_EPOCH=%d STEPS=%d LOSS=%.6f TEACHER_TOP128=%d/160 FREE_POOL4096=%d/52 FREE_TOP128=%d/52"
            % (
                epoch,
                optimizer_steps,
                row["loss"],
                metrics["teacher_top128"],
                metrics["free_pool4096"],
                metrics["free_top128"],
            ),
            flush=True,
        )

        s = score(
            metrics
        )

        if s > best_score:
            best_score = s
            best_round = epoch
            best_metrics = {
                k: v
                for k, v in metrics.items()
                if k != "detail"
            }
            best_detail = metrics["detail"]
            best_state = copy.deepcopy(
                bridge.state_dict()
            )

    bridge.load_state_dict(
        best_state
    )

    artifact_path = (
        artifact_dir
        / "paired_context_token_identity_bridge.pt"
    )

    torch.save(
        {
            "schema": "ZANT_LLM_V6_48_PERSISTENT_PAIRED_CONTEXT_TOKEN_IDENTITY_BRIDGE_V1",
            "input_dim": input_dim,
            "hidden_size": hidden,
            "projection_dim": PROJ_DIM,
            "plan_k": PLAN_K,
            "feature_weights": FEATURE_WEIGHTS,
            "projection_seed": 645045,
            "projection_matrix": P.float().cpu(),
            "residual_clip": RESIDUAL_CLIP,
            "identity_negative_weight": IDENTITY_NEG_WEIGHT,
            "state_dict": {
                k: v.detach().float().cpu()
                for k, v in bridge.state_dict().items()
            },
            "best_round": int(best_round),
            "optimizer_steps_executed": int(optimizer_steps),
            "best_teacher_top128": int(
                best_metrics[
                    "teacher_top128"
                ]
            ),
            "best_free_pool4096": int(
                best_metrics[
                    "free_pool4096"
                ]
            ),
            "best_free_top128": int(
                best_metrics[
                    "free_top128"
                ]
            ),
            "source_v6_47_summary_sha256": EXPECTED_V647_SUMMARY_SHA,
            "retained_holdout_evaluated": False,
        },
        artifact_path,
    )

    detail_path = (
        artifact_dir
        / "v6_48_eval_detail.jsonl"
    )

    report_path = (
        artifact_dir
        / "v6_48_training_report.json"
    )

    manifest_path = (
        artifact_dir
        / "v6_48_bridge_manifest.json"
    )

    write_jsonl(
        detail_path,
        best_detail,
    )

    report = {
        "schema": "ZANT_LLM_V6_48_PAIRED_CONTEXT_TOKEN_IDENTITY_BRIDGE_TRAINING_REPORT_V1",
        "training_complete": True,
        "persistent_training": True,
        "train_teacher_transitions": 639,
        "train_on_policy_transitions": 639,
        "total_domain_mixed_rows": 1278,
        "optimizer_steps_executed": int(
            optimizer_steps
        ),
        "epochs_executed": EPOCHS,
        "round0_teacher_top128": 149,
        "round0_free_pool4096": 42,
        "round0_free_top128": 40,
        "best_round": int(
            best_round
        ),
        "best_teacher_pool4096": int(
            best_metrics[
                "teacher_pool4096"
            ]
        ),
        "best_teacher_top128": int(
            best_metrics[
                "teacher_top128"
            ]
        ),
        "best_free_pool4096": int(
            best_metrics[
                "free_pool4096"
            ]
        ),
        "best_free_top128": int(
            best_metrics[
                "free_top128"
            ]
        ),
        "gradient_refinement_improved_free_top128": bool(
            best_round > 0
            and best_metrics[
                "free_top128"
            ] > 40
        ),
        "training_history": training_history,
        "artifact_sha256": rt.sha256_file(
            artifact_path
        ),
        "eval_detail_sha256": rt.sha256_file(
            detail_path
        ),
        "retained_holdout_evaluated": False,
        "github_push_performed": False,
    }

    write_json(
        report_path,
        report,
    )

    manifest = {
        "schema": "ZANT_LLM_V6_48_BRIDGE_MANIFEST_V1",
        "artifact_file": artifact_path.name,
        "artifact_sha256": rt.sha256_file(
            artifact_path
        ),
        "input_dim": input_dim,
        "hidden_size": hidden,
        "parameter_count": int(
            sum(
                p.numel()
                for p in bridge.parameters()
            )
        ),
        "architecture": "single_linear_residual_bridge_initialized_from_v6_47_paired_ridge",
        "domain_mixing": "teacher_and_on_policy_1_to_1",
        "loss": {
            "smooth_l1_residual_weight": MSE_WEIGHT,
            "positive_cosine_weight": POS_COS_WEIGHT,
            "hard_negative_margin_weight": HARD_NEG_WEIGHT,
            "hard_negative_margin": HARD_NEG_MARGIN,
        },
        "optimizer": "AdamW",
        "learning_rate": LEARNING_RATE,
        "weight_decay": WEIGHT_DECAY,
        "epochs": EPOCHS,
        "optimizer_steps": int(
            optimizer_steps
        ),
        "best_round": int(
            best_round
        ),
        "anchor_validation_do_not_train": True,
        "retained_holdout_evaluated": False,
    }

    write_json(
        manifest_path,
        manifest,
    )

    print(
        "========== V6.48 TRAINING SUMMARY =========="
    )
    print(
        "V6_48_TRAINING_COMPLETE=True"
    )
    print(
        "PERSISTENT_TRAINING=True"
    )
    print(
        "TRAIN_TEACHER_TRANSITIONS=639"
    )
    print(
        "TRAIN_ON_POLICY_TRANSITIONS=639"
    )
    print(
        "TOTAL_DOMAIN_MIXED_ROWS=1278"
    )
    print(
        "OPTIMIZER_STEPS_EXECUTED="
        + str(
            optimizer_steps
        )
    )
    print(
        "BEST_ROUND="
        + str(
            best_round
        )
    )
    print(
        "BEST_TEACHER_TOP128="
        + str(
            best_metrics[
                "teacher_top128"
            ]
        )
        + "/160"
    )
    print(
        "BEST_FREE_POOL4096="
        + str(
            best_metrics[
                "free_pool4096"
            ]
        )
        + "/52"
    )
    print(
        "BEST_FREE_TOP128="
        + str(
            best_metrics[
                "free_top128"
            ]
        )
        + "/52"
    )
    print(
        "GRADIENT_REFINEMENT_IMPROVED_FREE_TOP128="
        + str(
            report[
                "gradient_refinement_improved_free_top128"
            ]
        )
    )
    print(
        "BRIDGE_ARTIFACT_SHA256="
        + rt.sha256_file(
            artifact_path
        )
    )
    print(
        "TRAINING_REPORT_SHA256="
        + rt.sha256_file(
            report_path
        )
    )
    print(
        "BRIDGE_MANIFEST_SHA256="
        + rt.sha256_file(
            manifest_path
        )
    )
    print(
        "RETAINED_HOLDOUT_EVALUATED=False"
    )
    print(
        "NO_GITHUB_PUSH=True"
    )


if __name__ == "__main__":
    main()
