from pathlib import Path
import argparse
import importlib.util


def load_module(path, name):
    spec = importlib.util.spec_from_file_location(
        name,
        str(path),
    )
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--report", required=True)
    ap.add_argument("--runtime-script", required=True)
    ap.add_argument("--artifact-dir", required=True)
    a = ap.parse_args()

    rt = load_module(
        a.runtime_script,
        "v648_route_runtime",
    )

    r = rt.read_json(
        Path(a.report)
    )

    artifact_dir = Path(
        a.artifact_dir
    )

    if r.get(
        "training_complete"
    ) is not True:
        raise SystemExit(
            "v6.48 training incomplete"
        )

    if r.get(
        "persistent_training"
    ) is not True:
        raise SystemExit(
            "v6.48 persistent-training governance mismatch"
        )

    steps = int(
        r[
            "optimizer_steps_executed"
        ]
    )
    best_round = int(
        r[
            "best_round"
        ]
    )
    teacher = int(
        r[
            "best_teacher_top128"
        ]
    )
    free_pool = int(
        r[
            "best_free_pool4096"
        ]
    )
    free = int(
        r[
            "best_free_top128"
        ]
    )
    improved = bool(
        r[
            "gradient_refinement_improved_free_top128"
        ]
    )

    if (
        best_round > 0
        and teacher >= 145
        and free >= 42
        and free_pool >= 44
    ):
        status = "PERSISTENT_GRADIENT_REFINEMENT_IMPROVES_THE_PAIRED_CONTEXT_BRIDGE"
        nxt = "v6.49-persistent-bridge-live-inference-integration-milestone"
        obj = "PERSISTENT_BRIDGE_INFERENCE_INTEGRATION+LIVE_FREE_RUN_AB+FIRST_TOKEN_COMPATIBILITY+GATED_CONTROL"

    elif (
        teacher >= 145
        and free >= 40
        and free_pool >= 42
        and best_round == 0
    ):
        status = "PERSISTENT_PAIRED_RIDGE_BRIDGE_PRESERVES_STRONG_DUAL_DOMAIN_RETRIEVAL_GRADIENT_REFINEMENT_NOT_NEEDED"
        nxt = "v6.49-persistent-bridge-live-inference-integration-milestone"
        obj = "PERSISTENT_BRIDGE_INFERENCE_INTEGRATION+LIVE_FREE_RUN_AB+FIRST_TOKEN_COMPATIBILITY+GATED_CONTROL"

    elif (
        teacher >= 140
        and free >= 36
    ):
        status = "PERSISTENT_BRIDGE_IS_USABLE_BUT_REQUIRES_RUNTIME_GATE_CALIBRATION"
        nxt = "v6.49-persistent-bridge-runtime-gate-calibration-milestone"
        obj = "BRIDGE_GATE_CALIBRATION+TEACHER_FREE_RUN_SAFETY_FLOOR+LIVE_GENERATION_AB"

    else:
        status = "PERSISTENT_TRAINING_DOES_NOT_PRESERVE_THE_V6_47_DUAL_DOMAIN_SIGNAL"
        nxt = "v6.49-paired-ridge-persistence-and-training-objective-review-milestone"
        obj = "RESTORE_V6_47_PAIRED_RIDGE+LOSS_ABLATION+PERSISTENT_ARTIFACT_VALIDATION"

    analysis = {
        "schema": "ZANT_LLM_V6_48_MILESTONE_ANALYSIS_V1",
        "persistent_training_complete": True,
        "optimizer_steps_executed": steps,
        "best_round": best_round,
        "best_teacher_top128": teacher,
        "best_free_pool4096": free_pool,
        "best_free_top128": free,
        "gradient_refinement_improved_free_top128": improved,
        "classification": status,
        "retained_holdout_opened": False,
        "selected_v6_49_objective": obj,
        "next_milestone": nxt,
    }

    panalysis = (
        artifact_dir
        / "v6_48_milestone_analysis.json"
    )

    rt.write_json(
        panalysis,
        analysis,
    )

    summary = {
        "schema": "ZANT_LLM_V6_48_PAIRED_CONTEXT_TOKEN_IDENTITY_BRIDGE_TRAINING_MILESTONE_V1",
        "milestone_complete": True,
        "persistent_training": True,
        "optimizer_steps_executed": steps,
        "best_round": best_round,
        "best_teacher_top128": teacher,
        "best_free_pool4096": free_pool,
        "best_free_top128": free,
        "gradient_refinement_improved_free_top128": improved,
        "retained_holdout_opened": False,
        "milestone_status": status,
        "selected_v6_49_objective": obj,
        "next_milestone": nxt,
        "github_push_performed": False,
    }

    psummary = (
        artifact_dir
        / "v6_48_milestone_summary.json"
    )

    rt.write_json(
        psummary,
        summary,
    )

    print(
        "========== V6.48 MILESTONE FINAL =========="
    )
    print(
        "V6_48_MILESTONE_COMPLETE=True"
    )
    print(
        "PERSISTENT_TRAINING=True"
    )
    print(
        "OPTIMIZER_STEPS_EXECUTED="
        + str(
            steps
        )
    )
    print(
        "BEST_ROUND="
        + str(
            best_round
        )
    )
    print(
        "BEST_TEACHER_TOP128="
        + str(
            teacher
        )
        + "/160"
    )
    print(
        "BEST_FREE_POOL4096="
        + str(
            free_pool
        )
        + "/52"
    )
    print(
        "BEST_FREE_TOP128="
        + str(
            free
        )
        + "/52"
    )
    print(
        "GRADIENT_REFINEMENT_IMPROVED_FREE_TOP128="
        + str(
            improved
        )
    )
    print(
        "RETAINED_HOLDOUT_OPENED=False"
    )
    print(
        "MILESTONE_STATUS="
        + status
    )
    print(
        "SELECTED_V6_49_OBJECTIVE="
        + obj
    )
    print(
        "ANALYSIS_SHA256="
        + rt.sha256_file(
            panalysis
        )
    )
    print(
        "FINAL_SUMMARY_SHA256="
        + rt.sha256_file(
            psummary
        )
    )
    print(
        "NEXT_MILESTONE="
        + nxt
    )
    print(
        "GITHUB_PUSH_PERFORMED=False"
    )


if __name__ == "__main__":
    main()
