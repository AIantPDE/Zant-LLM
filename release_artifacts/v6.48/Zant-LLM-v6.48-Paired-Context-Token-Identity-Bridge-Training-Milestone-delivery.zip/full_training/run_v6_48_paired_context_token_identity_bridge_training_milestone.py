from pathlib import Path
import argparse
import subprocess
import sys


def run(cmd):
    print(
        "RUN=" + " ".join(
            str(x)
            for x in cmd
        ),
        flush=True,
    )

    p = subprocess.run(
        cmd
    )

    if p.returncode != 0:
        raise SystemExit(
            p.returncode
        )


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", required=True)
    ap.add_argument("--base-model", required=True)
    ap.add_argument("--source-adapter", required=True)
    ap.add_argument("--v67-patch", required=True)
    args = ap.parse_args()

    root = Path(args.root)
    py = sys.executable

    internal = (
        root
        / "full_training"
        / "v6_48_internal"
    )

    runtime = (
        root
        / "full_training"
        / "v6_36_internal"
        / "runtime_v6_36.py"
    )

    v624_script = (
        root
        / "full_training"
        / "v6_36_internal"
        / "controller_v6_24_frozen.py"
    )

    joint_script = (
        root
        / "full_training"
        / "v6_36_internal"
        / "controller_v6_29_joint.py"
    )

    artifact_dir = (
        root
        / "artifacts"
        / "Zant-LLM-v6_48-paired-context-token-identity-bridge"
    )

    report = (
        artifact_dir
        / "v6_48_training_report.json"
    )

    print(
        "========== ZANT-LLM v6.48 PERSISTENT PAIRED-CONTEXT TOKEN-IDENTITY BRIDGE TRAINING =========="
    )
    print("PERSISTENT_TRAINING=True")
    print("SOURCE_V6_47_COMPLETE=True")
    print("SOURCE_PAIRED_TEACHER_TOP128=149/160")
    print("SOURCE_PAIRED_FREE_TOP128=40/52")
    print("SOURCE_PAIRED_FREE_POOL4096=42/52")
    print(
        "OBJECTIVE=PERSISTENT_PAIRED_CONTEXT_TOKEN_IDENTITY_BRIDGE+PLAN_STEP_BALANCING+HARD_NEGATIVE_LOSS+DOMAIN_MIXING"
    )
    print("ANCHOR_VALIDATION_DO_NOT_TRAIN=True")
    print("RETAINED_HOLDOUT_EVALUATED=False")
    print("NO_GITHUB_PUSH=True")

    run(
        [
            py,
            str(
                internal
                / "train_v6_48_paired_context_bridge.py"
            ),
            "--root",
            str(root),
            "--base-model",
            args.base_model,
            "--source-adapter",
            args.source_adapter,
            "--v67-patch",
            args.v67_patch,
            "--runtime-script",
            str(runtime),
            "--v624-controller-script",
            str(v624_script),
            "--joint-controller-script",
            str(joint_script),
            "--artifact-dir",
            str(artifact_dir),
        ]
    )

    run(
        [
            py,
            str(
                internal
                / "route_v6_48.py"
            ),
            "--report",
            str(report),
            "--runtime-script",
            str(runtime),
            "--artifact-dir",
            str(artifact_dir),
        ]
    )

    print("V6_48_PROCESS_EXIT=0")
    print(
        "========== v6.48 ONE-CLICK DONE =========="
    )


if __name__ == "__main__":
    main()
