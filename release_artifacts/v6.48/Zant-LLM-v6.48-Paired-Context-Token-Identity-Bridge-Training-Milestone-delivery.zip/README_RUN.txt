Zant-LLM v6.48
Persistent Paired-Context Token-Identity Bridge Training Milestone
==================================================================

SOURCE v6.47
------------
v6.47 completed successfully:

  ANCHOR PROMPT PLAN TOP1                   = 17/20

  TEACHER-ONLY TEACHER TOP128               = 151/160
  ON-POLICY-ONLY TEACHER TOP128             = 122/160
  PAIRED TEACHER TOP128                     = 149/160

  TEACHER-ONLY FREE TOP128                  = 17/52
  ON-POLICY-ONLY FREE TOP128                = 40/52
  PAIRED FREE POOL4096                      = 42/52
  PAIRED FREE TOP128                        = 40/52

  PAIRED FREE GAIN OVER TEACHER-ONLY        = +23
  PAIRED TEACHER CHANGE                     = -2
  PAIRED DOMAIN GAP CLOSED RATE             = 0.454808

Final v6.47 status:

  PAIRED_TEACHER_FREE_RUN_CONTEXT_CLOSES_ENOUGH_DOMAIN_GAP_FOR_PERSISTENT_TRAINING

Training authorization:

  TRAINING_AUTHORIZED=True

Selected v6.48 objective:

  PERSISTENT_PAIRED_CONTEXT_TOKEN_IDENTITY_BRIDGE
  + PLAN_STEP_BALANCING
  + HARD_NEGATIVE_LOSS
  + DOMAIN_MIXING


WHAT CHANGES IN v6.48
---------------------
v6.47 used ephemeral closed-form ridge fitting.

v6.48 creates a persistent bridge artifact that can be loaded by later live
generation code.

This is the first persistent training milestone after the v6.31-v6.47
diagnostic chain.


TRAINING DATA
-------------
Teacher domain:

  639 v6.44 teacher transitions

On-policy domain:

  639 v6.46 free-run transitions

Total:

  1278 rows

Every teacher transition is paired with its exact on-policy transition.

The 20 anchor validation source rows remain DO_NOT_TRAIN.

Retained holdout remains closed.


ROUND 0
-------
The bridge is initialized from the exact successful v6.47 paired weighted
ridge solution.

Expected round-0 reproduction:

  Teacher Top128 = 149/160

  Free Pool4096  = 42/52

  Free Top128    = 40/52

If these values do not reproduce, v6.48 stops before persistent artifact
selection.


PERSISTENT BRIDGE
-----------------
Architecture:

  single linear residual bridge

Input:

  current hidden state projection
  prompt hidden state projection
  previous token embedding projection
  previous-2 token embedding projection
  predicted sequence plan
  generation step
  bias coordinate

Output:

  hidden-size residual vector

Final retrieval query:

  normalize(base hidden + bridge residual)


WHY LINEAR
----------
v6.47 already showed that the paired linear bridge is strong.

The purpose of v6.48 is to persist the proven signal, not to introduce an
unnecessary architecture change at the same time.


GRADIENT REFINEMENT
-------------------
After exact paired-ridge initialization, v6.48 runs:

  4 epochs
  batch size 64
  about 80 optimizer steps
  AdamW
  learning rate 2e-4

Loss:

  45% residual Smooth-L1
  40% positive token cosine
  15% hard-negative margin

Hard-negative margin:

  0.06

Plan-step balance weights are preserved.

Teacher and on-policy rows are mixed 1:1.


SAFE BEST-CHECKPOINT POLICY
---------------------------
Round 0 is always eligible as the best checkpoint.

This is intentional.

If gradient refinement damages the proven v6.47 signal, v6.48 does NOT save
the worse checkpoint merely because optimizer steps were executed.

Selection priority:

  1. Teacher Top128 must remain >= 140/160

  2. maximize Free-run Top128

  3. maximize Free-run Pool4096

  4. then maximize Teacher Top128


EXPECTED ARTIFACT
-----------------
artifacts\
Zant-LLM-v6_48-paired-context-token-identity-bridge\

  paired_context_token_identity_bridge.pt

  v6_48_bridge_manifest.json

  v6_48_training_report.json

  v6_48_eval_detail.jsonl

  v6_48_milestone_analysis.json

  v6_48_milestone_summary.json


ARTIFACT CONTENT
----------------
The .pt artifact contains:

  bridge schema
  input dimension
  hidden size
  fixed projection matrix
  feature weights
  residual clip
  token identity negative weight
  trained/persisted state_dict
  best round
  optimizer step count
  validation metrics
  v6.47 source lineage


RETAINED HOLDOUT
----------------
RETAINED_HOLDOUT_EVALUATED=False

The retained holdout remains closed.

v6.48 still uses only the existing 20-anchor development validation to select
the persistent checkpoint.


AUTOMATIC v6.49 ROUTING
-----------------------
A. Gradient refinement improves beyond v6.47 while preserving Teacher:

  v6.49-persistent-bridge-live-inference-integration-milestone


B. Round 0 remains best and preserves:

  Teacher >= 145/160
  Free Top128 >= 40/52
  Free Pool4096 >= 42/52

This is still a SUCCESS.

It means the paired ridge itself is the correct persistent bridge and extra
gradient refinement was unnecessary.

Next:

  v6.49-persistent-bridge-live-inference-integration-milestone


C. Artifact is usable but Teacher/Free balance weakens:

  v6.49-persistent-bridge-runtime-gate-calibration-milestone


D. Persistent training cannot preserve v6.47:

  v6.49-paired-ridge-persistence-and-training-objective-review-milestone


IMPORTANT
---------
v6.48 is persistent training.

But it still does NOT modify:

  base Gemma weights
  v6.31 controller weights
  retained holdout
  GitHub

The newly trained object is the paired-context token-identity bridge only.


RUN
---
Extract into:

  C:\Users\Administrator\Desktop\Zant-LLM

Then run:

  powershell.exe -ExecutionPolicy Bypass -File "C:\Users\Administrator\Desktop\Zant-LLM\RUN_ZANT_V6_48_PAIRED_CONTEXT_TOKEN_IDENTITY_BRIDGE_TRAINING_ONE_CLICK.ps1"
