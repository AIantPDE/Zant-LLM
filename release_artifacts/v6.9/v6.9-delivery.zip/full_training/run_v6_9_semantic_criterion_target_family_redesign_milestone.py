from pathlib import Path
import argparse,subprocess,sys

def main():
    ap=argparse.ArgumentParser()
    for k in (
        "root","v68-bridge","v67-reconstructed-file","approved-file",
        "train-file","holdout-file","v57-runner","worker"
    ):
        ap.add_argument("--"+k,required=True)
    a=ap.parse_args()

    print("========== ZANT-LLM v6.9 SEMANTIC-CRITERION + TARGET-FAMILY REDESIGN ==========")
    print("NO_TRAINING=True")
    print("NO_NEW_RULES=True")
    print("SOURCE_V6_8_COMPLETE=True")
    print("SOURCE_V6_8_PASS=0/20")
    print("SOURCE_V6_8_HIT_MAX=10")
    print("SOURCE_V6_8_FIRST_TOKEN_TOP1=0/20")
    print("SOURCE_V6_8_FIRST_TOKEN_MEAN_RANK=24.25")
    print("GENERATED_PARAPHRASE_ALLOWED=False")
    print("TARGET_FAMILY_POLICY=EXISTING_SOURCE_ONLY")
    print("RETAINED_HOLDOUT_EVALUATED=False")
    print("NO_GITHUB_PUSH=True")

    cmd=[
        Path(sys.executable),a.worker,
        "--root",a.root,
        "--v68-bridge",a.v68_bridge,
        "--v67-reconstructed-file",a.v67_reconstructed_file,
        "--approved-file",a.approved_file,
        "--train-file",a.train_file,
        "--holdout-file",a.holdout_file,
        "--v57-runner",a.v57_runner,
    ]
    print("RUN="+subprocess.list2cmdline([str(x) for x in cmd]))
    p=subprocess.run([str(x) for x in cmd])
    if p.returncode!=0:
        raise SystemExit("v6.9 worker failed exit="+str(p.returncode))
    print("V6_9_PROCESS_EXIT=0")
    print("========== v6.9 ONE-CLICK DONE ==========")

if __name__=="__main__":
    main()
