from pathlib import Path
import argparse,json,hashlib,importlib.util,inspect
from collections import Counter,defaultdict

EXPECTED_V68_ANCHOR_REPORT_SHA="e833edfd144a969b66a8da247a12ac61402e67324bc2e91cfb90456e139b966a"
EXPECTED_V68_ANALYSIS_SHA="9af981f694eb98936d80246ab1dceba565f4b21934aff75cf02374fa657cf39b"
EXPECTED_V68_SUMMARY_SHA="de9c31aa9623f74739487e56202a695fcad63349efe70078a40e055ba623cc51"
EXPECTED_V68_PATCH_MANIFEST_SHA="5095bd899a60752b982746aa9c0821e5df0b0c51d026d0d6318140447e4e2e98"
EXPECTED_V68_BRIDGE_FILE_SHA="c115cb57a6767a1dd85e2da5e3814a788249784fcc2aba4e45f884dd1301d440"
EXPECTED_V67_RECON_TARGET_SHA="05adfd512b6a6ae856e830fd242383f4695f00ea0e5172e1f447aaea50358e1f"
EXPECTED_V59171_APPROVED_SHA="688d978fee7062a49a2dbcb7f296b6824cd4ef3bdeb89065e2b6998912b14bd0"
EXPECTED_TRAIN_SHA="26a9cdb048c5e695bedcfd2a76d771d4361be79bae37a21e5432c49b4f6d9600"
EXPECTED_HOLDOUT_SHA="00c7401e10cb1555be8caf44a7717d80f8c57e86d6da67f587c3c29a626b89a5"

def sha256_file(path):
    h=hashlib.sha256()
    with Path(path).open("rb") as f:
        for b in iter(lambda:f.read(1048576),b""):
            h.update(b)
    return h.hexdigest()

def folder_manifest_sha(path):
    excluded={
        "v5_9_training_complete.json","v5_9_3_training_complete.json",
        "v5_9_7_training_complete.json","v5_9_12_training_complete.json",
        "v5_9_18_training_complete.json","v5_9_20_training_complete.json",
        "v5_9_22_training_complete.json","v5_9_25_training_complete.json",
        "v5_9_27_training_complete.json","v5_9_30_training_complete.json",
        "v6_2_training_complete.json","v6_3_block33_training_complete.json",
        "v6_3_block27_training_complete.json","v6_4_training_complete.json",
        "v6_5_training_complete.json","v6_7_training_complete.json",
        "v6_8_training_complete.json",
    }
    rows=[]
    for p in sorted(Path(path).rglob("*")):
        if p.is_file() and p.name not in excluded:
            rows.append(p.relative_to(path).as_posix()+"\t"+sha256_file(p))
    return hashlib.sha256(("\n".join(rows)+"\n").encode("utf-8")).hexdigest()

def read_json(path):
    return json.loads(Path(path).read_text(encoding="utf-8-sig"))

def read_jsonl(path):
    out=[]
    with Path(path).open("r",encoding="utf-8-sig") as f:
        for i,line in enumerate(f,1):
            line=line.strip()
            if not line:
                continue
            try:
                out.append(json.loads(line))
            except Exception as e:
                raise SystemExit(f"Invalid JSONL {path}:{i}: {e}")
    return out

def write_json(path,obj):
    Path(path).parent.mkdir(parents=True,exist_ok=True)
    Path(path).write_text(
        json.dumps(obj,ensure_ascii=False,indent=2)+"\n",
        encoding="utf-8",newline="\n"
    )

def write_jsonl(path,rows):
    Path(path).parent.mkdir(parents=True,exist_ok=True)
    with Path(path).open("w",encoding="utf-8",newline="\n") as f:
        for r in rows:
            f.write(json.dumps(r,ensure_ascii=False,separators=(",",":"))+"\n")

def load_module(path,name):
    spec=importlib.util.spec_from_file_location(name,str(path))
    m=importlib.util.module_from_spec(spec)
    spec.loader.exec_module(m)
    return m

def cid(r):
    return str(r.get("source_case_id") or r.get("case_id") or r.get("id") or "")

def lang(r):
    v=str(r.get("language") or r.get("lang") or "").lower()
    if v in ("en","zh"):
        return v
    return "zh" if "_ZH_" in cid(r) else "en"

def family(r):
    return str(r.get("family") or r.get("category") or "unknown")

def prompt_target(r):
    p=r.get("prompt")
    t=r.get("response") or r.get("target") or r.get("answer") or r.get("completion")
    msgs=r.get("messages") or []
    if (p is None or t is None) and isinstance(msgs,list):
        users=[m.get("content","") for m in msgs if str(m.get("role","")).lower() in ("user","human")]
        assists=[m.get("content","") for m in msgs if str(m.get("role","")).lower() in ("assistant","model")]
        if p is None and users:
            p=users[-1]
        if t is None and assists:
            t=assists[-1]
    if p is None or t is None:
        raise ValueError("missing prompt/target for "+cid(r))
    return str(p).strip(),str(t).strip()

def generated_body(r):
    for k in ("body","output","generated_text","response","text","completion"):
        if isinstance(r.get(k),str):
            return r[k].strip()
    return ""

def case_from_row(r):
    p,_=prompt_target(r)
    return {
        "id":cid(r),
        "kind":"SX_EN" if lang(r)=="en" else "SX_ZH",
        "language":lang(r),
        "route":"model",
        "family":family(r),
        "mode":r.get("mode"),
        "composition_depth":r.get("composition_depth"),
        "text":p,
        "runtime_strategy":"GENERIC_ADVERSARIAL_TRANSFER_STRESS_WRAPPER_ONLY",
        "per_case_exact_cue_enabled":False,
        "per_mode_exact_cue_enabled":False,
        "family_specific_cue_enabled":False,
    }

def semantic_bool(v57,text,case):
    try:
        return bool(v57.stress_semantic(text,case))
    except Exception as e:
        raise RuntimeError(
            "stress_semantic failed for "+str(case.get("id"))+": "+repr(e)
        )

def source_candidates(recon_row,approved_row,train_row):
    out=[]
    def add(kind,text):
        if not isinstance(text,str):
            return
        text=text.strip()
        if not text:
            return
        if any(x["text"]==text for x in out):
            return
        out.append({"kind":kind,"text":text})
    add("V6_7_RECONSTRUCTED",recon_row.get("canonical_target"))
    add("V5_9_17_1_APPROVED_CANONICAL",approved_row.get("canonical_target"))
    add("V5_9_17_1_ORIGINAL_SOURCE",approved_row.get("original_target"))
    try:
        _,t=prompt_target(train_row)
        add("V5_9_2_TRAINING_ROW_TARGET",t)
    except Exception:
        pass
    return out

def choose_existing_valid(cands):
    priority={
        "V6_7_RECONSTRUCTED":0,
        "V5_9_17_1_APPROVED_CANONICAL":1,
        "V5_9_17_1_ORIGINAL_SOURCE":2,
        "V5_9_2_TRAINING_ROW_TARGET":3,
    }
    valid=[x for x in cands if x["semantic_pass"]]
    if not valid:
        return None
    return min(valid,key=lambda x:(priority.get(x["kind"],99),len(x["text"])))

def main():
    ap=argparse.ArgumentParser()
    for k in (
        "root","v68-bridge","v67-reconstructed-file","approved-file",
        "train-file","holdout-file","v57-runner"
    ):
        ap.add_argument("--"+k,required=True)
    a=ap.parse_args()

    root=Path(a.root)
    v68_bridge=Path(a.v68_bridge)
    reconf=Path(a.v67_reconstructed_file)
    approvedf=Path(a.approved_file)
    trainf=Path(a.train_file)
    holdoutf=Path(a.holdout_file)
    v57p=Path(a.v57_runner)

    v68_report=root/"diagnostics/v6_8_prompt_conditioned_semantic_bridge_milestone/v6_8_anchor20_report.json"
    v68_detail=root/"diagnostics/v6_8_prompt_conditioned_semantic_bridge_milestone/v6_8_anchor20_detail.jsonl"
    v68_analysis=root/"diagnostics/v6_8_prompt_conditioned_semantic_bridge_milestone/v6_8_milestone_analysis.json"
    v68_summary=root/"diagnostics/v6_8_prompt_conditioned_semantic_bridge_milestone/v6_8_milestone_summary.json"
    bridge_file=v68_bridge/"semantic_bridge.safetensors"

    for p in (
        v68_bridge,bridge_file,v68_report,v68_detail,v68_analysis,v68_summary,
        reconf,approvedf,trainf,holdoutf,v57p
    ):
        if not p.exists():
            raise SystemExit("Missing required source: "+str(p))

    if sha256_file(v68_report)!=EXPECTED_V68_ANCHOR_REPORT_SHA:
        raise SystemExit("v6.8 anchor report SHA mismatch")
    if sha256_file(v68_analysis)!=EXPECTED_V68_ANALYSIS_SHA:
        raise SystemExit("v6.8 analysis SHA mismatch")
    if sha256_file(v68_summary)!=EXPECTED_V68_SUMMARY_SHA:
        raise SystemExit("v6.8 summary SHA mismatch")
    if folder_manifest_sha(v68_bridge)!=EXPECTED_V68_PATCH_MANIFEST_SHA:
        raise SystemExit("v6.8 patch manifest SHA mismatch")
    if sha256_file(bridge_file)!=EXPECTED_V68_BRIDGE_FILE_SHA:
        raise SystemExit("v6.8 bridge file SHA mismatch")
    if sha256_file(reconf)!=EXPECTED_V67_RECON_TARGET_SHA:
        raise SystemExit("v6.7 reconstructed target SHA mismatch")
    if sha256_file(approvedf)!=EXPECTED_V59171_APPROVED_SHA:
        raise SystemExit("v5.9.17.1 approved target SHA mismatch")
    if sha256_file(trainf)!=EXPECTED_TRAIN_SHA:
        raise SystemExit("train100 SHA mismatch")
    if sha256_file(holdoutf)!=EXPECTED_HOLDOUT_SHA:
        raise SystemExit("holdout SHA mismatch")

    r68=read_json(v68_report)
    a68=read_json(v68_analysis)
    s68=read_json(v68_summary)
    if int(r68.get("bridge_anchor_pass_count",-1))!=0:
        raise SystemExit("Expected v6.8 PASS=0")
    if int(r68.get("anchor_hit_max_count",-1))!=10:
        raise SystemExit("Expected v6.8 HIT_MAX=10")
    if int(r68.get("english_hit_max_count",-1))!=10:
        raise SystemExit("Expected v6.8 English HIT_MAX=10")
    if int(r68.get("chinese_hit_max_count",-1))!=0:
        raise SystemExit("Expected v6.8 Chinese HIT_MAX=0")
    if int(r68.get("first_token_top1_count",-1))!=0:
        raise SystemExit("Expected v6.8 first-token TOP1=0")
    if abs(float(r68.get("first_token_mean_rank",-1))-24.25)>1e-9:
        raise SystemExit("Unexpected v6.8 first-token mean rank")
    if a68.get("classification")!="PROMPT_CONDITIONED_SEMANTIC_BRIDGE_INSUFFICIENT":
        raise SystemExit("v6.8 analysis classification mismatch")
    if int(a68.get("same_generated_text_as_v6_7_rows",-1))!=19:
        raise SystemExit("Expected v6.8 same-text-as-v6.7=19/20")
    if s68.get("milestone_complete") is not True:
        raise SystemExit("v6.8 milestone not complete")
    if s68.get("retained_holdout_opened") is not False:
        raise SystemExit("retained holdout must remain closed")
    if s68.get("next_milestone")!="v6.9-semantic-criterion-and-target-family-redesign-milestone":
        raise SystemExit("v6.8 route mismatch")

    train_rows=read_jsonl(trainf)
    anchors=[r for r in train_rows if r.get("v5_9_2_role")=="residual_anchor"]
    if len(anchors)!=20:
        raise SystemExit("Expected 20 residual anchors")
    if {cid(x) for x in train_rows} & {cid(x) for x in read_jsonl(holdoutf)}:
        raise SystemExit("Train/holdout ID overlap")

    recon={str(r.get("source_case_id")):r for r in read_jsonl(reconf)}
    approved={str(r.get("source_case_id")):r for r in read_jsonl(approvedf)}
    detail={str(r.get("id") or r.get("case_id")):r for r in read_jsonl(v68_detail)}
    by_train={cid(r):r for r in anchors}

    if len(recon)!=20 or len(approved)!=20 or len(detail)!=20 or len(by_train)!=20:
        raise SystemExit(
            "Expected 20-row maps: recon/approved/detail/train = "
            f"{len(recon)}/{len(approved)}/{len(detail)}/{len(by_train)}"
        )

    v57=load_module(v57p,"v57_v69")
    if not hasattr(v57,"stress_semantic"):
        raise SystemExit("v5.7 runner has no stress_semantic")

    try:
        semantic_source=inspect.getsource(v57.stress_semantic)
    except Exception:
        semantic_source=repr(v57.stress_semantic)
    semantic_source_sha=hashlib.sha256(
        semantic_source.encode("utf-8","replace")
    ).hexdigest()

    print("========== ZANT-LLM v6.9 SEMANTIC-CRITERION AND TARGET-FAMILY REDESIGN ==========")
    print("NO_TRAINING=True")
    print("NO_NEW_RULES=True")
    print("SOURCE_V6_8_COMPLETE=True")
    print("SOURCE_V6_8_PASS=0/20")
    print("SOURCE_V6_8_HIT_MAX=10")
    print("SOURCE_V6_8_FIRST_TOKEN_TOP1=0/20")
    print("SOURCE_V6_8_FIRST_TOKEN_MEAN_RANK=24.25")
    print("TARGET_SOURCES=RECONSTRUCTED,APPROVED,ORIGINAL_SOURCE,TRAIN_ROW")
    print("GENERATED_PARAPHRASE_ALLOWED=False")
    print("RETAINED_HOLDOUT_EVALUATED=False")
    print("STRESS_SEMANTIC_SOURCE_SHA256="+semantic_source_sha)
    print("NO_GITHUB_PUSH=True")

    rows=[]
    family_stats=defaultdict(lambda:{
        "rows":0,
        "generated_pass":0,
        "reconstructed_pass":0,
        "approved_pass":0,
        "original_pass":0,
        "best_existing_pass":0,
    })
    source_counts=Counter()
    generated_replay_mismatch=[]

    for i,r in enumerate(anchors,1):
        rid=cid(r)
        rr=recon.get(rid)
        ar=approved.get(rid)
        dr=detail.get(rid)
        if rr is None or ar is None or dr is None:
            raise SystemExit("Missing case mapping for "+rid)

        case=case_from_row(r)
        gen=generated_body(dr)
        gen_sem=semantic_bool(v57,gen,case)
        stored_sem=bool(dr.get("semantic"))
        if gen_sem!=stored_sem:
            generated_replay_mismatch.append(rid)

        scored=[]
        for c in source_candidates(rr,ar,r):
            scored.append({
                **c,
                "semantic_pass":semantic_bool(v57,c["text"],case),
                "char_len":len(c["text"]),
                "sha256":hashlib.sha256(c["text"].encode("utf-8")).hexdigest(),
            })
        selected=choose_existing_valid(scored)

        rec_next=next((x for x in scored if x["kind"]=="V6_7_RECONSTRUCTED"),None)
        app_next=next((x for x in scored if x["kind"]=="V5_9_17_1_APPROVED_CANONICAL"),None)
        orig_next=next((x for x in scored if x["kind"]=="V5_9_17_1_ORIGINAL_SOURCE"),None)

        fam=family(r)
        fs=family_stats[fam]
        fs["rows"]+=1
        fs["generated_pass"]+=int(gen_sem)
        fs["reconstructed_pass"]+=int(bool(rec_next and rec_next["semantic_pass"]))
        fs["approved_pass"]+=int(bool(app_next and app_next["semantic_pass"]))
        fs["original_pass"]+=int(bool(orig_next and orig_next["semantic_pass"]))
        fs["best_existing_pass"]+=int(selected is not None)

        if selected is not None:
            source_counts[selected["kind"]]+=1
            redesign_status=(
                "KEEP_RECONSTRUCTED"
                if selected["kind"]=="V6_7_RECONSTRUCTED"
                else "USE_EXISTING_CRITERION_VALID_TARGET"
            )
        else:
            redesign_status="NO_EXISTING_CRITERION_VALID_TARGET"

        out={
            "id":rid,
            "language":lang(r),
            "family":fam,
            "mode":r.get("mode"),
            "composition_depth":r.get("composition_depth"),
            "generated_text":gen,
            "generated_semantic_pass":gen_sem,
            "stored_generated_semantic":stored_sem,
            "candidate_targets":scored,
            "selected_existing_target_kind":selected["kind"] if selected else None,
            "selected_existing_target":selected["text"] if selected else None,
            "selected_existing_target_sha256":selected["sha256"] if selected else None,
            "redesign_status":redesign_status,
            "manual_review_required":selected is None,
        }
        rows.append(out)

        print(
            f"CASE_{i}_OF_20={rid} LANG={lang(r)} FAMILY={fam} "
            f"GEN_SEM={gen_sem} "
            f"RECON_SEM={bool(rec_next and rec_next['semantic_pass'])} "
            f"APPROVED_SEM={bool(app_next and app_next['semantic_pass'])} "
            f"ORIGINAL_SEM={bool(orig_next and orig_next['semantic_pass'])} "
            f"SELECTED={selected['kind'] if selected else 'NONE'}"
        )

    if generated_replay_mismatch:
        raise SystemExit(
            "Semantic evaluator replay mismatch on: "
            +",".join(generated_replay_mismatch)
        )

    reconstructed_pass=sum(
        int(next(x for x in r["candidate_targets"] if x["kind"]=="V6_7_RECONSTRUCTED")["semantic_pass"])
        for r in rows
    )
    approved_pass=sum(
        int(next((x for x in r["candidate_targets"] if x["kind"]=="V5_9_17_1_APPROVED_CANONICAL"),{"semantic_pass":False})["semantic_pass"])
        for r in rows
    )
    original_pass=sum(
        int(next((x for x in r["candidate_targets"] if x["kind"]=="V5_9_17_1_ORIGINAL_SOURCE"),{"semantic_pass":False})["semantic_pass"])
        for r in rows
    )
    best_existing_pass=sum(int(r["selected_existing_target"] is not None) for r in rows)
    manual_review=20-best_existing_pass

    # Build a non-training target-family candidate file with strict provenance.
    family_candidates=[]
    for r in rows:
        family_candidates.append({
            "source_case_id":r["id"],
            "language":r["language"],
            "family":r["family"],
            "target_family_candidate":r["selected_existing_target"],
            "target_family_source":r["selected_existing_target_kind"],
            "criterion_valid":r["selected_existing_target"] is not None,
            "manual_review_required":r["manual_review_required"],
            "provenance_policy":"EXISTING_SOURCE_ONLY_NO_GENERATED_PARAPHRASE",
        })

    work=root/"diagnostics/v6_9_semantic_criterion_and_target_family_redesign_milestone"
    data=root/"full_training/v6_9_semantic_criterion_and_target_family_redesign"
    work.mkdir(parents=True,exist_ok=True)
    data.mkdir(parents=True,exist_ok=True)

    detailp=work/"v6_9_semantic_criterion_audit_detail.jsonl"
    familyp=data/"v6_9_target_family_candidates_20.jsonl"
    sourcep=work/"v6_9_stress_semantic_source.txt"
    reportp=work/"v6_9_semantic_criterion_report.json"
    summaryp=work/"v6_9_milestone_summary.json"

    write_jsonl(detailp,rows)
    write_jsonl(familyp,family_candidates)
    sourcep.write_text(semantic_source,encoding="utf-8",newline="\n")

    # Route without training. This is the decision point for v6.10.
    if reconstructed_pass>=16:
        classification="CANONICAL_TARGETS_ALREADY_CRITERION_VALID_MODEL_SEMANTIC_MAPPING_IS_PRIMARY_BOTTLENECK"
        next_milestone="v6.10-semantic-criterion-aware-discriminative-training-milestone"
        training_authorized=True
    elif best_existing_pass>=16:
        classification="EXISTING_TARGET_FAMILY_ALTERNATIVES_RESTORE_CRITERION_VALID_COVERAGE"
        next_milestone="v6.10-criterion-valid-target-family-training-milestone"
        training_authorized=True
    elif best_existing_pass>=8:
        classification="TARGET_FAMILY_COVERAGE_PARTIAL_MANUAL_REVIEW_REQUIRED"
        next_milestone="v6.10-target-family-review-and-controlled-reconstruction-milestone"
        training_authorized=False
    else:
        classification="SEMANTIC_CRITERION_AND_EXISTING_TARGET_FAMILIES_ARE_MISALIGNED"
        next_milestone="v6.10-semantic-criterion-reconciliation-milestone"
        training_authorized=False

    report={
        "schema":"ZANT_LLM_V6_9_SEMANTIC_CRITERION_TARGET_FAMILY_AUDIT_V1",
        "milestone_complete":True,
        "no_training":True,
        "generated_semantic_replay_mismatch_count":0,
        "generated_semantic_pass_count":sum(int(r["generated_semantic_pass"]) for r in rows),
        "reconstructed_target_semantic_pass_count":reconstructed_pass,
        "approved_canonical_semantic_pass_count":approved_pass,
        "original_source_semantic_pass_count":original_pass,
        "best_existing_source_semantic_pass_count":best_existing_pass,
        "manual_review_required_count":manual_review,
        "selected_existing_source_counts":dict(source_counts),
        "family_stats":dict(family_stats),
        "stress_semantic_source_sha256":semantic_source_sha,
        "detail_file":str(detailp),
        "detail_file_sha256":sha256_file(detailp),
        "target_family_candidate_file":str(familyp),
        "target_family_candidate_file_sha256":sha256_file(familyp),
        "classification":classification,
        "training_authorized":training_authorized,
        "retained_holdout_evaluated":False,
        "next_milestone":next_milestone,
    }
    write_json(reportp,report)

    summary={
        "schema":"ZANT_LLM_V6_9_SEMANTIC_CRITERION_AND_TARGET_FAMILY_REDESIGN_MILESTONE_V1",
        "milestone_complete":True,
        "no_training":True,
        "source_v6_8_complete":True,
        "source_v6_8_anchor_pass_count":0,
        "source_v6_8_hit_max_count":10,
        "source_v6_8_first_token_top1_count":0,
        "source_v6_8_first_token_mean_rank":24.25,
        "reconstructed_target_semantic_pass_count":reconstructed_pass,
        "approved_canonical_semantic_pass_count":approved_pass,
        "original_source_semantic_pass_count":original_pass,
        "best_existing_source_semantic_pass_count":best_existing_pass,
        "manual_review_required_count":manual_review,
        "milestone_status":classification,
        "training_authorized":training_authorized,
        "retained_holdout_opened":False,
        "next_milestone":next_milestone,
        "github_push_performed":False,
    }
    write_json(summaryp,summary)

    print("========== V6.9 MILESTONE FINAL ==========")
    print("V6_9_MILESTONE_COMPLETE=True")
    print("NO_TRAINING=True")
    print("GENERATED_SEMANTIC_PASS_COUNT="+str(sum(int(r["generated_semantic_pass"]) for r in rows))+"/20")
    print("RECONSTRUCTED_TARGET_SEMANTIC_PASS_COUNT="+str(reconstructed_pass)+"/20")
    print("APPROVED_CANONICAL_SEMANTIC_PASS_COUNT="+str(approved_pass)+"/20")
    print("ORIGINAL_SOURCE_SEMANTIC_PASS_COUNT="+str(original_pass)+"/20")
    print("BEST_EXISTING_SOURCE_SEMANTIC_PASS_COUNT="+str(best_existing_pass)+"/20")
    print("MANUAL_REVIEW_REQUIRED_COUNT="+str(manual_review)+"/20")
    print("TRAINING_AUTHORIZED="+str(training_authorized))
    print("RETAINED_HOLDOUT_OPENED=False")
    print("MILESTONE_STATUS="+classification)
    print("REPORT_SHA256="+sha256_file(reportp))
    print("FINAL_SUMMARY_SHA256="+sha256_file(summaryp))
    print("NEXT_MILESTONE="+next_milestone)
    print("GITHUB_PUSH_PERFORMED=False")

if __name__=="__main__":
    main()
