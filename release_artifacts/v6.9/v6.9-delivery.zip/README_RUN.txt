Zant-LLM v6.9 — Semantic Criterion + Target Family Redesign Milestone

Authoritative v6.8 result
-------------------------
v6.8 is COMPLETE / CLOSED.

Training:
- prompt-conditioned semantic bridge
- 394,753 trainable parameters
- 20 optimizer steps
- patch manifest:
  5095bd899a60752b982746aa9c0821e5df0b0c51d026d0d6318140447e4e2e98
- bridge file:
  c115cb57a6767a1dd85e2da5e3814a788249784fcc2aba4e45f884dd1301d440

Anchor result:
- PASS = 0/20
- HIT_MAX = 10
- English HIT_MAX = 10/10
- Chinese HIT_MAX = 0/10
- first-token TOP1 = 0/20
- first-token mean rank = 24.25
- same generated text as v6.7 = 19/20
- retained holdout stayed closed

The bridge moved first-token mean rank substantially, but it still did not
change the semantic landing behavior. Therefore another blind capacity or loss
increase is not justified.

Purpose of v6.9
---------------
v6.9 performs NO TRAINING.

It directly audits the semantic criterion used by the frozen v5.7 stress
evaluator against four existing target sources:

1. v6.7 reconstructed canonical target
2. v5.9.17.1 approved canonical target
3. v5.9.17.1 original source target
4. v5.9.2 training-row target

No generated paraphrase is permitted.

For each of the 20 anchors, v6.9 asks:

- Does the current v6.8 generated output pass the exact semantic criterion?
- Does the reconstructed target itself pass?
- Does the approved canonical target pass?
- Does the preserved original source target pass?
- Is there at least one existing source target that satisfies the criterion?

It also replays the semantic evaluator on the v6.8 generated outputs and
requires exact agreement with the stored semantic flags. This guards against
evaluator drift or wrapper mismatch.

Outputs
-------
diagnostics\v6_9_semantic_criterion_and_target_family_redesign_milestone\
  v6_9_semantic_criterion_audit_detail.jsonl
  v6_9_semantic_criterion_report.json
  v6_9_stress_semantic_source.txt
  v6_9_milestone_summary.json

full_training\v6_9_semantic_criterion_and_target_family_redesign\
  v6_9_target_family_candidates_20.jsonl

The candidate target-family file contains only existing, provenance-preserved
text. Rows with no criterion-valid existing target are explicitly marked for
manual review.

Automatic route to v6.10
-------------------------
If >=16 reconstructed targets already satisfy the criterion:
  -> v6.10 semantic-criterion-aware discriminative training

If >=16 anchors can be covered by an existing target-family alternative:
  -> v6.10 criterion-valid target-family training

If only 8..15 anchors can be covered:
  -> v6.10 controlled target-family review/reconstruction

If <8 anchors can be covered:
  -> v6.10 semantic-criterion reconciliation

Retained holdout is not evaluated.
No GitHub push.
