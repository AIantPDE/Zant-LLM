$ErrorActionPreference = "Stop"

$ROOT = "C:\Users\Administrator\Desktop\Zant-LLM"
$PYTHON = "C:\Users\Administrator\AppData\Local\Programs\Python\Python311\python.exe"

$V68_BRIDGE = Join-Path $ROOT "artifacts\Zant-LLM-v6_8-prompt-conditioned-semantic-bridge-pilot"
$V67_RECON = Join-Path $ROOT "full_training\v6_7_canonical_target_reconstruction\v6_7_reconstructed_canonical_targets_20.jsonl"
$APPROVED_FILE = Join-Path $ROOT "full_training\v5_9_17_1_canonical_target_review\canonical_target_approved_20.jsonl"
$TRAIN_FILE = Join-Path $ROOT "full_training\v5_9_2_residual_training_dataset\train_v5_9_2_round2_100.jsonl"
$HOLDOUT_FILE = Join-Path $ROOT "full_training\v5_9_2_residual_training_dataset\eval_v5_9_2_residual_holdout_20.jsonl"
$V57_RUNNER = Join-Path $ROOT "diagnostics\v5_7_adversarial_transfer_stress_runner\run_v5_7_adversarial_transfer_stress.py"

$ORCH = Join-Path $ROOT "full_training\run_v6_9_semantic_criterion_target_family_redesign_milestone.py"
$WORKER = Join-Path $ROOT "full_training\v6_9_internal\run_v6_9_semantic_criterion_target_family_redesign.py"

Write-Host "========== ZANT-LLM v6.9 SEMANTIC-CRITERION + TARGET-FAMILY REDESIGN =========="
Write-Host "NO_TRAINING=True"
Write-Host "NO_NEW_RULES=True"
Write-Host "SOURCE_V6_8_COMPLETE=True"
Write-Host "SOURCE_V6_8_PASS=0/20"
Write-Host "SOURCE_V6_8_HIT_MAX=10"
Write-Host "SOURCE_V6_8_FIRST_TOKEN_TOP1=0/20"
Write-Host "SOURCE_V6_8_FIRST_TOKEN_MEAN_RANK=24.25"
Write-Host "GENERATED_PARAPHRASE_ALLOWED=False"
Write-Host "TARGET_FAMILY_POLICY=EXISTING_SOURCE_ONLY"
Write-Host "RETAINED_HOLDOUT_EVALUATED=False"
Write-Host "NO_GITHUB_PUSH=True"

foreach ($p in @($PYTHON,$V68_BRIDGE,$V67_RECON,$APPROVED_FILE,$TRAIN_FILE,$HOLDOUT_FILE,$V57_RUNNER,$ORCH,$WORKER)) {
    if (!(Test-Path $p)) { throw "Required path not found: $p" }
}

& $PYTHON $ORCH `
    --root $ROOT `
    --v68-bridge $V68_BRIDGE `
    --v67-reconstructed-file $V67_RECON `
    --approved-file $APPROVED_FILE `
    --train-file $TRAIN_FILE `
    --holdout-file $HOLDOUT_FILE `
    --v57-runner $V57_RUNNER `
    --worker $WORKER

$exit=$LASTEXITCODE
Write-Host "V6_9_PROCESS_EXIT=$exit"
if ($exit -ne 0) { throw "v6.9 milestone failed (exit=$exit)" }
Write-Host "========== v6.9 ONE-CLICK DONE =========="
